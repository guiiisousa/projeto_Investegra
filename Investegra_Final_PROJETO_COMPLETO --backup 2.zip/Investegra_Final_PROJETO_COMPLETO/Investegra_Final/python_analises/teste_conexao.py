
from conexao import testar_conexao

resultado = testar_conexao()

if resultado["sucesso"]:
    print("Conexão realizada com sucesso!")
    print(f"Banco conectado: {resultado['banco']}")
    print("\nTabelas encontradas:")

    for tabela in resultado["tabelas"]:
        print(f"- {tabela}")
else:
    print("Não foi possível conectar ao banco.")
    print(f"Erro: {resultado['erro']}")
