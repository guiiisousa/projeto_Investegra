
import math

import pandas as pd

from conexao import obter_conexao
from brapi_service import buscar_cotacao


def listar_carteiras(usuario_id: int) -> pd.DataFrame:
    """Retorna somente as carteiras do usuário autenticado."""

    conexao = obter_conexao()

    try:
        consulta = """
            SELECT id, nome, descricao, criado_em
            FROM carteiras
            WHERE usuario_id = %s
            ORDER BY criado_em DESC
        """

        return pd.read_sql(
            consulta,
            conexao,
            params=(usuario_id,)
        )

    finally:
        conexao.close()


def listar_ativos(usuario_id: int) -> pd.DataFrame:
    """
    Lista os ativos pertencentes às carteiras do usuário.

    Calcula valores financeiros somente quando os dados são válidos.
    Não soma diretamente cotações de moedas diferentes.
    """

    conexao = obter_conexao()

    try:
        consulta = """
            SELECT
                c.id AS carteira_id,
                c.nome AS carteira,
                a.id AS ativo_id,
                a.ticker,
                a.quantidade,
                a.preco_medio,
                a.data_compra,
                cat.nome AS categoria
            FROM carteiras c
            INNER JOIN ativos a
                ON a.carteira_id = c.id
            LEFT JOIN categorias cat
                ON cat.id = a.categoria_id
            WHERE c.usuario_id = %s
            ORDER BY c.nome, a.ticker
        """

        df = pd.read_sql(
            consulta,
            conexao,
            params=(usuario_id,)
        )

    finally:
        conexao.close()

    if df.empty:
        return df

    # --------------------------------------------------
    # NORMALIZAÇÃO DOS DADOS
    # --------------------------------------------------

    df["quantidade"] = pd.to_numeric(
        df["quantidade"],
        errors="coerce"
    )

    df["preco_medio"] = pd.to_numeric(
        df["preco_medio"],
        errors="coerce"
    )

    # Evita valores infinitos nos cálculos.
    for coluna in ("quantidade", "preco_medio"):
        valores_validos = df[coluna].map(
            lambda valor: (
                math.isfinite(float(valor))
                if pd.notna(valor)
                else False
            )
        )

        df.loc[~valores_validos, coluna] = float("nan")

    # --------------------------------------------------
    # VALOR INVESTIDO
    # --------------------------------------------------

    df["valor_investido"] = (
        df["quantidade"] * df["preco_medio"]
    )

    investimento_finito = df["valor_investido"].map(
        lambda valor: (
            math.isfinite(float(valor))
            if pd.notna(valor)
            else False
        )
    )

    df.loc[
        ~investimento_finito,
        "valor_investido"
    ] = float("nan")

    # --------------------------------------------------
    # INICIALIZAÇÃO DOS INDICADORES
    # --------------------------------------------------

    df["preco_atual"] = float("nan")
    df["valor_mercado"] = float("nan")
    df["lucro_prejuizo"] = float("nan")
    df["rentabilidade_percentual"] = float("nan")
    df["moeda_cotacao"] = None
    df["erro_cotacao"] = None

    # Evita consultar o mesmo ticker repetidamente
    # durante esta execução da função.
    cache_local = {}

    # --------------------------------------------------
    # COTAÇÕES E CÁLCULOS POR ATIVO
    # --------------------------------------------------

    for indice, linha in df.iterrows():

        ticker_original = linha["ticker"]

        if pd.isna(ticker_original):
            ticker = ""
        else:
            ticker = str(ticker_original).strip().upper()

        quantidade = linha["quantidade"]
        preco_medio = linha["preco_medio"]
        valor_investido = linha["valor_investido"]

        # Valida os dados antes de consultar a API.
        if (
            not ticker
            or pd.isna(quantidade)
            or pd.isna(preco_medio)
            or pd.isna(valor_investido)
            or quantidade <= 0
            or preco_medio < 0
        ):
            df.at[indice, "erro_cotacao"] = (
                "Ticker, quantidade ou preço médio inválido."
            )
            continue

        try:
            # Consulta uma única vez por ticker nesta execução.
            if ticker not in cache_local:
                cache_local[ticker] = buscar_cotacao(ticker)

            cotacao = cache_local[ticker]

            if not isinstance(cotacao, dict):
                raise ValueError(
                    "Formato de cotação inválido."
                )

            preco_recebido = cotacao.get("preco_atual")

            if preco_recebido is None:
                raise ValueError(
                    "Preço atual não informado."
                )

            if isinstance(preco_recebido, bool):
                raise ValueError(
                    "Preço atual inválido."
                )

            preco_atual = float(preco_recebido)

            if (
                not math.isfinite(preco_atual)
                or preco_atual <= 0
            ):
                raise ValueError(
                    "Preço atual inválido."
                )

            moeda = str(
                cotacao.get("moeda") or "BRL"
            ).strip().upper()

            if not moeda:
                raise ValueError(
                    "Moeda da cotação não informada."
                )

            df.at[indice, "preco_atual"] = preco_atual
            df.at[indice, "moeda_cotacao"] = moeda

            # Não mistura moedas diferentes.
            # A conversão cambial ainda não está implementada.
            if moeda != "BRL":
                df.at[indice, "erro_cotacao"] = (
                    f"Cotação disponível em {moeda}; "
                    "conversão para BRL não implementada."
                )
                continue

            # Calcula os valores financeiros.
            valor_mercado = (
                float(quantidade) * preco_atual
            )

            resultado = (
                valor_mercado - float(valor_investido)
            )

            # Evita registrar resultados infinitos.
            if (
                not math.isfinite(valor_mercado)
                or not math.isfinite(resultado)
            ):
                raise ValueError(
                    "Resultado financeiro inválido."
                )

            df.at[indice, "valor_mercado"] = valor_mercado
            df.at[indice, "lucro_prejuizo"] = resultado

            # Não calcula rentabilidade percentual
            # quando não existe capital investido positivo.
            if valor_investido > 0:

                percentual = (
                    resultado / float(valor_investido)
                ) * 100

                if not math.isfinite(percentual):
                    raise ValueError(
                        "Rentabilidade calculada inválida."
                    )

                df.at[
                    indice,
                    "rentabilidade_percentual"
                ] = percentual

        except Exception:
            # Mantém o ativo na tabela mesmo quando a API falha.
            # Evita expor detalhes internos da conexão ou da API.
            df.at[indice, "erro_cotacao"] = (
                "Não foi possível obter uma cotação válida."
            )

    return df
