
import math
import pandas as pd


def _numero_valido(valor):
    """Verifica se um valor numérico é finito."""

    if pd.isna(valor):
        return False

    try:
        return math.isfinite(float(valor))
    except (TypeError, ValueError):
        return False


def _valor_ou_zero(valor):
    """Converte valores numéricos inválidos em zero."""

    if not _numero_valido(valor):
        return 0.0

    return float(valor)


def preparar_ativos(df):
    """
    Retorna uma cópia dos ativos com colunas financeiras
    normalizadas, sem modificar o DataFrame original.
    """

    if df is None or df.empty:
        return pd.DataFrame()

    resultado = df.copy()

    colunas_numericas = [
        "quantidade",
        "preco_medio",
        "preco_atual",
        "valor_investido",
        "valor_mercado",
        "lucro_prejuizo",
        "rentabilidade_percentual"
    ]

    for coluna in colunas_numericas:
        if coluna in resultado.columns:
            resultado[coluna] = pd.to_numeric(
                resultado[coluna],
                errors="coerce"
            )

    return resultado


def resumo_carteira(df):
    """
    Calcula os principais indicadores da carteira.

    Considera apenas ativos com valores de mercado
    e investimento válidos em BRL.
    """

    ativos = preparar_ativos(df)

    if ativos.empty:
        return {
            "quantidade_ativos": 0,
            "ativos_com_cotacao": 0,
            "patrimonio_investido": 0.0,
            "valor_mercado": 0.0,
            "lucro_prejuizo": 0.0,
            "rentabilidade_percentual": None,
            "moeda": "BRL"
        }

    if "moeda_cotacao" in ativos.columns:
        moeda = (
            ativos["moeda_cotacao"]
            .fillna("")
            .astype(str)
            .str.upper()
        )

        filtro_brl = moeda.eq("BRL")
    else:
        filtro_brl = pd.Series(
            False,
            index=ativos.index
        )

    if "erro_cotacao" in ativos.columns:
        filtro_erro = ativos["erro_cotacao"].isna()
    else:
        filtro_erro = pd.Series(
            True,
            index=ativos.index
        )

    filtro_valores = (
        ativos["valor_investido"].map(_numero_valido)
        & ativos["valor_mercado"].map(_numero_valido)
        & ativos["lucro_prejuizo"].map(_numero_valido)
    )

    validos = ativos[
        filtro_brl & filtro_erro & filtro_valores
    ]

    patrimonio_investido = float(
        validos["valor_investido"].sum()
    )

    valor_mercado = float(
        validos["valor_mercado"].sum()
    )

    lucro_prejuizo = float(
        validos["lucro_prejuizo"].sum()
    )

    if patrimonio_investido > 0:
        rentabilidade = (
            lucro_prejuizo / patrimonio_investido
        ) * 100
    else:
        rentabilidade = None

    return {
        "quantidade_ativos": int(len(ativos)),
        "ativos_com_cotacao": int(len(validos)),
        "patrimonio_investido": patrimonio_investido,
        "valor_mercado": valor_mercado,
        "lucro_prejuizo": lucro_prejuizo,
        "rentabilidade_percentual": rentabilidade,
        "moeda": "BRL"
    }


def distribuicao_por_categoria(df):
    """Calcula a distribuição patrimonial por categoria."""

    ativos = preparar_ativos(df)

    if ativos.empty or "categoria" not in ativos.columns:
        return []

    resumo = resumo_carteira(ativos)

    if resumo["valor_mercado"] <= 0:
        return []

    if "moeda_cotacao" not in ativos.columns:
        return []

    moeda = (
        ativos["moeda_cotacao"]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    filtro = (
        moeda.eq("BRL")
        & ativos["valor_mercado"].map(_numero_valido)
    )

    if "erro_cotacao" in ativos.columns:
        filtro &= ativos["erro_cotacao"].isna()

    validos = ativos[filtro].copy()

    validos["categoria"] = (
        validos["categoria"]
        .fillna("Não classificado")
        .astype(str)
    )

    agrupado = (
        validos.groupby("categoria")["valor_mercado"]
        .sum()
        .sort_values(ascending=False)
    )

    total = float(agrupado.sum())

    resultado = []

    for categoria, valor in agrupado.items():

        resultado.append({
            "categoria": str(categoria),
            "valor": float(valor),
            "percentual": float(valor / total * 100)
        })

    return resultado


def desempenho_por_ativo(df):
    """Organiza o desempenho individual dos ativos."""

    ativos = preparar_ativos(df)

    if ativos.empty:
        return []

    colunas = [
        "ticker",
        "categoria",
        "valor_investido",
        "valor_mercado",
        "lucro_prejuizo",
        "rentabilidade_percentual"
    ]

    existentes = [
        coluna
        for coluna in colunas
        if coluna in ativos.columns
    ]

    if "ticker" not in existentes:
        return []

    if "moeda_cotacao" not in ativos.columns:
        return []

    moeda = (
        ativos["moeda_cotacao"]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    filtro = (
        moeda.eq("BRL")
        & ativos["valor_mercado"].map(_numero_valido)
    )

    if "erro_cotacao" in ativos.columns:
        filtro &= ativos["erro_cotacao"].isna()

    validos = ativos.loc[filtro, existentes].copy()

    validos = validos.where(
        pd.notna(validos),
        None
    )

    return validos.to_dict(orient="records")
