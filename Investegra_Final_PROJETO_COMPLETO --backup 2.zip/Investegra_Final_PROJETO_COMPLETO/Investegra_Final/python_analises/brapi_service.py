
import math
import os
import time
import threading

import requests


# --------------------------------------------------
# CONFIGURAÇÃO DA BRAPI
# --------------------------------------------------

BASE_URL = os.getenv(
    "BRAPI_BASE_URL",
    "https://brapi.dev/api"
).rstrip("/")

TOKEN = os.getenv("BRAPI_TOKEN", "").strip()

CACHE_SEGUNDOS = 60
TIMEOUT_SEGUNDOS = 10

# Cache independente do Streamlit.
_cache_cotacoes = {}
_lock_cache = threading.Lock()


# --------------------------------------------------
# CONSULTA DE COTAÇÃO
# --------------------------------------------------

def _consultar_cotacao(
    ticker: str,
    token: str,
    base_url: str
) -> dict:

    ticker = ticker.strip().upper()

    if not ticker or len(ticker) > 20:
        raise ValueError("Código do ativo inválido.")

    if not all(
        caractere.isalnum() or caractere in ".-"
        for caractere in ticker
    ):
        raise ValueError(
            "O código do ativo contém caracteres inválidos."
        )

    if not base_url.startswith("https://"):
        raise ValueError(
            "A URL da API deve utilizar HTTPS."
        )

    chave_cache = (ticker, token, base_url)
    agora = time.monotonic()

    # Verifica se existe uma cotação ainda válida.
    with _lock_cache:
        item = _cache_cotacoes.get(chave_cache)

        if item is not None:
            cotacao, horario = item

            if agora - horario < CACHE_SEGUNDOS:
                return cotacao.copy()

    headers = {
        "Accept": "application/json"
    }

    if token:
        headers["Authorization"] = f"Bearer {token}"

    # --------------------------------------------------
    # REQUISIÇÃO HTTP
    # --------------------------------------------------

    try:
        resposta = requests.get(
            f"{base_url}/v2/stocks/quote",
            params={"symbols": ticker},
            headers=headers,
            timeout=TIMEOUT_SEGUNDOS
        )

    except requests.Timeout as erro:
        raise RuntimeError(
            "A consulta da cotação excedeu o tempo limite."
        ) from erro

    except requests.RequestException as erro:
        raise RuntimeError(
            "Não foi possível conectar à API de cotações."
        ) from erro

    # --------------------------------------------------
    # TRATAMENTO DE STATUS HTTP
    # --------------------------------------------------

    if resposta.status_code in (401, 403):
        raise RuntimeError(
            "A BRAPI exige autenticação ou permissão adicional."
        )

    if resposta.status_code == 429:
        raise RuntimeError(
            "Limite de consultas da BRAPI atingido."
        )

    try:
        resposta.raise_for_status()

    except requests.HTTPError as erro:
        raise RuntimeError(
            "A API de cotações retornou um erro HTTP."
        ) from erro

    # --------------------------------------------------
    # VALIDAÇÃO DO JSON
    # --------------------------------------------------

    try:
        dados = resposta.json()

    except ValueError as erro:
        raise RuntimeError(
            "A BRAPI retornou uma resposta inválida."
        ) from erro

    if not isinstance(dados, dict):
        raise RuntimeError(
            "Formato de resposta inesperado da BRAPI."
        )

    resultados = dados.get("results")

    if (
        not isinstance(resultados, list)
        or not resultados
        or not isinstance(resultados[0], dict)
    ):
        raise RuntimeError(
            "Não foi encontrada cotação para esse ativo."
        )

    resultado = resultados[0]

    cotacao = resultado.get("data", resultado)

    if not isinstance(cotacao, dict):
        raise RuntimeError(
            "Os dados da cotação estão em formato inválido."
        )

    # --------------------------------------------------
    # VALIDAÇÃO DO PREÇO
    # --------------------------------------------------

    preco = cotacao.get("regularMarketPrice")

    if (
        not isinstance(preco, (int, float))
        or isinstance(preco, bool)
        or not math.isfinite(float(preco))
        or preco <= 0
    ):
        raise RuntimeError(
            "A BRAPI não retornou um preço válido."
        )

    # --------------------------------------------------
    # VALIDAÇÃO DA MOEDA
    # --------------------------------------------------

    moeda_recebida = cotacao.get("currency")

    if (
        not isinstance(moeda_recebida, str)
        or not moeda_recebida.strip()
    ):
        raise RuntimeError(
            "A BRAPI não informou uma moeda válida."
        )

    moeda = moeda_recebida.strip().upper()

    # --------------------------------------------------
    # VARIAÇÃO PERCENTUAL
    # --------------------------------------------------

    variacao = cotacao.get(
        "regularMarketChangePercent"
    )

    if variacao is not None:
        if (
            not isinstance(variacao, (int, float))
            or isinstance(variacao, bool)
            or not math.isfinite(float(variacao))
        ):
            variacao = None
        else:
            variacao = float(variacao)

    # --------------------------------------------------
    # RESULTADO NORMALIZADO
    # --------------------------------------------------

    resultado_final = {
        "ticker": resultado.get("symbol") or ticker,
        "nome": (
            cotacao.get("shortName")
            or cotacao.get("longName")
            or ticker
        ),
        "preco_atual": float(preco),
        "variacao_percentual": variacao,
        "moeda": moeda,
        "consultado_em": dados.get("requestedAt")
    }

    # Armazena somente consultas bem-sucedidas.
    with _lock_cache:
        _cache_cotacoes[chave_cache] = (
            resultado_final.copy(),
            time.monotonic()
        )

    return resultado_final


# --------------------------------------------------
# FUNÇÃO UTILIZADA PELO RESTANTE DO SISTEMA
# --------------------------------------------------

def buscar_cotacao(ticker: str) -> dict:

    if not isinstance(ticker, str):
        raise ValueError(
            "O código do ativo deve ser um texto."
        )

    return _consultar_cotacao(
        ticker=ticker,
        token=TOKEN,
        base_url=BASE_URL
    )


# --------------------------------------------------
# LIMPEZA DO CACHE
# --------------------------------------------------

def limpar_cache_cotacoes():

    with _lock_cache:
        _cache_cotacoes.clear()
