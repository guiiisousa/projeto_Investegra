
from dados_financeiros import listar_carteiras, listar_ativos

# Troque pelo ID de um usuário de teste existente no banco.
USUARIO_ID = 1

carteiras = listar_carteiras(USUARIO_ID)
ativos = listar_ativos(USUARIO_ID)

print("\n=== CARTEIRAS ===")
print(carteiras.to_string(index=False) if not carteiras.empty else "Nenhuma carteira encontrada.")

print("\n=== ATIVOS ===")
print(ativos.to_string(index=False) if not ativos.empty else "Nenhum ativo encontrado.")
