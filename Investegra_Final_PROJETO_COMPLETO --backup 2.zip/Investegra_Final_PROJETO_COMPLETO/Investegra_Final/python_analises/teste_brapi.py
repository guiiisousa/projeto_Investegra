
from brapi_service import buscar_cotacao

try:
    ticker = input("Digite um ticker para testar (ex.: PETR4): ").strip()

    cotacao = buscar_cotacao(ticker)

    print("\nCotação consultada com sucesso!")
    print(f"Ativo: {cotacao['ticker']}")
    print(f"Nome: {cotacao['nome']}")
    print(f"Preço atual: R$ {cotacao['preco_atual']:.2f}")
    print(f"Moeda: {cotacao['moeda']}")
    print(f"Consultado em: {cotacao['consultado_em']}")

except Exception as erro:
    print("\nNão foi possível consultar a cotação.")
    print(f"Motivo: {erro}")
