
import base64
import hashlib
import hmac
import json
import time
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from dados_financeiros import listar_carteiras, listar_ativos


# --------------------------------------------------
# CONFIGURAÇÃO DA PÁGINA
# --------------------------------------------------

st.set_page_config(
    page_title="INVESTEGRA | Análises",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)


# --------------------------------------------------
# AUTENTICAÇÃO: TOKEN ASSINADO PELO PHP
# --------------------------------------------------

def validar_token_php(token: str) -> int | None:
    """
    Valida o token HMAC-SHA256 criado pelo DashboardController.php.

    Retorna o ID do usuário se o token for válido.
    Retorna None se o token for inválido ou estiver expirado.
    """

    if not token or "." not in token:
        return None

    try:
        payload, assinatura_recebida = token.rsplit(".", 1)

        caminho_chave = (
            Path(__file__).resolve().parent.parent
            / "config"
            / "python_bridge_secret.txt"
        )

        if not caminho_chave.is_file():
            return None

        segredo = caminho_chave.read_text(
            encoding="utf-8"
        ).strip()

        if len(segredo) < 64:
            return None

        assinatura_esperada = hmac.new(
            segredo.encode("utf-8"),
            payload.encode("ascii"),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(
            assinatura_esperada,
            assinatura_recebida
        ):
            return None

        payload_completo = payload + "=" * (
            (4 - len(payload) % 4) % 4
        )

        dados = json.loads(
            base64.urlsafe_b64decode(
                payload_completo.encode("ascii")
            ).decode("utf-8")
        )

        usuario_id = int(dados["user_id"])
        expiracao = int(dados["exp"])

        if usuario_id <= 0:
            return None

        if expiracao <= int(time.time()):
            return None

        return usuario_id

    except (
        ValueError,
        TypeError,
        KeyError,
        UnicodeDecodeError,
        json.JSONDecodeError,
        OSError
    ):
        return None

    except Exception:
        return None


# Valida o token em todas as execuções do Streamlit.

token_recebido = st.query_params.get("token", "")
usuario_validado = validar_token_php(token_recebido)

if usuario_validado is None:

    st.session_state.pop("bridge_user_id", None)

    st.error(
        "Não foi possível validar seu acesso às análises financeiras."
    )

    st.info(
        "Acesse o INVESTEGRA pelo login PHP e abra novamente "
        "a seção de análises avançadas."
    )

    st.stop()


# A identidade vem exclusivamente do token validado.

st.session_state["bridge_user_id"] = usuario_validado
usuario_id = int(usuario_validado)


# --------------------------------------------------
# ESTILO VISUAL
# --------------------------------------------------

st.markdown(
    """
    <style>
        .stApp {
            background-color: #f5f8f6;
        }

        h1, h2, h3 {
            color: #087f5b;
        }

        div[data-testid="stMetric"] {
            background-color: white;
            border: 1px solid #dce8e1;
            padding: 18px;
            border-radius: 12px;
        }
    </style>
    """,
    unsafe_allow_html=True
)


# --------------------------------------------------
# MENU LATERAL
# --------------------------------------------------

st.sidebar.title("INVESTEGRA")
st.sidebar.caption("Inteligência financeira")
st.sidebar.caption("Análises da sua conta autenticada")

pagina = st.sidebar.radio(
    "Navegação",
    [
        "Visão geral",
        "Carteiras",
        "Meus ativos",
        "Rentabilidade",
        "Sobre"
    ]
)

if st.sidebar.button("Atualizar dados"):
    st.cache_data.clear()
    st.rerun()


# --------------------------------------------------
# CABEÇALHO
# --------------------------------------------------

st.title("Análises financeiras")

st.caption(
    "Dados do MySQL e cotações consultadas pela BRAPI."
)


# --------------------------------------------------
# CARREGAMENTO DOS DADOS DO USUÁRIO
# --------------------------------------------------

try:

    # Todas as consultas usam o ID validado pelo token.

    carteiras = listar_carteiras(usuario_id)
    ativos = listar_ativos(usuario_id)

    total_carteiras = len(carteiras)
    total_ativos = len(ativos)

    valor_investido = (
        float(ativos["valor_investido"].sum())
        if not ativos.empty
        else 0.0
    )

    valor_mercado = (
        float(ativos["valor_mercado"].sum(min_count=1))
        if not ativos.empty
        else 0.0
    )

    lucro_prejuizo = (
        valor_mercado - valor_investido
        if pd.notna(valor_mercado)
        else None
    )

    # A rentabilidade consolidada só é calculada
    # quando todos os ativos possuem cotações válidas.

    cotacoes_completas = (
        not ativos.empty
        and ativos["preco_atual"].notna().all()
        and ativos["valor_investido"].notna().all()
    )

    rentabilidade_total = (
        lucro_prejuizo / valor_investido * 100
        if cotacoes_completas
        and valor_investido > 0
        and lucro_prejuizo is not None
        else None
    )


    # --------------------------------------------------
    # PÁGINA: VISÃO GERAL
    # --------------------------------------------------

    if pagina == "Visão geral":

        st.subheader("Visão geral da carteira")

        col1, col2, col3, col4 = st.columns(4)

        col1.metric(
            "Valor investido",
            f"R$ {valor_investido:,.2f}"
        )

        col2.metric(
            "Valor de mercado",
            f"R$ {valor_mercado:,.2f}"
            if pd.notna(valor_mercado)
            else "Indisponível"
        )

        col3.metric(
            "Lucro / prejuízo estimado",
            f"R$ {lucro_prejuizo:,.2f}"
            if lucro_prejuizo is not None
            else "Indisponível"
        )

        col4.metric(
            "Rentabilidade estimada",
            f"{rentabilidade_total:.2f}%"
            if rentabilidade_total is not None
            else "Indisponível"
        )

        col5, col6 = st.columns(2)

        col5.metric("Carteiras", total_carteiras)
        col6.metric("Ativos cadastrados", total_ativos)

        if not ativos.empty:

            st.divider()
            st.subheader("Distribuição por categoria")

            distribuicao = (
                ativos.assign(
                    categoria=ativos["categoria"].fillna(
                        "Sem categoria"
                    )
                )
                .groupby(
                    "categoria",
                    as_index=False
                )["valor_investido"]
                .sum()
            )

            grafico = px.pie(
                distribuicao,
                names="categoria",
                values="valor_investido",
                hole=0.45
            )

            st.plotly_chart(
                grafico,
                use_container_width=True
            )

            st.subheader("Rentabilidade por ativo")

            ativos_com_cotacao = ativos.dropna(
                subset=["rentabilidade_percentual"]
            )

            if not ativos_com_cotacao.empty:

                grafico_rentabilidade = px.bar(
                    ativos_com_cotacao,
                    x="ticker",
                    y="rentabilidade_percentual",
                    color="rentabilidade_percentual",
                    title="Variação estimada desde o preço médio",
                    labels={
                        "ticker": "Ativo",
                        "rentabilidade_percentual": "Rentabilidade (%)"
                    }
                )

                st.plotly_chart(
                    grafico_rentabilidade,
                    use_container_width=True
                )

            if ativos["preco_atual"].isna().any():

                st.warning(
                    "Há ativos sem cotação disponível. "
                    "Os indicadores consolidados podem estar incompletos."
                )

        else:

            st.info(
                "Você ainda não possui ativos cadastrados."
            )


    # --------------------------------------------------
    # PÁGINA: CARTEIRAS
    # --------------------------------------------------

    elif pagina == "Carteiras":

        st.subheader("Carteiras cadastradas")

        if carteiras.empty:

            st.info("Nenhuma carteira encontrada.")

        else:

            st.dataframe(
                carteiras,
                use_container_width=True,
                hide_index=True
            )


    # --------------------------------------------------
    # PÁGINA: MEUS ATIVOS
    # --------------------------------------------------

    elif pagina == "Meus ativos":

        st.subheader("Meus ativos")

        st.caption(
            "Confira os ativos atualmente cadastrados "
            "em suas carteiras."
        )

        if ativos.empty:

            st.info(
                "Você ainda não possui ativos cadastrados."
            )

        else:

            col1, col2, col3 = st.columns(3)

            col1.metric(
                "Total de ativos",
                len(ativos)
            )

            col2.metric(
                "Valor investido",
                f"R$ {ativos['valor_investido'].sum():,.2f}"
            )

            col3.metric(
                "Carteiras utilizadas",
                ativos["carteira_id"].nunique()
            )

            st.divider()

            st.subheader("Ativos cadastrados")

            colunas = [
                "carteira",
                "ticker",
                "categoria",
                "quantidade",
                "preco_medio",
                "preco_atual",
                "valor_investido",
                "valor_mercado"
            ]

            tabela = ativos[colunas].copy()

            tabela = tabela.rename(columns={
                "carteira": "Carteira",
                "ticker": "Ativo",
                "categoria": "Categoria",
                "quantidade": "Quantidade",
                "preco_medio": "Preço médio",
                "preco_atual": "Cotação atual",
                "valor_investido": "Valor investido",
                "valor_mercado": "Valor de mercado"
            })

            st.dataframe(
                tabela,
                use_container_width=True,
                hide_index=True
            )


    # --------------------------------------------------
    # PÁGINA: RENTABILIDADE
    # --------------------------------------------------

    elif pagina == "Rentabilidade":

        st.subheader("Análise de rentabilidade")

        if ativos.empty:

            st.info("Não há ativos para analisar.")

        else:

            validos = ativos.dropna(
                subset=["rentabilidade_percentual"]
            )

            if validos.empty:

                st.warning(
                    "Não há cotações válidas para calcular a rentabilidade."
                )

            else:

                grafico = px.bar(
                    validos,
                    x="ticker",
                    y="rentabilidade_percentual",
                    color="rentabilidade_percentual",
                    title="Rentabilidade estimada por ativo (%)"
                )

                st.plotly_chart(
                    grafico,
                    use_container_width=True
                )

                st.dataframe(
                    validos[
                        [
                            "ticker",
                            "preco_medio",
                            "preco_atual",
                            "valor_investido",
                            "valor_mercado",
                            "lucro_prejuizo",
                            "rentabilidade_percentual"
                        ]
                    ],
                    use_container_width=True,
                    hide_index=True
                )


    # --------------------------------------------------
    # PÁGINA: SOBRE
    # --------------------------------------------------

    elif pagina == "Sobre":

        st.subheader("Sobre o módulo")

        st.write(
            "O módulo Python complementa o sistema PHP "
            "com indicadores e visualizações financeiras."
        )

        st.write(
            "A identificação do usuário é recebida por meio "
            "de um token temporário assinado pelo PHP."
        )

        st.caption(
            "Os dados financeiros são consultados para o usuário "
            "validado nesta sessão."
        )


    # --------------------------------------------------
    # RODAPÉ
    # --------------------------------------------------

    st.divider()

    st.caption(
        "INVESTEGRA • Valores estimados com base nas cotações "
        "disponíveis. Não constituem recomendação de investimento."
    )


except Exception as erro:

    st.error(
        "Não foi possível carregar os dados financeiros."
    )

    # O detalhe técnico fica no terminal do Streamlit.

    print(
        "Erro ao carregar análises financeiras:",
        repr(erro)
    )
