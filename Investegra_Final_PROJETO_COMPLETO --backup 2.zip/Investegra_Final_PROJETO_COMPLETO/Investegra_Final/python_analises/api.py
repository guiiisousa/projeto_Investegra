
import os
import hmac
import math
import logging

from pathlib import Path
from datetime import date, datetime

import pandas as pd

from fastapi import FastAPI, Header, HTTPException, Depends
from dotenv import load_dotenv

from dados_financeiros import listar_ativos
from calculos import (
    resumo_carteira,
    distribuicao_por_categoria,
    desempenho_por_ativo
)


# =========================================================
# CONFIGURAÇÕES
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

API_KEY = os.getenv("INVESTEGRA_API_KEY")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Investegra API",
    description="Serviço interno de análises financeiras do Investegra.",
    version="1.0.0",
    docs_url=None,
    redoc_url=None
)


# =========================================================
# AUTENTICAÇÃO INTERNA
# =========================================================

def verificar_api_key(x_api_key: str = Header(default="")):

    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Chave da API não configurada."
        )

    if not hmac.compare_digest(x_api_key, API_KEY):
        raise HTTPException(
            status_code=401,
            detail="Acesso não autorizado."
        )


# =========================================================
# SERIALIZAÇÃO DE DADOS
# =========================================================

def converter_valor(valor):

    if valor is None:
        return None

    if valor is pd.NA or valor is pd.NaT:
        return None

    if isinstance(valor, dict):
        return {
            str(chave): converter_valor(item)
            for chave, item in valor.items()
        }

    if isinstance(valor, (list, tuple)):
        return [converter_valor(item) for item in valor]

    if isinstance(valor, (datetime, date)):
        return valor.isoformat()

    if hasattr(valor, "item"):
        valor = valor.item()

    if isinstance(valor, float):
        return valor if math.isfinite(valor) else None

    try:
        if pd.isna(valor):
            return None
    except (TypeError, ValueError):
        pass

    return valor


def converter_resposta(dados):
    return converter_valor(dados)


# =========================================================
# OBTENÇÃO DOS DADOS
# =========================================================

def obter_dados_usuario(usuario_id: int):

    if usuario_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="Identificador de usuário inválido."
        )

    try:
        df = listar_ativos(usuario_id)

        if df is None:
            raise ValueError("A consulta não retornou dados.")

        return df

    except HTTPException:
        raise

    except Exception:
        logger.exception(
            "Erro ao consultar ativos do usuário %s",
            usuario_id
        )

        raise HTTPException(
            status_code=500,
            detail="Não foi possível consultar os dados financeiros."
        )


# =========================================================
# ROTAS
# =========================================================

@app.get("/health")
def verificar_status(
    autenticado: None = Depends(verificar_api_key)
):
    return {
        "status": "online",
        "servico": "Investegra API",
        "versao": "1.0.0"
    }


@app.get("/analises/resumo/{usuario_id}")
def consultar_resumo(
    usuario_id: int,
    autenticado: None = Depends(verificar_api_key)
):

    df = obter_dados_usuario(usuario_id)

    try:
        resultado = resumo_carteira(df)

        return converter_resposta(resultado)

    except Exception:
        logger.exception("Erro ao gerar resumo financeiro.")

        raise HTTPException(
            status_code=500,
            detail="Não foi possível gerar o resumo financeiro."
        )


@app.get("/analises/distribuicao/{usuario_id}")
def consultar_distribuicao(
    usuario_id: int,
    autenticado: None = Depends(verificar_api_key)
):

    df = obter_dados_usuario(usuario_id)

    try:
        resultado = distribuicao_por_categoria(df)

        return converter_resposta(resultado)

    except Exception:
        logger.exception("Erro ao gerar distribuição.")

        raise HTTPException(
            status_code=500,
            detail="Não foi possível gerar a distribuição."
        )


@app.get("/analises/desempenho/{usuario_id}")
def consultar_desempenho(
    usuario_id: int,
    autenticado: None = Depends(verificar_api_key)
):

    df = obter_dados_usuario(usuario_id)

    try:
        resultado = desempenho_por_ativo(df)

        return converter_resposta(resultado)

    except Exception:
        logger.exception("Erro ao gerar desempenho.")

        raise HTTPException(
            status_code=500,
            detail="Não foi possível gerar o desempenho dos ativos."
        )
