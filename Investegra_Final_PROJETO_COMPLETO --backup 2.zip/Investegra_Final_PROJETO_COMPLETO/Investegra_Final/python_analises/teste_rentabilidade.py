
from dados_financeiros import listar_ativos

USUARIO_ID = 1  # Substitua pelo ID correto, se necessário.

ativos = listar_ativos(USUARIO_ID)

if ativos.empty:
    print("Nenhum ativo encontrado para este usuário.")
else:
    colunas = [
        "ticker",
        "quantidade",
        "preco_medio",
        "preco_atual",
        "valor_investido",
        "valor_mercado",
        "lucro_prejuizo",
        "rentabilidade_percentual",
        "erro_cotacao"
    ]

    print(ativos[colunas].to_string(index=False))
