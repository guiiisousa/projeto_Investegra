import os
import mysql.connector


def obter_conexao():
    return mysql.connector.connect(
        host=os.getenv("INVESTEGRA_DB_HOST", "localhost"),
        user=os.getenv("INVESTEGRA_DB_USER", "root"),
        password=os.getenv("INVESTEGRA_DB_PASS", "Beto2009!"),
        database=os.getenv("INVESTEGRA_DB_NAME", "Investegra_Final_Projeto_Completo"),
        port=int(os.getenv("INVESTEGRA_DB_PORT", "3306"))
    )


def testar_conexao():
    conexao = None
    try:
        conexao = obter_conexao()
        cursor = conexao.cursor()
        cursor.execute("SELECT DATABASE()")
        banco = cursor.fetchone()[0]
        cursor.execute("SHOW TABLES")
        tabelas = [linha[0] for linha in cursor.fetchall()]
        cursor.close()
        return {"sucesso": True, "banco": banco, "tabelas": tabelas}
    except mysql.connector.Error as erro:
        return {"sucesso": False, "erro": str(erro)}
    finally:
        if conexao is not None and conexao.is_connected():
            conexao.close()
