
import pandas as pd

from calculos import (
    resumo_carteira,
    distribuicao_por_categoria,
    desempenho_por_ativo
)


def criar_dados_teste():

    return pd.DataFrame([
        {
            "ticker": "PETR4",
            "categoria": "Ações",
            "quantidade": 10,
            "preco_medio": 30,
            "valor_investido": 300,
            "preco_atual": 35,
            "valor_mercado": 350,
            "lucro_prejuizo": 50,
            "rentabilidade_percentual": 16.6667,
            "moeda_cotacao": "BRL",
            "erro_cotacao": None
        },
        {
            "ticker": "VALE3",
            "categoria": "Ações",
            "quantidade": 5,
            "preco_medio": 60,
            "valor_investido": 300,
            "preco_atual": 55,
            "valor_mercado": 275,
            "lucro_prejuizo": -25,
            "rentabilidade_percentual": -8.3333,
            "moeda_cotacao": "BRL",
            "erro_cotacao": None
        },
        {
            "ticker": "HGLG11",
            "categoria": "Fundos imobiliários",
            "quantidade": 5,
            "preco_medio": 100,
            "valor_investido": 500,
            "preco_atual": 110,
            "valor_mercado": 550,
            "lucro_prejuizo": 50,
            "rentabilidade_percentual": 10,
            "moeda_cotacao": "BRL",
            "erro_cotacao": None
        }
    ])


def executar_testes():

    df = criar_dados_teste()

    # Teste 1: resumo patrimonial
    resumo = resumo_carteira(df)

    assert resumo["quantidade_ativos"] == 3
    assert resumo["ativos_com_cotacao"] == 3
    assert resumo["patrimonio_investido"] == 1100
    assert resumo["valor_mercado"] == 1175
    assert resumo["lucro_prejuizo"] == 75

    assert abs(
        resumo["rentabilidade_percentual"]
        - (75 / 1100 * 100)
    ) < 0.0001

    # Teste 2: distribuição por categoria
    distribuicao = distribuicao_por_categoria(df)

    assert len(distribuicao) == 2

    total_percentual = sum(
        item["percentual"]
        for item in distribuicao
    )

    assert abs(total_percentual - 100) < 0.0001

    # Teste 3: desempenho individual
    desempenho = desempenho_por_ativo(df)

    assert len(desempenho) == 3

    print("Todos os testes foram aprovados!")


if __name__ == "__main__":
    executar_testes()
