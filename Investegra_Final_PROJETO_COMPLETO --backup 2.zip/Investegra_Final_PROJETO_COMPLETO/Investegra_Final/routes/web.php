<?php

use App\Controllers\AuthController;
use App\Controllers\CadastroController;
use App\Controllers\DashboardController;
use App\Controllers\HomeController;
use App\Core\Router;
use App\Controllers\CarteiraController;

use App\Controllers\AtivoController;

use App\Controllers\BrapiController;

use App\Controllers\AnaliseController;

use App\Controllers\SimulacaoController;


use App\Controllers\ChatController;

use App\Controllers\PerfilController;

use App\Controllers\QuestionarioController;


$router = new Router();


$router->get(
    "/questionario",
    [QuestionarioController::class, "index"]
);

$router->post(
    "/questionario/salvar",
    [QuestionarioController::class, "salvar"]
);

$router->get(
    "/perfil",
    [PerfilController::class, "index"]
);

$router->post(
    "/perfil/atualizar",
    [PerfilController::class, "atualizar"]
);

$router->get(
    "/chat",
    [ChatController::class, "index"]
);

$router->post(
    "/chat/enviar",
    [ChatController::class, "enviar"]
);

$router->post(
    "/chat/limpar",
    [ChatController::class, "limpar"]
);



$router->get(
    "/simulacoes",
    [SimulacaoController::class, "index"]
);

$router->post(
    "/simulacoes/salvar",
    [SimulacaoController::class, "salvar"]
);

$router->get("/analises", [AnaliseController::class, "index"]);

$router->get(
    "/api/ativos/buscar",
    [BrapiController::class, "buscar"]
);

$router->get(
    "/api/ativos/cotacao",
    [BrapiController::class, "cotacao"]
);

$router->get("/ativos", [AtivoController::class, "index"]);
$router->get("/ativos/criar", [AtivoController::class, "criarForm"]);
$router->post("/ativos/criar", [AtivoController::class, "salvar"]);
$router->get("/ativos/editar", [AtivoController::class, "editarForm"]);
$router->post("/ativos/atualizar", [AtivoController::class, "atualizar"]);
$router->post("/ativos/excluir", [AtivoController::class, "excluir"]);

$router->get(
    "/",
    [AuthController::class, "loginForm"]
);

$router->get(
    "/login",
    [AuthController::class, "loginForm"]
);

$router->post(
    "/login",
    [AuthController::class, "autenticar"]
);

$router->get(
    "/cadastro",
    [CadastroController::class, "formulario"]
);

$router->post(
    "/cadastro",
    [CadastroController::class, "cadastrar"]
);

$router->get(
    "/dashboard",
    [DashboardController::class, "index"]
);

$router->post(
    "/logout",
    [AuthController::class, "logout"]
);

$router->get(
    "/carteiras",
    [CarteiraController::class, "index"]
);

$router->get(
    "/carteiras/criar",
    [CarteiraController::class, "criarForm"]
);

$router->post(
    "/carteiras/criar",
    [CarteiraController::class, "salvar"]
);

$router->get(
    "/carteiras/editar",
    [CarteiraController::class, "editarForm"]
);

$router->post(
    "/carteiras/atualizar",
    [CarteiraController::class, "atualizar"]
);

$router->post(
    "/carteiras/excluir",
    [CarteiraController::class, "excluir"]
);

return $router;
