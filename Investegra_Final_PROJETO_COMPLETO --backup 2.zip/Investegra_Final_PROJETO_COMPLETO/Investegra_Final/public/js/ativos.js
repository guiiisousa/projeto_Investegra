
document.addEventListener("DOMContentLoaded", () => {
    const formulario = document.querySelector("[data-ativos-api]");

    if (!formulario) {
        return;
    }

    const campoTicker = formulario.querySelector("#ticker");
    const campoPrecoMedio = formulario.querySelector("#preco_medio");

    const buscaUrl = formulario.dataset.buscaUrl;
    const cotacaoUrl = formulario.dataset.cotacaoUrl;

    if (!campoTicker || !buscaUrl || !cotacaoUrl) {
        return;
    }

    // Cria a área de sugestões sem precisar alterar o HTML manualmente.
    const sugestoes = document.createElement("div");
    sugestoes.className = "sugestoes-ticker";
    sugestoes.setAttribute("role", "listbox");
    sugestoes.hidden = true;

    campoTicker.insertAdjacentElement("afterend", sugestoes);

    const cotacao = document.createElement("div");
    cotacao.className = "cotacao-ativo";
    cotacao.setAttribute("aria-live", "polite");
    cotacao.hidden = true;

    sugestoes.insertAdjacentElement("afterend", cotacao);

    let temporizador = null;
    let numeroBusca = 0;
    let controladorCotacao = null;

    function mostrarMensagemCotacao(mensagem) {
        cotacao.replaceChildren();
        cotacao.textContent = mensagem;
        cotacao.hidden = false;
    }

    function ocultarSugestoes() {
        sugestoes.replaceChildren();
        sugestoes.hidden = true;
    }

    function formatarMoeda(valor, moeda = "BRL") {
        return new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: moeda
        }).format(valor);
    }

    async function buscarCotacao(ticker) {
        if (controladorCotacao) {
            controladorCotacao.abort();
        }

        controladorCotacao = new AbortController();

        mostrarMensagemCotacao("Consultando cotação atual...");

        try {
            const url = new URL(cotacaoUrl, window.location.origin);
            url.searchParams.set("ticker", ticker);

            const resposta = await fetch(url, {
                headers: { Accept: "application/json" },
                signal: controladorCotacao.signal
            });

            const dados = await resposta.json();

            if (!resposta.ok || !dados.sucesso || !dados.cotacao) {
                mostrarMensagemCotacao(
                    dados.mensagem || "Cotação indisponível no momento."
                );
                return;
            }

            const item = dados.cotacao;

            cotacao.replaceChildren();

            const titulo = document.createElement("strong");
            titulo.textContent = "Cotação atual: ";

            const preco = document.createElement("span");
            preco.textContent = formatarMoeda(
                item.preco_atual,
                item.moeda || "BRL"
            );

            cotacao.append(titulo, preco);

            if (item.nome) {
                const nome = document.createElement("p");
                nome.textContent = item.nome;
                cotacao.append(nome);
            }

            if (item.variacao_percentual !== null &&
                item.variacao_percentual !== undefined) {
                const variacao = document.createElement("p");
                const valor = Number(item.variacao_percentual);

                variacao.textContent =
                    `Variação informada pela API: ${
                        valor.toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        })
                    }%`;

                cotacao.append(variacao);
            }

            cotacao.hidden = false;
        } catch (erro) {
            if (erro.name === "AbortError") {
                return;
            }

            mostrarMensagemCotacao(
                "Não foi possível consultar a cotação."
            );
        }
    }

    function selecionarAtivo(item) {
        const ticker = String(item.symbol || "").trim().toUpperCase();

        if (!ticker) {
            return;
        }

        campoTicker.value = ticker;
        ocultarSugestoes();

        buscarCotacao(ticker);
    }

    async function buscarTickers(termo, buscaAtual) {
        try {
            const url = new URL(buscaUrl, window.location.origin);
            url.searchParams.set("q", termo);

            const resposta = await fetch(url, {
                headers: { Accept: "application/json" }
            });

            const dados = await resposta.json();

            // Ignora respostas antigas caso o usuário continue digitando.
            if (buscaAtual !== numeroBusca) {
                return;
            }

            if (!resposta.ok || !dados.sucesso) {
                ocultarSugestoes();
                return;
            }

            const resultados = Array.isArray(dados.resultados)
                ? dados.resultados
                : [];

            sugestoes.replaceChildren();

            if (resultados.length === 0) {
                const vazio = document.createElement("div");
                vazio.className = "sugestao-vazia";
                vazio.textContent = "Nenhum ativo encontrado.";
                sugestoes.append(vazio);
                sugestoes.hidden = false;
                return;
            }

            resultados.forEach((item) => {
                if (!item.symbol) {
                    return;
                }

                const botao = document.createElement("button");
                botao.type = "button";
                botao.className = "sugestao-ticker";
                botao.setAttribute("role", "option");

                const codigo = document.createElement("strong");
                codigo.textContent = item.symbol;

                const nome = document.createElement("span");
                nome.textContent = item.name || "";

                botao.append(codigo, nome);

                // Evita que o campo perca o foco antes da seleção.
                botao.addEventListener("mousedown", (evento) => {
                    evento.preventDefault();
                });

                botao.addEventListener("click", () => {
                    selecionarAtivo(item);
                });

                sugestoes.append(botao);
            });

            sugestoes.hidden = sugestoes.childElementCount === 0;
        } catch (erro) {
            if (buscaAtual === numeroBusca) {
                ocultarSugestoes();
            }
        }
    }

    campoTicker.addEventListener("input", () => {
        clearTimeout(temporizador);

        const termo = campoTicker.value.trim();
        const buscaAtual = ++numeroBusca;

        ocultarSugestoes();
        cotacao.hidden = true;

        if (termo.length < 2) {
            return;
        }

        temporizador = setTimeout(() => {
            buscarTickers(termo, buscaAtual);
        }, 350);
    });

    campoTicker.addEventListener("keydown", (evento) => {
        if (evento.key === "Escape") {
            ocultarSugestoes();
        }

        if (evento.key === "Enter" && !sugestoes.hidden) {
            const primeiraOpcao = sugestoes.querySelector(
                ".sugestao-ticker"
            );

            if (primeiraOpcao) {
                evento.preventDefault();
                primeiraOpcao.click();
            }
        }
    });

    campoTicker.addEventListener("blur", () => {
        setTimeout(() => {
            if (document.activeElement !== campoTicker) {
                ocultarSugestoes();
            }
        }, 150);
    });

    // Ao sair do campo, também permite consultar um ticker digitado manualmente.
    campoTicker.addEventListener("change", () => {
        const ticker = campoTicker.value.trim().toUpperCase();

        if (/^[A-Z0-9.-]{1,20}$/.test(ticker)) {
            campoTicker.value = ticker;
            buscarCotacao(ticker);
        }
    });

    // Evita confundir a cotação atual com o preço médio de compra.
    if (campoPrecoMedio) {
        campoPrecoMedio.addEventListener("input", () => {
            campoPrecoMedio.setCustomValidity("");
        });
    }
});
