(() => {
    "use strict";

    const dataElement = document.getElementById("dashboard-chart-data");
    if (!dataElement) return;

    let data;
    try {
        data = JSON.parse(dataElement.textContent || "{}");
    } catch (error) {
        console.error("Erro ao interpretar os dados dos gráficos:", error);
        return;
    }

    if (typeof Chart === "undefined") {
        console.error("Chart.js não foi carregado.");
        return;
    }

    const palette = ["#00A86B", "#174A5B", "#D6A84F", "#C8755D", "#8B83B8", "#6C9A8B", "#78909C", "#A3B18A"];
    const brl = value => Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
    const percent = value => `${Number(value || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`;
    const tickers = Array.isArray(data.tickers) ? data.tickers : [];

    // 1. Distribuição do capital aplicado por categoria.
    const categories = Array.isArray(data.categorias) ? data.categorias : [];
    const categoryValues = Array.isArray(data.valoresCategorias) ? data.valoresCategorias.map(Number) : [];
    const categoryCanvas = document.getElementById("graficoCategorias");

    if (categoryCanvas && categories.length && categories.length === categoryValues.length) {
        new Chart(categoryCanvas, {
            type: "doughnut",
            data: {
                labels: categories,
                datasets: [{
                    label: "Capital aplicado",
                    data: categoryValues,
                    backgroundColor: categories.map((_, i) => palette[i % palette.length]),
                    borderColor: "#FFFFFF",
                    borderWidth: 3,
                    hoverOffset: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "66%",
                plugins: {
                    legend: { position: "bottom", labels: { usePointStyle: true, pointStyle: "circle", padding: 18, color: "#52645A" } },
                    tooltip: { callbacks: { label(context) {
                        const total = context.dataset.data.reduce((sum, value) => sum + Number(value || 0), 0);
                        const value = Number(context.raw || 0);
                        const share = total > 0 ? value / total * 100 : 0;
                        return `${context.label}: ${brl(value)} (${percent(share)})`;
                    } } }
                }
            }
        });
    }

    // 2. Resultado financeiro estimado em reais por ativo.
    const results = Array.isArray(data.resultados) ? data.resultados.map(Number) : [];
    const performanceCanvas = document.getElementById("graficoDesempenho");
    if (performanceCanvas && tickers.length && tickers.length === results.length) {
        new Chart(performanceCanvas, {
            type: "bar",
            data: { labels: tickers, datasets: [{
                label: "Resultado estimado",
                data: results,
                backgroundColor: results.map(value => value >= 0 ? "#00A86B" : "#C8755D"),
                borderRadius: 6,
                borderSkipped: false,
                maxBarThickness: 34
            }] },
            options: horizontalBarOptions(brl, "R$")
        });
    }

    // 3. Comparação entre custo de aquisição e valor de mercado.
    const invested = Array.isArray(data.valoresInvestidosAtivos) ? data.valoresInvestidosAtivos.map(Number) : [];
    const market = Array.isArray(data.valoresMercadoAtivos) ? data.valoresMercadoAtivos.map(Number) : [];
    const comparisonCanvas = document.getElementById("graficoInvestidoMercado");
    if (comparisonCanvas && tickers.length && invested.length === tickers.length && market.length === tickers.length) {
        new Chart(comparisonCanvas, {
            type: "bar",
            data: { labels: tickers, datasets: [
                { label: "Valor investido", data: invested, backgroundColor: "#174A5B", borderRadius: 5 },
                { label: "Valor de mercado", data: market, backgroundColor: "#00A86B", borderRadius: 5 }
            ] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: {
                    legend: { position: "bottom", labels: { usePointStyle: true, color: "#52645A", padding: 18 } },
                    tooltip: { callbacks: { label(context) { return `${context.dataset.label}: ${brl(context.raw)}`; } } }
                },
                scales: {
                    x: { beginAtZero: true, grid: { color: "#EDF1EE" }, ticks: { color: "#718078", callback: value => brl(value) } },
                    y: { grid: { display: false }, ticks: { color: "#52645A" } }
                }
            }
        });
    }

    // 4. Rentabilidade percentual: positivo acima de zero, negativo abaixo.
    const percentages = Array.isArray(data.percentuaisAtivos) ? data.percentuaisAtivos.map(Number) : [];
    const percentageCanvas = document.getElementById("graficoRentabilidadePercentual");
    if (percentageCanvas && tickers.length && percentages.length === tickers.length) {
        new Chart(percentageCanvas, {
            type: "bar",
            data: { labels: tickers, datasets: [{
                label: "Rentabilidade estimada",
                data: percentages,
                backgroundColor: percentages.map(value => value >= 0 ? "#00A86B" : "#C8755D"),
                borderRadius: 6,
                borderSkipped: false,
                maxBarThickness: 34
            }] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label(context) { return percent(context.raw); } } }
                },
                scales: {
                    x: { grid: { color: "#EDF1EE" }, ticks: { color: "#718078", callback: value => percent(value) } },
                    y: { grid: { display: false }, ticks: { color: "#52645A" } }
                }
            }
        });
    }

    function horizontalBarOptions(formatter) {
        return {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: "y",
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label(context) { return formatter(context.raw); } } }
            },
            scales: {
                x: { grid: { color: "#EDF1EE" }, ticks: { color: "#718078", callback: value => formatter(value) } },
                y: { grid: { display: false }, ticks: { color: "#52645A" } }
            }
        };
    }
})();
