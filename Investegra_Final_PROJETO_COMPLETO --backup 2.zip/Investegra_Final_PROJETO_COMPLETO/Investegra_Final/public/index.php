<?php

session_start();

define(
    "BASE_URL",
    rtrim(
        str_replace(
            "\\",
            "/",
            dirname($_SERVER["SCRIPT_NAME"])
        ),
        "/"
    )
);

require_once dirname(__DIR__)
    . "/app/core/Autoload.php";

use App\Core\Router;

$router = require dirname(__DIR__)
    . "/routes/web.php";

$router->executar();
