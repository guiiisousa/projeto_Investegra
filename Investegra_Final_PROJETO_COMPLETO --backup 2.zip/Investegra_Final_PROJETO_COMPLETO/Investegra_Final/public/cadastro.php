<?php
$_SERVER["REQUEST_URI"] = rtrim(dirname($_SERVER["SCRIPT_NAME"] ?? ""), "/\\") . "/cadastro";
require __DIR__ . "/index.php";
