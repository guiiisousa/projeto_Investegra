<?php

use App\Core\Database;
use App\Services\HistoricoPatrimonioService;

require_once dirname(__DIR__) . "/app/core/Autoload.php";

date_default_timezone_set("America/Sao_Paulo");

try {
    $conexao = Database::conectar();

    $resultado = $conexao->query(
        "SELECT id FROM usuarios ORDER BY id ASC"
    );

    if (!$resultado) {
        throw new RuntimeException(
            "Não foi possível consultar os usuários."
        );
    }

    $totalUsuarios = 0;
    $totalSucessos = 0;
    $totalFalhas = 0;

    $servico = new HistoricoPatrimonioService();

    while ($usuario = $resultado->fetch_assoc()) {
        $usuarioId = (int) $usuario["id"];

        $totalUsuarios++;

        $registro = $servico->registrarPatrimonioUsuario(
            $usuarioId
        );

        if (!empty($registro["sucesso"])) {
            $totalSucessos++;

            echo "[SUCESSO] Usuário {$usuarioId}: "
                . ($registro["mensagem"] ?? "Registro concluído.")
                . PHP_EOL;
        } else {
            $totalFalhas++;

            echo "[FALHA] Usuário {$usuarioId}: "
                . ($registro["mensagem"] ?? "Registro não concluído.")
                . PHP_EOL;
        }
    }

    $resultado->free();

    echo PHP_EOL;
    echo "Execução finalizada." . PHP_EOL;
    echo "Usuários processados: {$totalUsuarios}" . PHP_EOL;
    echo "Registros concluídos: {$totalSucessos}" . PHP_EOL;
    echo "Falhas: {$totalFalhas}" . PHP_EOL;

    $conexao->close();

} catch (Throwable $erro) {
    error_log(
        "Erro no registro diário do INVESTEGRA: "
        . $erro->getMessage()
    );

    fwrite(
        STDERR,
        "Erro ao executar o registro diário. "
        . "Consulte o log de erros do PHP."
        . PHP_EOL
    );

    exit(1);
}
