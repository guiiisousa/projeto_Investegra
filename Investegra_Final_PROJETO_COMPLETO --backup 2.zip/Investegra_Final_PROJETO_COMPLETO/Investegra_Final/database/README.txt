O banco de dados é entregue em arquivo separado: Investegra_Final_database.sql.
Importe-o pelo phpMyAdmin conforme LEIA-ME.txt.
