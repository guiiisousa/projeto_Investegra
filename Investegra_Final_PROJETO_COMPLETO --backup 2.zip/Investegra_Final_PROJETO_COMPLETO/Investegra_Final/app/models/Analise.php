<?php

namespace App\Models;

use App\Core\Database;
use mysqli;

class Analise
{
    private mysqli $conexao;

    public function __construct()
    {
        $this->conexao = Database::conectar();
    }

    public function distribuicaoPorCategoria(int $usuarioId): array
    {
        $sql = "
            SELECT
                COALESCE(cat.nome, 'Sem categoria') AS categoria,
                SUM(a.quantidade * a.preco_medio) AS total_investido
            FROM ativos a
            INNER JOIN carteiras c
                ON c.id = a.carteira_id
            LEFT JOIN categorias cat
                ON cat.id = a.categoria_id
            WHERE c.usuario_id = ?
            GROUP BY COALESCE(cat.nome, 'Sem categoria')
            ORDER BY total_investido DESC
        ";

        $stmt = $this->conexao->prepare($sql);
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $categorias = [];

        while ($linha = $resultado->fetch_assoc()) {
            $categorias[] = [
                "categoria" => $linha["categoria"],
                "total_investido" => (float) $linha["total_investido"],
            ];
        }

        $stmt->close();

        return $categorias;
    }
}
