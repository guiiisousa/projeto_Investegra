<?php

namespace App\Models;

use App\Core\Database;

class Ativo
{
    /**
     * Lista os ativos de uma carteira,
     * garantindo que ela pertença ao usuário.
     */
    public function listarPorCarteiraEUsuario(
        int $carteiraId,
        int $usuarioId
    ): array {
        $conexao = Database::conectar();

        $sql = "
            SELECT
                a.id,
                a.carteira_id,
                a.categoria_id,
                a.ticker,
                a.quantidade,
                a.preco_medio,
                a.data_compra,
                a.observacao,
                c.nome AS categoria
            FROM ativos a
            INNER JOIN carteiras ca
                ON ca.id = a.carteira_id
            LEFT JOIN categorias c
                ON c.id = a.categoria_id
            WHERE a.carteira_id = ?
              AND ca.usuario_id = ?
            ORDER BY a.id DESC
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $carteiraId, $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $ativos = $resultado->fetch_all(MYSQLI_ASSOC);

        $stmt->close();

        return $ativos;
    }

    /**
     * Busca um ativo pelo ID,
     * verificando se pertence ao usuário.
     */
    public function buscarPorIdEUsuario(
        int $id,
        int $usuarioId
    ): ?array {
        $conexao = Database::conectar();

        $sql = "
            SELECT
                a.id,
                a.carteira_id,
                a.categoria_id,
                a.ticker,
                a.quantidade,
                a.preco_medio,
                a.data_compra,
                a.observacao
            FROM ativos a
            INNER JOIN carteiras ca
                ON ca.id = a.carteira_id
            WHERE a.id = ?
              AND ca.usuario_id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id, $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $ativo = $resultado->fetch_assoc();

        $stmt->close();

        return $ativo ?: null;
    }

    /**
     * Retorna as categorias disponíveis.
     */
    public function listarCategorias(): array
    {
        $conexao = Database::conectar();

        $sql = "
            SELECT id, nome
            FROM categorias
            ORDER BY nome ASC
        ";

        $resultado = $conexao->query($sql);
        $categorias = $resultado->fetch_all(MYSQLI_ASSOC);

        $resultado->free();

        return $categorias;
    }

    /**
     * Verifica se a carteira pertence ao usuário.
     */
    public function carteiraPertenceAoUsuario(
        int $carteiraId,
        int $usuarioId
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            SELECT id
            FROM carteiras
            WHERE id = ?
              AND usuario_id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $carteiraId, $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $existe = $resultado->num_rows > 0;

        $stmt->close();

        return $existe;
    }

    /**
     * Cadastra um ativo somente se a carteira
     * pertencer ao usuário informado.
     *
     * Retorna o ID criado ou 0 se não inserir.
     */
    public function criar(
        int $carteiraId,
        int $usuarioId,
        ?int $categoriaId,
        string $ticker,
        float $quantidade,
        float $precoMedio,
        ?string $dataCompra,
        ?string $observacao
    ): int {
        $conexao = Database::conectar();

        $sql = "
            INSERT INTO ativos (
                carteira_id,
                categoria_id,
                ticker,
                quantidade,
                preco_medio,
                data_compra,
                observacao
            )
            SELECT ?, ?, ?, ?, ?, ?, ?
            FROM carteiras
            WHERE id = ?
              AND usuario_id = ?
        ";

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            "iisddssii",
            $carteiraId,
            $categoriaId,
            $ticker,
            $quantidade,
            $precoMedio,
            $dataCompra,
            $observacao,
            $carteiraId,
            $usuarioId
        );

        $stmt->execute();

        $id = $stmt->affected_rows > 0
            ? (int) $conexao->insert_id
            : 0;

        $stmt->close();

        return $id;
    }

    /**
     * Atualiza um ativo que pertence ao usuário.
     */
    public function atualizar(
        int $id,
        int $usuarioId,
        ?int $categoriaId,
        string $ticker,
        float $quantidade,
        float $precoMedio,
        ?string $dataCompra,
        ?string $observacao
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            UPDATE ativos a
            INNER JOIN carteiras ca
                ON ca.id = a.carteira_id
            SET
                a.categoria_id = ?,
                a.ticker = ?,
                a.quantidade = ?,
                a.preco_medio = ?,
                a.data_compra = ?,
                a.observacao = ?
            WHERE a.id = ?
              AND ca.usuario_id = ?
        ";

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            "isddssii",
            $categoriaId,
            $ticker,
            $quantidade,
            $precoMedio,
            $dataCompra,
            $observacao,
            $id,
            $usuarioId
        );

        $executou = $stmt->execute();

        $stmt->close();

        return $executou;
    }

    /**
     * Exclui um ativo somente se ele pertencer
     * ao usuário informado.
     */
    public function excluir(
        int $id,
        int $usuarioId
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            DELETE a
            FROM ativos a
            INNER JOIN carteiras ca
                ON ca.id = a.carteira_id
            WHERE a.id = ?
              AND ca.usuario_id = ?
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id, $usuarioId);
        $stmt->execute();

        $excluiu = $stmt->affected_rows > 0;

        $stmt->close();

        return $excluiu;
    }
}
