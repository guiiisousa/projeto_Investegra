<?php

namespace App\Models;

use App\Core\Database;

class Usuario
{
    public function buscarPorEmail(string $email): ?array
    {
        $conexao = Database::conectar();

        $sql = "
            SELECT id, nome, email, senha
            FROM usuarios
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $usuario = $resultado->fetch_assoc();

        $stmt->close();

        return $usuario ?: null;
    }

    public function autenticar(
        string $email,
        string $senha
    ): ?array {
        $usuario = $this->buscarPorEmail($email);

        if (!$usuario) {
            return null;
        }

        if (!password_verify($senha, $usuario["senha"])) {
            return null;
        }

        unset($usuario["senha"]);

        return $usuario;
    }

    public function emailExiste(string $email): bool
    {
        return $this->buscarPorEmail($email) !== null;
    }

    public function cadastrar(
        string $nome,
        string $email,
        string $documento,
        string $senha,
        string $tipoUsuario = "PF"
    ): int {
        if (!in_array($tipoUsuario, ["PF", "PJ"], true)) {
            throw new \InvalidArgumentException(
                "Tipo de usuário inválido."
            );
        }

        $conexao = Database::conectar();

        $senhaHash = password_hash(
            $senha,
            PASSWORD_DEFAULT
        );

        $sql = "
            INSERT INTO usuarios (
                nome,
                email,
                documento,
                senha,
                tipo_usuario
            )
            VALUES (?, ?, ?, ?, ?)
        ";

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            "sssss",
            $nome,
            $email,
            $documento,
            $senhaHash,
            $tipoUsuario
        );

        $stmt->execute();

        $id = (int) $conexao->insert_id;

        $stmt->close();

        return $id;
    }

    public function documentoExiste(
        string $documento
    ): bool {
        $conexao = Database::conectar();

        $documentoNormalizado = strtoupper(
            preg_replace('/[^A-Za-z0-9]/', '', $documento)
        );

        $sql = "
            SELECT id
            FROM usuarios
            WHERE UPPER(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(documento, '.', ''),
                            '-', ''
                        ),
                        '/',
                        ''
                    ),
                    ' ',
                    ''
                )
            ) = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $documentoNormalizado);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $existe = $resultado->num_rows > 0;

        $stmt->close();

        return $existe;
    }

    public function buscarPerfilPorId(int $id): ?array
    {
        $conexao = Database::conectar();

        $sql = "
            SELECT
                id,
                nome,
                email,
                documento,
                tipo_usuario,
                idade,
                experiencia,
                renda_mensal,
                horizonte_investimento,
                tolerancia_risco,
                objetivo,
                descricao_pessoal,
                score_risco,
                perfil_risco,
                analise_ia,
                criado_em
            FROM usuarios
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $usuario = $resultado->fetch_assoc();

        $stmt->close();

        return $usuario ?: null;
    }

    public function emailEmUsoPorOutroUsuario(
        string $email,
        int $id
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            SELECT id
            FROM usuarios
            WHERE email = ?
              AND id <> ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("si", $email, $id);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $existe = $resultado->num_rows > 0;

        $stmt->close();

        return $existe;
    }

    public function atualizarPerfil(
        int $id,
        string $nome,
        string $email,
        ?int $idade,
        ?string $experiencia,
        ?float $rendaMensal,
        ?string $horizonte,
        ?string $toleranciaRisco,
        ?string $objetivo,
        ?string $descricao
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            UPDATE usuarios
            SET
                nome = ?,
                email = ?,
                idade = ?,
                experiencia = ?,
                renda_mensal = ?,
                horizonte_investimento = ?,
                tolerancia_risco = ?,
                objetivo = ?,
                descricao_pessoal = ?
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            "ssisdssssi",
            $nome,
            $email,
            $idade,
            $experiencia,
            $rendaMensal,
            $horizonte,
            $toleranciaRisco,
            $objetivo,
            $descricao,
            $id
        );

        $sucesso = $stmt->execute();

        $stmt->close();

        return $sucesso;
    }

    public function salvarResultadoRisco(
        int $usuarioId,
        int $score,
        string $perfil
    ): bool {
        $perfisPermitidos = [
            "Conservador",
            "Moderado",
            "Arrojado"
        ];

        if (
            $score < 0 ||
            $score > 12 ||
            !in_array($perfil, $perfisPermitidos, true)
        ) {
            return false;
        }

        $conexao = Database::conectar();

        $sql = "
            UPDATE usuarios
            SET
                score_risco = ?,
                perfil_risco = ?
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("isi", $score, $perfil, $usuarioId);

        $sucesso = $stmt->execute();

        $stmt->close();

        return $sucesso;
    }
}
