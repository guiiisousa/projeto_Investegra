<?php

namespace App\Models;

use App\Core\Database;

class Carteira
{
    /**
     * Lista somente as carteiras do usuário autenticado.
     */
    public function listarPorUsuario(int $usuarioId): array
    {
        $conexao = Database::conectar();

        $sql = "
            SELECT id, nome, descricao, usuario_id, criado_em
            FROM carteiras
            WHERE usuario_id = ?
            ORDER BY criado_em DESC
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $carteiras = $resultado->fetch_all(MYSQLI_ASSOC);

        $stmt->close();

        return $carteiras;
    }

    /**
     * Busca uma carteira pertencente ao usuário.
     */
    public function buscarPorIdEUsuario(
        int $id,
        int $usuarioId
    ): ?array {
        $conexao = Database::conectar();

        $sql = "
            SELECT id, nome, descricao, usuario_id, criado_em
            FROM carteiras
            WHERE id = ? AND usuario_id = ?
            LIMIT 1
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id, $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $carteira = $resultado->fetch_assoc();

        $stmt->close();

        return $carteira ?: null;
    }

    /**
     * Cria uma carteira para o usuário.
     */
    public function criar(
        string $nome,
        ?string $descricao,
        int $usuarioId
    ): int {
        $conexao = Database::conectar();

        $sql = "
            INSERT INTO carteiras (
                nome,
                descricao,
                usuario_id
            )
            VALUES (?, ?, ?)
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param(
            "ssi",
            $nome,
            $descricao,
            $usuarioId
        );

        $stmt->execute();

        $id = (int) $conexao->insert_id;

        $stmt->close();

        return $id;
    }

    /**
     * Atualiza uma carteira somente se ela pertencer
     * ao usuário informado.
     */
    public function atualizar(
        int $id,
        int $usuarioId,
        string $nome,
        ?string $descricao
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            UPDATE carteiras
            SET nome = ?, descricao = ?
            WHERE id = ? AND usuario_id = ?
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param(
            "ssii",
            $nome,
            $descricao,
            $id,
            $usuarioId
        );

        $stmt->execute();

        $atualizou = $stmt->affected_rows > 0;

        $stmt->close();

        return $atualizou;
    }

    /**
     * Exclui uma carteira somente se ela pertencer
     * ao usuário informado.
     */
    public function excluir(
        int $id,
        int $usuarioId
    ): bool {
        $conexao = Database::conectar();

        $sql = "
            DELETE FROM carteiras
            WHERE id = ? AND usuario_id = ?
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id, $usuarioId);
        $stmt->execute();

        $excluiu = $stmt->affected_rows > 0;

        $stmt->close();

        return $excluiu;
    }
}
