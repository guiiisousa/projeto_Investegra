<?php

namespace App\Models;

use App\Core\Database;
use mysqli;

class HistoricoPatrimonio
{
    private mysqli $conexao;

    public function __construct()
    {
        $this->conexao = Database::conectar();
    }

    /**
     * Salva o patrimônio do usuário.
     * Se já existir um registro hoje, atualiza seu valor.
     */
    public function registrarOuAtualizar(
        int $usuarioId,
        float $valorTotal
    ): bool {
        $sqlBusca = "
            SELECT id
            FROM historico_patrimonio
            WHERE usuario_id = ?
              AND data_registro >= CURDATE()
              AND data_registro < CURDATE() + INTERVAL 1 DAY
            LIMIT 1
        ";

        $stmt = $this->conexao->prepare($sqlBusca);
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $registro = $resultado->fetch_assoc();

        $stmt->close();

        if ($registro) {
            $sql = "
                UPDATE historico_patrimonio
                SET valor_total = ?
                WHERE id = ?
                  AND usuario_id = ?
            ";

            $stmt = $this->conexao->prepare($sql);

            $id = (int) $registro["id"];

            $stmt->bind_param(
                "dii",
                $valorTotal,
                $id,
                $usuarioId
            );
        } else {
            $sql = "
                INSERT INTO historico_patrimonio
                    (usuario_id, valor_total)
                VALUES (?, ?)
            ";

            $stmt = $this->conexao->prepare($sql);

            $stmt->bind_param(
                "id",
                $usuarioId,
                $valorTotal
            );
        }

        $sucesso = $stmt->execute();

        $stmt->close();

        return $sucesso;
    }

    /**
     * Retorna o histórico de um usuário,
     * do registro mais antigo para o mais recente.
     */
    public function listarPorUsuario(int $usuarioId): array
    {
        $sql = "
            SELECT
                id,
                valor_total,
                data_registro
            FROM historico_patrimonio
            WHERE usuario_id = ?
            ORDER BY data_registro ASC
        ";

        $stmt = $this->conexao->prepare($sql);
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $historico = [];

        while ($linha = $resultado->fetch_assoc()) {
            $historico[] = [
                "id" => (int) $linha["id"],
                "valor_total" => (float) $linha["valor_total"],
                "data_registro" => $linha["data_registro"]
            ];
        }

        $stmt->close();

        return $historico;
    }
}
