<?php
namespace App\Models;

use App\Core\Database;

class Simulacao
{
    public function salvar(int $usuarioId, string $tipo, float $capital, float $aporte, float $taxa, int $meses, float $montante, ?string $ticker = null, ?float $precoReferencia = null, ?string $cenario = null): int
    {
        $db = Database::conectar();
        $tipoJuros = $tipo === 'juros_simples' ? 'simples' : 'compostos';
        $tipoSimulacao = $tipo === 'ativo' ? 'ativo' : 'juros';
        $prazoAnos = max(1, (int) ceil($meses / 12));
        $sql = "INSERT INTO simulacoes
            (usuario_id, tipo_juros, aporte_inicial, aporte_mensal, rentabilidade, prazo_anos, montante,
             tipo_simulacao, ticker, preco_referencia, cenario)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $stmt->bind_param('isdddidssds', $usuarioId, $tipoJuros, $capital, $aporte, $taxa, $prazoAnos, $montante, $tipoSimulacao, $ticker, $precoReferencia, $cenario);
        $stmt->execute();
        $id = (int)$db->insert_id;
        $stmt->close();
        return $id;
    }

    public function listarPorUsuario(int $usuarioId): array
    {
        $db = Database::conectar();
        $sql = "SELECT id, tipo_juros, tipo_simulacao, ticker, preco_referencia, cenario,
                       aporte_inicial, aporte_mensal, rentabilidade, prazo_anos, montante, criado_em
                FROM simulacoes WHERE usuario_id = ? ORDER BY criado_em DESC, id DESC LIMIT 30";
        $stmt = $db->prepare($sql);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }
}
