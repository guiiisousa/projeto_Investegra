<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | INVESTEGRA</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/css/style.css">
</head>
<body>
    <main class="login-container">
        <h1>INVESTEGRA</h1>
        <p class="subtitulo">Entre na sua conta</p>

        <?php if (!empty($erro)): ?>
            <div class="mensagem-erro">
                <?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form
            action="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/login"
            method="POST"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            >

            <label for="email">E-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                autocomplete="username"
                maxlength="150"
                required
            >

            <label for="senha">Senha</label>
            <input
                type="password"
                id="senha"
                name="senha"
                autocomplete="current-password"
                required
            >

            <button type="submit">Entrar</button>
        </form>

        <p class="aviso">
            Ainda não possui uma conta?
            <a href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/cadastro.php">Criar cadastro</a>
        </p>
    </main>
</body>
</html>
