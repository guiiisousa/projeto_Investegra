
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cadastro | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/css/style.css"
    >
</head>
<body>
    <main class="login-container">
        <h1>INVESTEGRA</h1>
        <p class="subtitulo">Crie sua conta</p>

        <?php if (!empty($erro)): ?>
            <div class="mensagem-erro">
                <?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form
            action="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/cadastro"
            method="POST"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            >

            <label for="nome">Nome completo ou razão social</label>
            <input
                type="text"
                id="nome"
                name="nome"
                maxlength="100"
                autocomplete="name"
                value="<?= htmlspecialchars($nome ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="tipo_usuario">Tipo de cadastro</label>
            <select id="tipo_usuario" name="tipo_usuario" required>
                <option value="PF" <?= ($tipoUsuario ?? 'PF') === 'PF' ? 'selected' : '' ?>>
                    Pessoa física (CPF)
                </option>
                <option value="PJ" <?= ($tipoUsuario ?? 'PF') === 'PJ' ? 'selected' : '' ?>>
                    Pessoa jurídica (CNPJ)
                </option>
            </select>

            <label for="documento" id="rotulo-documento">CPF</label>
            <input
                type="text"
                id="documento"
                name="documento"
                maxlength="18"
                autocomplete="off"
                placeholder="000.000.000-00"
                value="<?= htmlspecialchars($documento ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="email">E-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                maxlength="150"
                autocomplete="email"
                value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="senha">Senha</label>
            <input
                type="password"
                id="senha"
                name="senha"
                minlength="8"
                autocomplete="new-password"
                required
            >

            <label for="confirmacao">Confirme sua senha</label>
            <input
                type="password"
                id="confirmacao"
                name="confirmacao"
                minlength="8"
                autocomplete="new-password"
                required
            >

            <button type="submit">Criar conta</button>
        </form>

        <p class="aviso">
            Já possui uma conta?
            <a href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/login">
                Fazer login
            </a>
        </p>
    </main>

    <script>
        const tipoUsuario = document.getElementById("tipo_usuario");
        const documento = document.getElementById("documento");
        const rotuloDocumento = document.getElementById("rotulo-documento");
        const nome = document.getElementById("nome");

        function aplicarMascaraDocumento() {
            const tipo = tipoUsuario.value;

            if (tipo === "PF") {
                rotuloDocumento.textContent = "CPF";
                documento.placeholder = "000.000.000-00";
                nome.setAttribute("autocomplete", "name");

                let valor = documento.value.replace(/\D/g, "").slice(0, 11);

                if (valor.length > 9) {
                    valor = valor.replace(
                        /^(\d{3})(\d{3})(\d{3})(\d{0,2}).*/,
                        "$1.$2.$3-$4"
                    );
                } else if (valor.length > 6) {
                    valor = valor.replace(
                        /^(\d{3})(\d{3})(\d{0,3}).*/,
                        "$1.$2.$3"
                    );
                } else if (valor.length > 3) {
                    valor = valor.replace(
                        /^(\d{3})(\d{0,3}).*/,
                        "$1.$2"
                    );
                }

                documento.value = valor;
            } else {
                rotuloDocumento.textContent = "CNPJ";
                documento.placeholder = "00.AAA.AAA/AAAA-00";
                nome.setAttribute("autocomplete", "organization");

                let valor = documento.value
                    .toUpperCase()
                    .replace(/[^A-Z0-9]/g, "")
                    .slice(0, 14);

                if (valor.length > 12) {
                    valor = valor.replace(
                        /^(.{2})(.{3})(.{3})(.{4})(.{0,2}).*/,
                        "$1.$2.$3/$4-$5"
                    );
                } else if (valor.length > 8) {
                    valor = valor.replace(
                        /^(.{2})(.{3})(.{3})(.*)/,
                        "$1.$2.$3/$4"
                    );
                } else if (valor.length > 5) {
                    valor = valor.replace(
                        /^(.{2})(.{3})(.*)/,
                        "$1.$2.$3"
                    );
                } else if (valor.length > 2) {
                    valor = valor.replace(
                        /^(.{2})(.*)/,
                        "$1.$2"
                    );
                }

                documento.value = valor;
            }
        }

        tipoUsuario.addEventListener("change", () => {
            documento.value = "";
            aplicarMascaraDocumento();
        });

        documento.addEventListener("input", aplicarMascaraDocumento);

        aplicarMascaraDocumento();
    </script>
</body>
</html>
