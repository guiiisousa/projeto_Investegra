<?php

$escapar = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$moeda = static function ($valor) use ($escapar): string {
    return $escapar(
        "R$ " . number_format(
            (float) $valor,
            2,
            ",",
            "."
        )
    );
};

$nomeUsuario = $nomeUsuario ?? "Investidor";
$totalInvestido = (float) ($totalInvestido ?? 0);
$totalMercado = (float) ($totalMercado ?? 0);
$totalResultado = (float) ($totalResultado ?? 0);

$quantidadeCarteiras = (int) ($quantidadeCarteiras ?? 0);
$quantidadeAtivos = (int) ($quantidadeAtivos ?? 0);
$quantidadeCotada = (int) ($quantidadeCotada ?? 0);
$ativosSemCotacao = (int) ($ativosSemCotacao ?? 0);

$distribuicaoCategorias = $distribuicaoCategorias ?? [];
$carteiras = $carteiras ?? [];
$ultimosAtivos = $ultimosAtivos ?? [];

$percentualResultado = $totalInvestido > 0
    ? ($totalResultado / $totalInvestido) * 100
    : 0;

// O controller fornece categoria => valor investido.
$categoriasGrafico = array_keys($distribuicaoCategorias);
$valoresCategoriasGrafico = array_map(
    static fn($valor): float => (float) $valor,
    array_values($distribuicaoCategorias)
);

// O resultado só existe quando a cotação em BRL foi obtida.
$ativosGrafico = array_values(array_filter(
    $ultimosAtivos,
    static fn(array $ativo): bool =>
        isset($ativo["resultado"]) && $ativo["resultado"] !== null
));

usort(
    $ativosGrafico,
    static fn(array $a, array $b): int =>
        abs((float) $b["resultado"]) <=> abs((float) $a["resultado"])
);

$ativosGrafico = array_slice($ativosGrafico, 0, 8);

$tickersGrafico = array_map(
    static fn(array $ativo): string => (string) ($ativo["ticker"] ?? ""),
    $ativosGrafico
);

$resultadosGrafico = array_map(
    static fn(array $ativo): float => (float) $ativo["resultado"],
    $ativosGrafico
);

$valoresInvestidosAtivos = array_map(
    static fn(array $ativo): float => (float) ($ativo["valor_investido"] ?? 0),
    $ativosGrafico
);

$valoresMercadoAtivos = array_map(
    static fn(array $ativo): float => (float) ($ativo["valor_mercado"] ?? 0),
    $ativosGrafico
);

$percentuaisAtivos = array_map(
    static fn(array $ativo): float => (float) ($ativo["resultado_percentual"] ?? 0),
    $ativosGrafico
);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= $escapar(BASE_URL . '/css/style.css') ?>"
    >

    <link
        rel="stylesheet"
        href="<?= $escapar(BASE_URL . '/css/dashboard-charts.css') ?>"
    >

    <script
        src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"
        defer
    ></script>

    <script
        src="<?= $escapar(BASE_URL . '/js/dashboard-charts.js') ?>"
        defer
    ></script>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f7f6;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        a {
            color: inherit;
        }

        .dashboard-layout {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 245px;
            flex-shrink: 0;
            padding: 28px 18px;
            background: #103d2d;
            color: #fff;
            display: flex;
            flex-direction: column;
        }

        .logo {
            margin: 0 0 8px;
            color: #55d69a;
            font-size: 25px;
            font-weight: 800;
            letter-spacing: 1px;
        }

        .logo-descricao {
            margin: 0 0 32px;
            color: #c6ddd1;
            font-size: 12px;
        }

        .menu-titulo {
            margin: 18px 10px 10px;
            color: #a8c7b8;
            font-size: 11px;
            font-weight: bold;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .menu a {
            display: block;
            padding: 12px 13px;
            border-radius: 8px;
            color: #e4f0e9;
            font-size: 14px;
            text-decoration: none;
            transition: background .2s;
        }

        .menu a:hover,
        .menu a.ativo {
            background: #205941;
            color: #fff;
        }

        .menu a.ativo {
            border-left: 3px solid #55d69a;
        }

        .sidebar-rodape {
            margin-top: auto;
            padding-top: 30px;
        }

        .sidebar-rodape form {
            margin: 0;
        }

        .botao-sair {
            width: 100%;
            padding: 12px;
            border: 1px solid #4e7965;
            border-radius: 8px;
            background: transparent;
            color: #fff;
            cursor: pointer;
            text-align: left;
        }

        .botao-sair:hover {
            background: #205941;
        }

        .dashboard-conteudo {
            flex: 1;
            min-width: 0;
            padding: 32px;
        }

        .cabecalho {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        .cabecalho h1 {
            margin: 0 0 8px;
            font-size: 29px;
        }

        .cabecalho p {
            margin: 0;
            color: #718078;
            line-height: 1.5;
        }

        .data-atual {
            color: #718078;
            font-size: 13px;
        }

        .indicadores {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .card {
            min-width: 0;
            padding: 22px;
            border: 1px solid #e5ece8;
            border-radius: 13px;
            background: #fff;
            box-shadow: 0 4px 14px rgba(20, 50, 35, .04);
        }

        .indicador-label {
            display: block;
            margin-bottom: 12px;
            color: #718078;
            font-size: 13px;
        }

        .indicador-valor {
            display: block;
            overflow-wrap: anywhere;
            color: #087c50;
            font-size: 24px;
            font-weight: bold;
        }

        .indicador-detalhe {
            display: block;
            margin-top: 10px;
            color: #718078;
            font-size: 12px;
        }

        .positivo {
            color: #087c50;
        }

        .negativo {
            color: #c0392b;
        }

        .paineis {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
            margin-bottom: 25px;
        }

        .painel-titulo {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 20px;
        }

        .painel-titulo h2 {
            margin: 0;
            font-size: 18px;
        }

        .link-ver-mais {
            color: #087c50;
            font-size: 13px;
            font-weight: bold;
            text-decoration: none;
        }

        .link-ver-mais:hover {
            text-decoration: underline;
        }

        .lista-categorias {
            display: flex;
            flex-direction: column;
            gap: 19px;
        }

        .categoria-cabecalho {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 8px;
            font-size: 13px;
        }

        .categoria-nome {
            font-weight: bold;
        }

        .categoria-valor {
            color: #718078;
        }

        .barra-fundo {
            height: 9px;
            overflow: hidden;
            border-radius: 20px;
            background: #e9f0ec;
        }

        .barra-progresso {
            height: 100%;
            border-radius: 20px;
            background: #00a86b;
        }

        .lista-carteiras {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .carteira-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 15px;
            border: 1px solid #e9efeb;
            border-radius: 9px;
        }

        .carteira-item h3 {
            margin: 0 0 6px;
            font-size: 15px;
        }

        .carteira-item p {
            margin: 0;
            color: #718078;
            font-size: 12px;
            line-height: 1.5;
        }

        .botao-pequeno {
            display: inline-block;
            padding: 9px 12px;
            border-radius: 7px;
            background: #e7f7ed;
            color: #087c50;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            white-space: nowrap;
        }

        .botao-pequeno:hover {
            background: #d4efdf;
        }

        .tabela-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 620px;
        }

        th,
        td {
            padding: 14px 12px;
            border-bottom: 1px solid #e9efeb;
            text-align: left;
        }

        th {
            background: #f8faf9;
            color: #718078;
            font-size: 12px;
        }

        td {
            font-size: 13px;
        }

        .ticker {
            color: #087c50;
            font-weight: bold;
        }

        .estado-vazio {
            padding: 24px 12px;
            color: #718078;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
        }

        .atalhos {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .atalho {
            display: block;
            padding: 20px;
            border: 1px solid #e5ece8;
            border-radius: 12px;
            background: #fff;
            text-decoration: none;
            transition: transform .2s, box-shadow .2s;
        }

        .atalho:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(20, 50, 35, .08);
        }

        .atalho h3 {
            margin: 0 0 8px;
            color: #087c50;
            font-size: 16px;
        }

        .atalho p {
            margin: 0;
            color: #718078;
            font-size: 13px;
            line-height: 1.6;
        }

        .aviso-cotacao {
            margin-bottom: 22px;
            padding: 13px 16px;
            border-radius: 8px;
            background: #fff7e6;
            color: #795b18;
            font-size: 13px;
            line-height: 1.6;
        }

        @media (max-width: 1150px) {
            .indicadores {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .dashboard-conteudo {
                padding: 24px;
            }
        }

        @media (max-width: 850px) {
            .dashboard-layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding: 20px;
            }

            .logo-descricao {
                margin-bottom: 18px;
            }

            .menu {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .menu-titulo {
                margin-top: 12px;
            }

            .sidebar-rodape {
                margin-top: 18px;
                padding-top: 0;
            }

            .paineis {
                grid-template-columns: 1fr;
            }

            .atalhos {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 520px) {
            .dashboard-conteudo {
                padding: 16px;
            }

            .indicadores {
                grid-template-columns: 1fr;
            }

            .cabecalho h1 {
                font-size: 24px;
            }

            .card {
                padding: 17px;
            }

            .menu {
                grid-template-columns: 1fr;
            }
        }

    </style>
</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div>
            <div class="logo">INVESTEGRA</div>

            <p class="logo-descricao">
                Gestão inteligente de investimentos
            </p>
        </div>

        <span class="menu-titulo">Menu principal</span>

        <nav class="menu">
            <a class="ativo" href="<?= $escapar(BASE_URL . '/dashboard') ?>">
                Dashboard
            </a>

            <a href="<?= $escapar(BASE_URL . '/carteiras') ?>">
                Carteiras
            </a>

            <a href="<?= $escapar(BASE_URL . '/ativos') ?>">
                Ativos
            </a>

            <a href="<?= $escapar(BASE_URL . '/simulacoes') ?>">
                Simulações
            </a>

            <a href="<?= $escapar(BASE_URL . '/analises') ?>">
                Análises
            </a>


        <a href="<?= htmlspecialchars(BASE_URL . '/chat') ?>">
            Assistente IA
        </a>

        </nav>

        <span class="menu-titulo">Conta</span>

        <nav class="menu">
            <a href="<?= $escapar(BASE_URL . '/perfil') ?>">
                Perfil
            </a>

            <a href="<?= $escapar(BASE_URL . '/questionario') ?>">
                Quiz de perfil de investidor
            </a>
        </nav>

        <div class="sidebar-rodape">
            <form
                action="<?= $escapar(BASE_URL . '/logout') ?>"
                method="POST"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= $escapar($csrfToken ?? '') ?>"
                >

                <button class="botao-sair" type="submit">
                    Sair da conta
                </button>
            </form>
        </div>

    </aside>

    <main class="dashboard-conteudo">

        <header class="cabecalho">
            <div>
                <h1>
                    Olá, <?= $escapar($nomeUsuario) ?>!
                </h1>

                <p>
                    Acompanhe seus investimentos e a situação
                    das suas carteiras.
                </p>
            </div>

            <span class="data-atual">
                <?= $escapar(date('d/m/Y')) ?>
            </span>
        </header>

        <?php if ($ativosSemCotacao > 0): ?>
            <div class="aviso-cotacao">
                <?= $ativosSemCotacao ?> ativo(s) estão sem cotação
                disponível. O valor de mercado pode estar incompleto.
            </div>
        <?php endif; ?>

        <section class="indicadores">

            <article class="card">
                <span class="indicador-label">
                    Total investido
                </span>

                <strong class="indicador-valor">
                    <?= $moeda($totalInvestido) ?>
                </strong>

                <span class="indicador-detalhe">
                    Calculado pelo preço médio de aquisição
                </span>
            </article>

            <article class="card">
                <span class="indicador-label">
                    Valor de mercado
                </span>

                <strong class="indicador-valor">
                    <?= $moeda($totalMercado) ?>
                </strong>

                <span class="indicador-detalhe">
                    Baseado nas cotações disponíveis
                </span>
            </article>

            <article class="card">
                <span class="indicador-label">
                    Resultado estimado
                </span>

                <strong class="indicador-valor <?= $totalResultado >= 0 ? 'positivo' : 'negativo' ?>">
                    <?= $moeda($totalResultado) ?>
                </strong>

                <span class="indicador-detalhe">
                    <?= number_format(
                        $percentualResultado,
                        2,
                        ',',
                        '.'
                    ) ?>% sobre o valor investido
                </span>
            </article>

            <article class="card">
                <span class="indicador-label">
                    Ativos cadastrados
                </span>

                <strong class="indicador-valor">
                    <?= $quantidadeAtivos ?>
                </strong>

                <span class="indicador-detalhe">
                    <?= $quantidadeCotada ?> com cotação disponível
                </span>
            </article>

        </section>

        <section class="atalhos">

            <a
                class="atalho"
                href="<?= $escapar(BASE_URL . '/carteiras') ?>"
            >
                <h3>Minhas carteiras</h3>

                <p>
                    <?= $quantidadeCarteiras ?>
                    carteira(s) cadastrada(s).
                    Gerencie seus investimentos.
                </p>
            </a>

            <a
                class="atalho"
                href="<?= $escapar(BASE_URL . '/simulacoes') ?>"
            >
                <h3>Simular investimentos</h3>

                <p>
                    Projete o crescimento do seu patrimônio
                    com aportes e taxas estimadas.
                </p>
            </a>

            <a
                class="atalho"
                href="<?= $escapar(BASE_URL . '/analises') ?>"
            >
                <h3>Análises financeiras</h3>

                <p>
                    Consulte a distribuição dos investimentos
                    e o histórico patrimonial.
                </p>
            </a>

            <a
                class="atalho"
                href="<?= $escapar(BASE_URL . '/questionario') ?>"
            >
                <h3>Quiz: perfil de investidor</h3>

                <p>
                    Responda ao questionário para conhecer sua
                    tolerância a riscos e seu perfil indicativo.
                </p>
            </a>

        </section>

        <section class="paineis">

            <article class="card">

                <div class="painel-titulo">
                    <h2>Distribuição por categoria</h2>

                    <a
                        class="link-ver-mais"
                        href="<?= $escapar(BASE_URL . '/analises') ?>"
                    >
                        Ver análises
                    </a>
                </div>

                <?php if (!empty($categoriasGrafico)): ?>

                    <div class="dashboard-chart-container dashboard-chart-container-doughnut">
                        <canvas
                            id="graficoCategorias"
                            aria-label="Distribuição do valor investido por categoria"
                        ></canvas>
                    </div>

                <?php else: ?>

                    <div class="estado-vazio">
                        Ainda não há investimentos suficientes
                        para apresentar a distribuição.
                    </div>

                <?php endif; ?>

            </article>

            <article class="card">

                <div class="painel-titulo">
                    <h2>Minhas carteiras</h2>

                    <a
                        class="link-ver-mais"
                        href="<?= $escapar(BASE_URL . '/carteiras') ?>"
                    >
                        Ver todas
                    </a>
                </div>

                <?php if (!empty($carteiras)): ?>

                    <div class="lista-carteiras">

                        <?php foreach (array_slice($carteiras, 0, 5) as $carteira): ?>

                            <div class="carteira-item">

                                <div>
                                    <h3>
                                        <?= $escapar($carteira["nome"] ?? "Carteira") ?>
                                    </h3>

                                    <p>
                                        <?= $escapar(
                                            $carteira["descricao"]
                                            ?? "Sem descrição"
                                        ) ?>
                                    </p>
                                </div>

                                <a
                                    class="botao-pequeno"
                                    href="<?= $escapar(
                                        BASE_URL . '/ativos?carteira='
                                        . (int) ($carteira["id"] ?? 0)
                                    ) ?>"
                                >
                                    Ver ativos
                                </a>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php else: ?>

                    <div class="estado-vazio">
                        Você ainda não possui carteiras cadastradas.

                        <p>
                            <a
                                class="link-ver-mais"
                                href="<?= $escapar(BASE_URL . '/carteiras') ?>"
                            >
                                Criar minha primeira carteira
                            </a>
                        </p>
                    </div>

                <?php endif; ?>

            </article>

        </section>

        <section class="card dashboard-performance-card">

            <div class="painel-titulo">
                <div>
                    <h2>Resultado estimado por ativo</h2>
                    <p class="dashboard-chart-description">
                        Diferença entre valor de mercado e valor investido,
                        considerando apenas cotações disponíveis em reais.
                    </p>
                </div>

                <a
                    class="link-ver-mais"
                    href="<?= $escapar(BASE_URL . '/analises') ?>"
                >
                    Ver análises
                </a>
            </div>

            <?php if (!empty($tickersGrafico)): ?>

                <div class="dashboard-chart-container dashboard-chart-container-bars">
                    <canvas
                        id="graficoDesempenho"
                        aria-label="Resultado estimado por ativo"
                    ></canvas>
                </div>

            <?php else: ?>

                <div class="estado-vazio">
                    Ainda não existem cotações válidas suficientes
                    para comparar o desempenho dos ativos.
                </div>

            <?php endif; ?>

        </section>

        <section class="paineis paineis-graficos-detalhados">

            <article class="card dashboard-performance-card">
                <div class="painel-titulo">
                    <div>
                        <h2>Capital aplicado x valor de mercado</h2>
                        <p class="dashboard-chart-description">
                            Compara quanto foi aplicado em cada ativo com seu valor estimado pelas cotações atuais em BRL.
                        </p>
                    </div>
                </div>

                <?php if (!empty($tickersGrafico)): ?>
                    <div class="dashboard-chart-container dashboard-chart-container-comparison">
                        <canvas id="graficoInvestidoMercado" aria-label="Comparação entre capital aplicado e valor de mercado por ativo"></canvas>
                    </div>
                <?php else: ?>
                    <div class="estado-vazio">Não há ativos com cotação em reais para esta comparação.</div>
                <?php endif; ?>
            </article>

            <article class="card dashboard-performance-card">
                <div class="painel-titulo">
                    <div>
                        <h2>Rentabilidade percentual por ativo</h2>
                        <p class="dashboard-chart-description">
                            Mostra a variação percentual estimada de cada ativo em relação ao seu custo de aquisição.
                        </p>
                    </div>
                </div>

                <?php if (!empty($tickersGrafico)): ?>
                    <div class="dashboard-chart-container dashboard-chart-container-bars">
                        <canvas id="graficoRentabilidadePercentual" aria-label="Rentabilidade percentual estimada por ativo"></canvas>
                    </div>
                <?php else: ?>
                    <div class="estado-vazio">Não há dados de cotação suficientes para calcular a rentabilidade percentual.</div>
                <?php endif; ?>
            </article>

        </section>

        <section class="card">

            <div class="painel-titulo">
                <h2>Ativos recentes</h2>

                <a
                    class="link-ver-mais"
                    href="<?= $escapar(BASE_URL . '/ativos') ?>"
                >
                    Ver ativos
                </a>
            </div>

            <?php if (!empty($ultimosAtivos)): ?>

                <div class="tabela-wrapper">

                    <table>
                        <thead>
                            <tr>
                                <th>Ticker</th>
                                <th>Categoria</th>
                                <th>Quantidade</th>
                                <th>Preço médio</th>
                                <th>Valor investido</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach (array_slice($ultimosAtivos, 0, 8) as $ativo): ?>

                                <?php
                                $ticker = $ativo["ticker"] ?? "—";

                                $categoriaAtivo =
                                    $ativo["categoria"]
                                    ?? $ativo["categoria_nome"]
                                    ?? $ativo["nome_categoria"]
                                    ?? "Não informada";

                                $quantidade = (float) (
                                    $ativo["quantidade"] ?? 0
                                );

                                $precoMedio = (float) (
                                    $ativo["preco_medio"] ?? 0
                                );

                                $valorAtivo = $quantidade * $precoMedio;
                                ?>

                                <tr>
                                    <td class="ticker">
                                        <?= $escapar($ticker) ?>
                                    </td>

                                    <td>
                                        <?= $escapar($categoriaAtivo) ?>
                                    </td>

                                    <td>
                                        <?= number_format(
                                            $quantidade,
                                            4,
                                            ',',
                                            '.'
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= $moeda($precoMedio) ?>
                                    </td>

                                    <td>
                                        <?= $moeda($valorAtivo) ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

            <?php else: ?>

                <div class="estado-vazio">
                    Nenhum ativo foi encontrado.

                    <p>
                        Cadastre ativos em uma das suas carteiras
                        para visualizar os dados aqui.
                    </p>

                    <a
                        class="botao-pequeno"
                        href="<?= $escapar(BASE_URL . '/carteiras') ?>"
                    >
                        Acessar carteiras
                    </a>
                </div>

            <?php endif; ?>

        </section>




    </main>

</div>

<script
    id="dashboard-chart-data"
    type="application/json"
><?= json_encode(
    [
        "categorias" => $categoriasGrafico,
        "valoresCategorias" => $valoresCategoriasGrafico,
        "tickers" => $tickersGrafico,
        "resultados" => $resultadosGrafico,
        "valoresInvestidosAtivos" => $valoresInvestidosAtivos,
        "valoresMercadoAtivos" => $valoresMercadoAtivos,
        "percentuaisAtivos" => $percentuaisAtivos
    ],
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?></script>

</body>
</html>
