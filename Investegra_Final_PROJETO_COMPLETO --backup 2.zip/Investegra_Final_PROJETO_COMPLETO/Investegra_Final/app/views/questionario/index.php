<?php

$escapar = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$erroSessao = $_SESSION["questionario_erro"] ?? null;
unset($_SESSION["questionario_erro"]);

$perfis = [
    "Conservador" => [
        "descricao" => "Você demonstra preferência por preservar seu patrimônio e limitar oscilações. Considere também inflação, liquidez e objetivos."
    ],
    "Moderado" => [
        "descricao" => "Suas respostas indicam uma busca por equilíbrio entre preservação e crescimento, com alguma disposição para aceitar oscilações."
    ],
    "Arrojado" => [
        "descricao" => "Suas respostas indicam maior disposição para aceitar oscilações em busca de crescimento. Isso não elimina o risco de perdas."
    ]
];

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Perfil de investidor | INVESTEGRA</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 16px;
            background: #f6f8f7;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        .quiz-container {
            width: 100%;
            max-width: 800px;
            margin: auto;
        }

        .quiz-voltar {
            display: inline-block;
            margin-bottom: 22px;
            color: #008653;
            text-decoration: none;
            font-size: 14px;
        }

        .quiz-cabecalho {
            margin-bottom: 24px;
        }

        .quiz-marca {
            margin: 0 0 18px;
            color: #008653;
            font-size: 20px;
            font-weight: 800;
        }

        h1 {
            margin: 0 0 12px;
            color: #20342b;
            font-size: clamp(25px, 4vw, 34px);
        }

        .quiz-subtitulo {
            color: #738078;
            line-height: 1.7;
        }

        .quiz-cartao {
            margin-bottom: 18px;
            padding: 24px;
            border: 1px solid #e4ebe6;
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 5px 18px rgba(20, 50, 35, .03);
        }

        .quiz-pergunta {
            margin: 0 0 18px;
            font-size: 16px;
            line-height: 1.5;
        }

        .quiz-opcao {
            display: flex;
            align-items: flex-start;
            gap: 11px;
            margin-top: 10px;
            padding: 13px;
            border: 1px solid #e1e9e3;
            border-radius: 9px;
            cursor: pointer;
            line-height: 1.5;
        }

        .quiz-opcao:hover {
            background: #f4faf6;
            border-color: #9bd8b6;
        }

        .quiz-opcao input {
            margin-top: 4px;
            accent-color: #008653;
        }

        .quiz-botao {
            display: inline-flex;
            justify-content: center;
            padding: 13px 18px;
            border: 0;
            border-radius: 9px;
            background: #008653;
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .quiz-botao:hover {
            background: #006f44;
        }

        .quiz-secundario {
            border: 1px solid #dce5df;
            background: #fff;
            color: #405047;
        }

        .quiz-alerta {
            margin-bottom: 18px;
            padding: 14px;
            border-radius: 9px;
            background: #fff0f0;
            color: #a52b2b;
        }

        .quiz-resultado {
            padding: 30px;
            border: 1px solid #dcece2;
            border-radius: 16px;
            background: #fff;
        }

        .quiz-perfil {
            display: inline-block;
            margin: 8px 0 14px;
            padding: 8px 12px;
            border-radius: 20px;
            background: #e8f7ee;
            color: #008653;
            font-weight: 700;
        }

        .quiz-nota {
            margin-top: 20px;
            color: #738078;
            font-size: 13px;
            line-height: 1.7;
        }

        .quiz-acoes {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 24px;
        }

        @media (max-width: 500px) {
            .quiz-cartao,
            .quiz-resultado {
                padding: 18px;
            }

            .quiz-acoes .quiz-botao {
                width: 100%;
            }
        }
    </style>
</head>

<body>
<main class="quiz-container">

    <a
        class="quiz-voltar"
        href="<?= $escapar(BASE_URL . '/perfil') ?>"
    >
        ← Voltar ao perfil
    </a>

    <header class="quiz-cabecalho">
        <p class="quiz-marca">INVESTEGRA</p>
        <h1>Descubra seu perfil de investidor</h1>

        <p class="quiz-subtitulo">
            Responda seis perguntas sobre seus objetivos e sua
            tolerância a oscilações. O questionário é opcional e
            pode ser refeito a qualquer momento.
        </p>
    </header>

    <?php if ($erroSessao): ?>
        <div class="quiz-alerta">
            <?= $escapar($erroSessao) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($erro)): ?>
        <div class="quiz-alerta">
            <?= $escapar($erro) ?>
        </div>
    <?php endif; ?>

    <?php if ($resultado !== null): ?>

        <?php
        $perfilAtual = $resultado["perfil"];
        $informacao = $perfis[$perfilAtual]
            ?? $perfis["Moderado"];
        ?>

        <section class="quiz-resultado">
            <h2>Seu resultado mais recente</h2>

            <div class="quiz-perfil">
                <?= $escapar($perfilAtual) ?>
            </div>

            <p>
                Pontuação: <strong>
                    <?= $escapar($resultado["score"]) ?>/12
                </strong>
            </p>

            <p>
                <?= $escapar($informacao["descricao"]) ?>
            </p>

            <p class="quiz-nota">
                Esta classificação é indicativa e se baseia nas
                respostas fornecidas. Não representa garantia de
                rentabilidade nem recomendação individual de ativos.
                A experiência, isoladamente, não determina sua
                capacidade de suportar perdas.
            </p>

            <div class="quiz-acoes">
                <a
                    class="quiz-botao"
                    href="<?= $escapar(BASE_URL . '/questionario?refazer=1') ?>"
                >
                    Refazer questionário
                </a>

                <a
                    class="quiz-botao quiz-secundario"
                    href="<?= $escapar(BASE_URL . '/perfil') ?>"
                >
                    Voltar ao perfil
                </a>
            </div>
        </section>

    <?php else: ?>

        <form
            method="POST"
            action="<?= $escapar(BASE_URL . '/questionario/salvar') ?>"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= $escapar($csrfToken) ?>"
            >

            <?php foreach ($perguntas as $numero => $pergunta): ?>

                <section class="quiz-cartao">
                    <h2 class="quiz-pergunta">
                        <?= $numero ?>.
                        <?= $escapar($pergunta["pergunta"]) ?>
                    </h2>

                    <?php foreach ($pergunta["opcoes"] as $pontos => $texto): ?>
                        <label class="quiz-opcao">
                            <input
                                type="radio"
                                name="q<?= $numero ?>"
                                value="<?= $pontos ?>"
                                required
                            >

                            <span><?= $escapar($texto) ?></span>
                        </label>
                    <?php endforeach; ?>
                </section>

            <?php endforeach; ?>

            <div class="quiz-acoes">
                <button class="quiz-botao" type="submit">
                    Calcular meu perfil
                </button>

                <a
                    class="quiz-botao quiz-secundario"
                    href="<?= $escapar(BASE_URL . '/perfil') ?>"
                >
                    Responder depois
                </a>
            </div>
        </form>

    <?php endif; ?>

</main>
</body>
</html>
