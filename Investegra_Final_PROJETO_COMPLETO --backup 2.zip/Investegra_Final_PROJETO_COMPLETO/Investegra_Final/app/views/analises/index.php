<?php

$categoriasGrafico = array_column(
    $distribuicaoCategorias,
    "categoria"
);

$valoresGrafico = array_map(
    "floatval",
    array_column($distribuicaoCategorias, "total_investido")
);

$percentuaisGrafico = array_map(
    "floatval",
    array_column($distribuicaoCategorias, "percentual")
);

$datasHistorico = array_map(
    function ($registro) {
        return date(
            "d/m/Y",
            strtotime($registro["data_registro"])
        );
    },
    $historicoPatrimonio
);

$valoresHistorico = array_map(
    function ($registro) {
        return (float) $registro["valor_total"];
    },
    $historicoPatrimonio
);

$totalRegistros = count($historicoPatrimonio);
$totalCategorias = count($distribuicaoCategorias);

function formatarMoedaAnalise(float $valor): string
{
    return "R$ " . number_format(
        $valor,
        2,
        ",",
        "."
    );
}

function escaparAnalise($valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES,
        "UTF-8"
    );
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Análises | INVESTEGRA</title>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            background: #f4f7f6;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container {
            width: 100%;
            max-width: 1250px;
            margin: 0 auto;
        }

        .cabecalho {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }

        .cabecalho h1 {
            margin: 0 0 8px;
            color: #087c50;
            font-size: 30px;
        }

        .cabecalho p {
            margin: 0;
            color: #68766e;
            line-height: 1.5;
        }

        .botao-voltar {
            display: inline-block;
            padding: 11px 18px;
            border-radius: 8px;
            background: #087c50;
            color: #ffffff;
            text-decoration: none;
            font-weight: bold;
        }

        .botao-voltar:hover {
            background: #066541;
        }

        .indicadores {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .card {
            background: #ffffff;
            border: 1px solid #e5ece8;
            border-radius: 14px;
            padding: 24px;
            box-shadow: 0 4px 16px rgba(20, 50, 35, 0.04);
            min-width: 0;
        }

        .indicador-label {
            display: block;
            color: #718078;
            font-size: 14px;
            margin-bottom: 12px;
        }

        .indicador-valor {
            display: block;
            color: #087c50;
            font-size: 27px;
            font-weight: bold;
            overflow-wrap: anywhere;
        }

        .secao {
            margin-bottom: 25px;
        }

        .secao h2 {
            margin: 0 0 8px;
            color: #26352e;
            font-size: 21px;
        }

        .descricao {
            margin: 0 0 22px;
            color: #718078;
            font-size: 14px;
            line-height: 1.6;
        }

        .graficos {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .grafico-container {
            position: relative;
            width: 100%;
            height: 320px;
        }

        .grafico-linha {
            position: relative;
            width: 100%;
            height: 340px;
        }

        .mensagem {
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .mensagem.sucesso {
            background: #e7f7ed;
            color: #17653d;
        }

        .mensagem.erro {
            background: #fdecec;
            color: #9a2929;
        }

        .mensagem.info {
            background: #edf4fa;
            color: #285779;
        }

        .estado-vazio {
            padding: 28px 15px;
            text-align: center;
            color: #718078;
            background: #f8faf9;
            border-radius: 9px;
            line-height: 1.6;
        }

        .tabela-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 450px;
        }

        th,
        td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9efeb;
            text-align: left;
        }

        th {
            color: #68766e;
            font-size: 13px;
            font-weight: bold;
            background: #f8faf9;
        }

        td {
            font-size: 14px;
        }

        .valor-tabela {
            color: #087c50;
            font-weight: bold;
        }

        .rodape {
            margin-top: 25px;
            text-align: center;
            color: #849087;
            font-size: 12px;
        }

        @media (max-width: 850px) {
            body {
                padding: 18px;
            }

            .indicadores {
                grid-template-columns: 1fr;
            }

            .graficos {
                grid-template-columns: 1fr;
            }

            .indicador-valor {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <header class="cabecalho">
        <div>
            <h1>Análises financeiras</h1>

            <p>
                Acompanhe a composição dos seus investimentos
                e a evolução do seu patrimônio.
            </p>
        </div>

        <a
            class="botao-voltar"
            href="<?= escaparAnalise(BASE_URL . '/dashboard') ?>"
        >
            Voltar ao painel
        </a>
    </header>

    <?php if (!empty($mensagemHistorico)): ?>
        <div class="mensagem <?= escaparAnalise($tipoMensagemHistorico) ?>">
            <?= escaparAnalise($mensagemHistorico) ?>
        </div>
    <?php endif; ?>

    <section class="indicadores">

        <article class="card">
            <span class="indicador-label">
                Total investido pelo preço médio
            </span>

            <strong class="indicador-valor">
                <?= escaparAnalise(formatarMoedaAnalise((float) $totalInvestido)) ?>
            </strong>
        </article>

        <article class="card">
            <span class="indicador-label">
                Categorias com investimentos
            </span>

            <strong class="indicador-valor">
                <?= (int) $totalCategorias ?>
            </strong>
        </article>

        <article class="card">
            <span class="indicador-label">
                Registros históricos
            </span>

            <strong class="indicador-valor">
                <?= (int) $totalRegistros ?>
            </strong>
        </article>

    </section>

    <section class="graficos">

        <article class="card secao">
            <h2>Distribuição por categoria</h2>

            <p class="descricao">
                Participação de cada categoria no total investido,
                calculada com base no preço médio de aquisição.
            </p>

            <?php if (!empty($distribuicaoCategorias)): ?>

                <div class="grafico-container">
                    <canvas id="graficoCategorias"></canvas>
                </div>

            <?php else: ?>

                <div class="estado-vazio">
                    Nenhum investimento cadastrado para gerar
                    este gráfico.
                </div>

            <?php endif; ?>
        </article>

        <article class="card secao">
            <h2>Valores por categoria</h2>

            <p class="descricao">
                Comparação dos valores investidos em cada categoria.
            </p>

            <?php if (!empty($distribuicaoCategorias)): ?>

                <div class="grafico-container">
                    <canvas id="graficoValores"></canvas>
                </div>

            <?php else: ?>

                <div class="estado-vazio">
                    Cadastre ativos para visualizar os valores
                    por categoria.
                </div>

            <?php endif; ?>
        </article>

    </section>

    <section class="card secao">

        <h2>Evolução do patrimônio</h2>

        <p class="descricao">
            Histórico dos valores de mercado efetivamente
            registrados no sistema.
        </p>

        <?php if ($totalRegistros >= 2): ?>

            <div class="grafico-linha">
                <canvas id="graficoHistorico"></canvas>
            </div>

        <?php elseif ($totalRegistros === 1): ?>

            <div class="estado-vazio">
                Você já possui um registro patrimonial.
                Novos registros em outras datas permitirão
                visualizar a evolução neste gráfico.
            </div>

        <?php else: ?>

            <div class="estado-vazio">
                Ainda não há registros históricos disponíveis.
                O gráfico será exibido quando houver dados suficientes.
            </div>

        <?php endif; ?>

    </section>

    <section class="card secao">

        <h2>Detalhamento por categoria</h2>

        <p class="descricao">
            Confira o valor investido e a participação percentual
            de cada categoria.
        </p>

        <?php if (!empty($distribuicaoCategorias)): ?>

            <div class="tabela-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>Categoria</th>
                            <th>Valor investido</th>
                            <th>Participação</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($distribuicaoCategorias as $item): ?>

                            <tr>
                                <td>
                                    <?= escaparAnalise($item["categoria"]) ?>
                                </td>

                                <td class="valor-tabela">
                                    <?= escaparAnalise(
                                        formatarMoedaAnalise(
                                            (float) $item["total_investido"]
                                        )
                                    ) ?>
                                </td>

                                <td>
                                    <?= number_format(
                                        (float) $item["percentual"],
                                        2,
                                        ",",
                                        "."
                                    ) ?>%
                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>

        <?php else: ?>

            <div class="estado-vazio">
                Nenhuma categoria possui investimentos registrados.
            </div>

        <?php endif; ?>

    </section>

    <section class="card secao">

        <h2>Histórico de registros</h2>

        <p class="descricao">
            Valores armazenados na tabela
            <code>historico_patrimonio</code>.
        </p>

        <?php if (!empty($historicoPatrimonio)): ?>

            <div class="tabela-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>Data do registro</th>
                            <th>Valor patrimonial</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach (array_reverse($historicoPatrimonio) as $registro): ?>

                            <tr>
                                <td>
                                    <?= escaparAnalise(
                                        date(
                                            "d/m/Y H:i",
                                            strtotime($registro["data_registro"])
                                        )
                                    ) ?>
                                </td>

                                <td class="valor-tabela">
                                    <?= escaparAnalise(
                                        formatarMoedaAnalise(
                                            (float) $registro["valor_total"]
                                        )
                                    ) ?>
                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>

        <?php else: ?>

            <div class="estado-vazio">
                Nenhum registro patrimonial foi armazenado até o momento.
            </div>

        <?php endif; ?>

    </section>

    <footer class="rodape">
        INVESTEGRA — Análises e acompanhamento patrimonial
    </footer>

</div>

<script>
const categorias = <?= json_encode(
    $categoriasGrafico,
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?>;

const valores = <?= json_encode(
    $valoresGrafico,
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?>;

const percentuais = <?= json_encode(
    $percentuaisGrafico,
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?>;

const datasHistorico = <?= json_encode(
    $datasHistorico,
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?>;

const valoresHistorico = <?= json_encode(
    $valoresHistorico,
    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
) ?>;

function formatarBRL(valor, casasDecimais = 2) {
    return Number(valor).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL",
        minimumFractionDigits: casasDecimais,
        maximumFractionDigits: casasDecimais
    });
}

// Gráfico de distribuição percentual.
const canvasCategorias = document.getElementById("graficoCategorias");

if (canvasCategorias) {
    new Chart(canvasCategorias, {
        type: "doughnut",

        data: {
            labels: categorias,

            datasets: [{
                data: percentuais,
                backgroundColor: [
                    "#00a86b",
                    "#247ba0",
                    "#f4a261",
                    "#8e7dbe",
                    "#e76f51",
                    "#6c9a8b",
                    "#d4a373",
                    "#78909c"
                ],
                borderWidth: 2,
                borderColor: "#ffffff"
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    position: "bottom"
                },

                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ": " +
                                Number(context.raw).toLocaleString(
                                    "pt-BR",
                                    {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    }
                                ) + "%";
                        }
                    }
                }
            }
        }
    });
}

// Gráfico de valores investidos por categoria.
const canvasValores = document.getElementById("graficoValores");

if (canvasValores) {
    new Chart(canvasValores, {
        type: "bar",

        data: {
            labels: categorias,

            datasets: [{
                label: "Valor investido",
                data: valores,
                backgroundColor: "#00a86b",
                borderRadius: 6
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: false
                },

                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return formatarBRL(context.raw);
                        }
                    }
                }
            },

            scales: {
                y: {
                    beginAtZero: true,

                    ticks: {
                        callback: function(valor) {
                            return formatarBRL(valor, 0);
                        }
                    }
                }
            }
        }
    });
}

// Gráfico de evolução patrimonial.
const canvasHistorico = document.getElementById("graficoHistorico");

if (canvasHistorico) {
    new Chart(canvasHistorico, {
        type: "line",

        data: {
            labels: datasHistorico,

            datasets: [{
                label: "Patrimônio registrado",
                data: valoresHistorico,
                borderColor: "#00a86b",
                backgroundColor: "rgba(0, 168, 107, 0.12)",
                borderWidth: 3,
                fill: true,
                tension: 0.25,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: true
                },

                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return "Patrimônio: " +
                                formatarBRL(context.raw);
                        }
                    }
                }
            },

            scales: {
                y: {
                    beginAtZero: true,

                    ticks: {
                        callback: function(valor) {
                            return formatarBRL(valor, 0);
                        }
                    }
                }
            }
        }
    });
}
</script>

</body>
</html>
