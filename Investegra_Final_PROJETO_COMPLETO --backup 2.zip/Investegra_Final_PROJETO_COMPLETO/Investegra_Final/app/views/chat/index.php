<?php

$escaparChat = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$mensagens = is_array($mensagens ?? null) ? $mensagens : [];

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Assistente IA | INVESTEGRA</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 25px;
            background: #f4f7f6;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        .chat-container {
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 950px;
            min-height: calc(100vh - 50px);
            margin: 0 auto;
            overflow: hidden;
            border: 1px solid #e1eae4;
            border-radius: 16px;
            background: #ffffff;
            box-shadow: 0 8px 28px rgba(20, 50, 35, 0.06);
        }

        .chat-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 22px 25px;
            border-bottom: 1px solid #e5ece8;
            background: #ffffff;
        }

        .chat-identidade {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .chat-avatar {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 45px;
            height: 45px;
            flex-shrink: 0;
            border-radius: 13px;
            background: #e5f7ed;
            color: #087c50;
            font-size: 23px;
        }

        .chat-header h1 {
            margin: 0 0 6px;
            color: #087c50;
            font-size: 20px;
        }

        .chat-header p {
            margin: 0;
            color: #718078;
            font-size: 12px;
        }

        .chat-acoes {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .botao {
            display: inline-block;
            padding: 10px 13px;
            border: 0;
            border-radius: 8px;
            background: #087c50;
            color: #ffffff;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .botao:hover {
            background: #066541;
        }

        .botao-secundario {
            border: 1px solid #dbe6df;
            background: #ffffff;
            color: #405449;
        }

        .botao-secundario:hover {
            background: #f3f7f4;
        }

        .chat-mensagens {
            display: flex;
            flex: 1;
            flex-direction: column;
            gap: 20px;
            min-height: 350px;
            max-height: 65vh;
            overflow-y: auto;
            padding: 25px;
            background: #f9fbfa;
        }

        .boas-vindas {
            max-width: 650px;
            margin: auto;
            padding: 20px;
            text-align: center;
        }

        .boas-vindas .icone {
            margin-bottom: 15px;
            font-size: 42px;
        }

        .boas-vindas h2 {
            margin: 0 0 12px;
            color: #087c50;
            font-size: 23px;
        }

        .boas-vindas p {
            color: #718078;
            font-size: 14px;
            line-height: 1.7;
        }

        .sugestoes {
            display: flex;
            justify-content: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .sugestao {
            padding: 9px 12px;
            border: 1px solid #dbe9e0;
            border-radius: 20px;
            background: #ffffff;
            color: #087c50;
            font-size: 12px;
        }

        .mensagem {
            display: flex;
            flex-direction: column;
            max-width: 82%;
            gap: 6px;
        }

        .mensagem.usuario {
            align-self: flex-end;
        }

        .mensagem.assistente {
            align-self: flex-start;
        }

        .mensagem-autor {
            color: #718078;
            font-size: 11px;
        }

        .mensagem.usuario .mensagem-autor {
            text-align: right;
        }

        .mensagem-conteudo {
            padding: 14px 16px;
            border-radius: 13px;
            font-size: 14px;
            line-height: 1.7;
            overflow-wrap: anywhere;
        }

        .mensagem.usuario .mensagem-conteudo {
            border-bottom-right-radius: 4px;
            background: #087c50;
            color: #ffffff;
        }

        .mensagem.assistente .mensagem-conteudo {
            border: 1px solid #e4ece7;
            border-bottom-left-radius: 4px;
            background: #ffffff;
            color: #26352e;
        }

        .mensagem-conteudo p {
            margin: 0 0 10px;
        }

        .mensagem-conteudo p:last-child {
            margin-bottom: 0;
        }

        .erro {
            margin: 18px 25px 0;
            padding: 13px 15px;
            border-radius: 8px;
            background: #fdecec;
            color: #9a2929;
            font-size: 13px;
            line-height: 1.5;
        }

        .chat-formulario {
            padding: 20px 25px;
            border-top: 1px solid #e5ece8;
            background: #ffffff;
        }

        .chat-formulario form {
            display: flex;
            align-items: flex-end;
            gap: 12px;
        }

        .campo-mensagem {
            flex: 1;
            min-width: 0;
        }

        .campo-mensagem textarea {
            display: block;
            width: 100%;
            min-height: 52px;
            max-height: 160px;
            padding: 14px;
            border: 1px solid #d5dfd9;
            border-radius: 10px;
            outline: none;
            resize: vertical;
            font-family: inherit;
            font-size: 14px;
            line-height: 1.5;
        }

        .campo-mensagem textarea:focus {
            border-color: #00a86b;
            box-shadow: 0 0 0 3px rgba(0, 168, 107, 0.1);
        }

        .botao-enviar {
            min-height: 48px;
            padding: 0 20px;
            font-size: 13px;
        }

        .nota {
            margin: 12px 0 0;
            color: #849087;
            font-size: 11px;
            line-height: 1.5;
            text-align: center;
        }

        @media (max-width: 600px) {
            body {
                padding: 0;
            }

            .chat-container {
                min-height: 100vh;
                border: 0;
                border-radius: 0;
            }

            .chat-header {
                align-items: flex-start;
                padding: 18px;
            }

            .chat-header h1 {
                font-size: 17px;
            }

            .chat-mensagens {
                padding: 18px;
                max-height: none;
            }

            .mensagem {
                max-width: 95%;
            }

            .chat-formulario {
                padding: 15px;
            }

            .chat-formulario form {
                gap: 8px;
            }

            .botao-enviar {
                padding: 0 13px;
            }
        }
    </style>
</head>

<body>

<div class="chat-container">

    <header class="chat-header">

        <div class="chat-identidade">
            <div class="chat-avatar" aria-hidden="true">
                ✦
            </div>

            <div>
                <h1>Assistente INVESTEGRA</h1>

                <p>Inteligência artificial local com Ollama</p>
            </div>
        </div>

        <div class="chat-acoes">

            <a
                class="botao botao-secundario"
                href="<?= $escaparChat(BASE_URL . '/dashboard') ?>"
            >
                Voltar
            </a>

            <form
                action="<?= $escaparChat(BASE_URL . '/chat/limpar') ?>"
                method="POST"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= $escaparChat($_SESSION['csrf_token'] ?? '') ?>"
                >

                <button
                    class="botao botao-secundario"
                    type="submit"
                >
                    Limpar chat
                </button>
            </form>

        </div>

    </header>

    <?php if (!empty($erroChat)): ?>
        <div class="erro" role="alert">
            <?= $escaparChat($erroChat) ?>
        </div>
    <?php endif; ?>

    <main
        class="chat-mensagens"
        id="chatMensagens"
        aria-live="polite"
    >

        <?php if (empty($mensagens)): ?>

            <section class="boas-vindas">

                <div class="icone" aria-hidden="true">✦</div>

                <h2>Como posso ajudar?</h2>

                <p>
                    Tire dúvidas sobre investimentos, conceitos financeiros,
                    planejamento e funcionamento do INVESTEGRA.
                </p>

                <div class="sugestoes">
                    <span class="sugestao">
                        O que é renda fixa?
                    </span>

                    <span class="sugestao">
                        Explique a diversificação
                    </span>

                    <span class="sugestao">
                        Como funciona a rentabilidade?
                    </span>
                </div>

            </section>

        <?php else: ?>

            <?php foreach ($mensagens as $mensagem): ?>

                <?php
                $papel = ($mensagem["role"] ?? "") === "user"
                    ? "usuario"
                    : "assistente";

                $autor = $papel === "usuario"
                    ? "Você"
                    : "Assistente INVESTEGRA";
                ?>

                <article class="mensagem <?= $papel ?>">

                    <span class="mensagem-autor">
                        <?= $escaparChat($autor) ?>
                    </span>

                    <div class="mensagem-conteudo"><?=
                        nl2br(
                            $escaparChat($mensagem["content"] ?? "")
                        )
                    ?></div>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

    </main>

    <footer class="chat-formulario">

        <form
            action="<?= $escaparChat(BASE_URL . '/chat/enviar') ?>"
            method="POST"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= $escaparChat($_SESSION['csrf_token'] ?? '') ?>"
            >

            <div class="campo-mensagem">
                <textarea
                    name="mensagem"
                    id="mensagem"
                    placeholder="Digite sua pergunta..."
                    maxlength="4000"
                    rows="2"
                    required
                ></textarea>
            </div>

            <button
                class="botao botao-enviar"
                type="submit"
            >
                Enviar
            </button>

        </form>

        <p class="nota">
            As respostas são geradas por IA e podem conter erros.
            As orientações não garantem resultados financeiros.
        </p>

    </footer>

</div>

<script>
const areaMensagens = document.getElementById("chatMensagens");
const campoMensagem = document.getElementById("mensagem");

if (areaMensagens) {
    areaMensagens.scrollTop = areaMensagens.scrollHeight;
}

if (campoMensagem) {
    campoMensagem.focus();
}
</script>

</body>
</html>
