<?php

$escapar = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$valor = static function (
    string $campo
) use ($usuario): string {
    return htmlspecialchars(
        (string) ($usuario[$campo] ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$nome = trim((string) ($usuario["nome"] ?? "Investidor"));
$iniciais = strtoupper(
    mb_substr($nome !== "" ? $nome : "I", 0, 1, "UTF-8")
);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Meu perfil | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= $escapar(BASE_URL . '/css/style.css') ?>"
    >

    <style>
        body {
            display: block;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            background: #f6f8f7;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        .perfil-layout {
            display: flex;
            min-height: 100vh;
        }

        .perfil-sidebar {
            width: 235px;
            flex-shrink: 0;
            padding: 28px 18px;
            background: #fff;
            border-right: 1px solid #e7ece9;
        }

        .perfil-logo {
            margin: 0 0 5px;
            color: #008653;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: .5px;
        }

        .perfil-logo-descricao {
            margin: 0 0 32px;
            color: #849087;
            font-size: 12px;
        }

        .perfil-menu-titulo {
            margin: 24px 10px 10px;
            color: #9aa49d;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .perfil-menu {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .perfil-menu a {
            padding: 12px;
            border-radius: 8px;
            color: #526158;
            font-size: 14px;
            text-decoration: none;
        }

        .perfil-menu a:hover,
        .perfil-menu a.ativo {
            background: #eaf7f0;
            color: #008653;
        }

        .perfil-conteudo {
            width: min(100%, 1100px);
            margin: 0 auto;
            padding: 34px;
        }

        .perfil-cabecalho {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 28px;
        }

        .perfil-cabecalho h1 {
            margin: 0 0 8px;
            color: #20342b;
            text-align: left;
            font-size: 28px;
        }

        .perfil-cabecalho p {
            margin: 0;
            color: #7b8980;
            line-height: 1.5;
        }

        .perfil-cartao {
            margin-bottom: 22px;
            padding: 26px;
            background: #fff;
            border: 1px solid #e7ece9;
            border-radius: 16px;
            box-shadow: 0 5px 18px rgba(20, 50, 35, .035);
        }

        .perfil-identificacao {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .perfil-avatar {
            display: flex;
            width: 66px;
            height: 66px;
            flex-shrink: 0;
            align-items: center;
            justify-content: center;
            border-radius: 18px;
            background: #e5f6ed;
            color: #008653;
            font-size: 27px;
            font-weight: 800;
        }

        .perfil-identificacao h2 {
            margin: 0 0 6px;
            font-size: 20px;
        }

        .perfil-identificacao p {
            margin: 0;
            color: #7b8980;
            overflow-wrap: anywhere;
        }

        .perfil-selo {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 9px;
            border-radius: 20px;
            background: #f0f5f2;
            color: #526158;
            font-size: 12px;
        }

        .perfil-cartao h2.titulo-secao {
            margin: 0 0 8px;
            font-size: 18px;
        }

        .perfil-ajuda {
            margin: 0 0 24px;
            color: #7b8980;
            font-size: 13px;
            line-height: 1.5;
        }

        .perfil-formulario {
            display: block;
        }

        .perfil-grade {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .perfil-campo {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 0;
        }

        .perfil-campo.completo {
            grid-column: 1 / -1;
        }

        .perfil-campo label {
            color: #405047;
            font-size: 13px;
            font-weight: 700;
        }

        .perfil-campo input,
        .perfil-campo textarea {
            width: 100%;
            min-width: 0;
            padding: 12px 13px;
            border: 1px solid #dce5df;
            border-radius: 9px;
            background: #fff;
            color: #26352e;
            font: inherit;
            font-size: 14px;
        }

        .perfil-campo textarea {
            min-height: 105px;
            resize: vertical;
        }

        .perfil-campo input:focus,
        .perfil-campo textarea:focus {
            outline: 2px solid #bcebd2;
            border-color: #008653;
        }

        .perfil-campo input[readonly] {
            background: #f5f7f6;
            color: #7b8980;
            cursor: not-allowed;
        }

        .perfil-nota {
            color: #849087;
            font-size: 12px;
            line-height: 1.4;
        }

        .perfil-acoes {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
        }

        .perfil-botao {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 43px;
            padding: 11px 17px;
            border: 0;
            border-radius: 9px;
            background: #008653;
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .perfil-botao:hover {
            background: #006f44;
        }

        .perfil-botao-secundario {
            border: 1px solid #dce5df;
            background: #fff;
            color: #405047;
        }

        .perfil-botao-secundario:hover {
            background: #f5f7f6;
        }

        .perfil-mensagem {
            margin-bottom: 20px;
            padding: 14px 16px;
            border-radius: 10px;
            font-size: 14px;
            line-height: 1.5;
        }

        .perfil-sucesso {
            border: 1px solid #bcebd2;
            background: #edf9f2;
            color: #176b43;
        }

        .perfil-erro {
            border: 1px solid #f1c7c7;
            background: #fff1f1;
            color: #a52b2b;
        }

        .perfil-rodape {
            padding: 8px 0 20px;
            color: #849087;
            font-size: 12px;
            text-align: center;
        }

        @media (max-width: 850px) {
            .perfil-layout {
                display: block;
            }

            .perfil-sidebar {
                width: 100%;
                padding: 18px;
                border-right: 0;
                border-bottom: 1px solid #e7ece9;
            }

            .perfil-logo-descricao,
            .perfil-menu-titulo {
                display: none;
            }

            .perfil-menu {
                flex-direction: row;
                flex-wrap: wrap;
                margin-top: 16px;
            }

            .perfil-conteudo {
                padding: 24px 18px;
            }
        }

        @media (max-width: 560px) {
            .perfil-grade {
                grid-template-columns: 1fr;
            }

            .perfil-campo.completo {
                grid-column: auto;
            }

            .perfil-cabecalho {
                align-items: flex-start;
                flex-direction: column;
            }

            .perfil-cabecalho h1 {
                font-size: 24px;
            }

            .perfil-cartao {
                padding: 20px;
            }

            .perfil-acoes {
                flex-direction: column-reverse;
            }

            .perfil-botao {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="perfil-layout">

    <aside class="perfil-sidebar">
        <h2 class="perfil-logo">INVESTEGRA</h2>
        <p class="perfil-logo-descricao">
            Sua jornada financeira
        </p>

        <nav class="perfil-menu">
            <p class="perfil-menu-titulo">Menu principal</p>

            <a href="<?= $escapar(BASE_URL . '/dashboard') ?>">
                Dashboard
            </a>

            <a href="<?= $escapar(BASE_URL . '/carteiras') ?>">
                Carteiras
            </a>

            <a href="<?= $escapar(BASE_URL . '/ativos') ?>">
                Ativos
            </a>

            <a href="<?= $escapar(BASE_URL . '/analises') ?>">
                Análises
            </a>

            <a href="<?= $escapar(BASE_URL . '/simulacoes') ?>">
                Simulações
            </a>

            <a href="<?= $escapar(BASE_URL . '/chat') ?>">
                Assistente IA
            </a>

            <a
                class="ativo"
                href="<?= $escapar(BASE_URL . '/perfil') ?>"
            >
                Meu perfil
            </a>
        </nav>
    </aside>

    <main class="perfil-conteudo">

        <header class="perfil-cabecalho">
            <div>
                <h1>Meu perfil</h1>
                <p>
                    Gerencie seus dados pessoais e suas preferências
                    de investimento.
                </p>
            </div>

            <a
                class="perfil-botao perfil-botao-secundario"
                href="<?= $escapar(BASE_URL . '/dashboard') ?>"
            >
                Voltar ao dashboard
            </a>
        </header>

        <?php if (!empty($sucesso)): ?>
            <div class="perfil-mensagem perfil-sucesso">
                Perfil atualizado com sucesso!
            </div>
        <?php endif; ?>

        <?php if (!empty($erro)): ?>
            <div class="perfil-mensagem perfil-erro">
                <?= $escapar($erro) ?>
            </div>
        <?php endif; ?>

        <section class="perfil-cartao">
            <div class="perfil-identificacao">
                <div class="perfil-avatar">
                    <?= $escapar($iniciais) ?>
                </div>

                <div>
                    <h2><?= $valor("nome") ?></h2>
                    <p><?= $valor("email") ?></p>

                    <span class="perfil-selo">
                        <?= $valor("tipo_usuario") === "PJ"
                            ? "Pessoa jurídica"
                            : "Pessoa física" ?>
                    </span>
                </div>
            </div>
        </section>

        <section class="perfil-cartao">
            <h2 class="titulo-secao">Dados pessoais</h2>

            <p class="perfil-ajuda">
                Atualize suas informações. O documento cadastrado
                permanece somente para consulta nesta tela.
            </p>

            <form
                class="perfil-formulario"
                action="<?= $escapar(BASE_URL . '/perfil/atualizar') ?>"
                method="POST"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= $escapar($csrfToken) ?>"
                >

                <div class="perfil-grade">

                    <div class="perfil-campo">
                        <label for="nome">Nome completo</label>
                        <input
                            type="text"
                            id="nome"
                            name="nome"
                            maxlength="100"
                            value="<?= $valor("nome") ?>"
                            autocomplete="name"
                            required
                        >
                    </div>

                    <div class="perfil-campo">
                        <label for="email">E-mail</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            maxlength="150"
                            value="<?= $valor("email") ?>"
                            autocomplete="email"
                            required
                        >
                    </div>

                    <div class="perfil-campo">
                        <label for="documento">Documento cadastrado</label>
                        <input
                            type="text"
                            id="documento"
                            value="<?= $valor("documento") ?>"
                            readonly
                        >
                        <span class="perfil-nota">
                            Para evitar alterações indevidas,
                            este campo não é editável nesta versão.
                        </span>
                    </div>

                    <div class="perfil-campo">
                        <label for="idade">Idade</label>
                        <input
                            type="number"
                            id="idade"
                            name="idade"
                            min="13"
                            max="120"
                            value="<?= $valor("idade") ?>"
                            placeholder="Ex.: 25"
                        >
                    </div>

                </div>

                <h2
                    class="titulo-secao"
                    style="margin-top: 30px;"
                >
                    Informações financeiras
                </h2>

                <p class="perfil-ajuda">
                    Estes campos são opcionais e podem ajudar a
                    contextualizar suas análises futuras.
                </p>

                <div class="perfil-grade">

                    <div class="perfil-campo">
                        <label for="experiencia">
                            Experiência com investimentos
                        </label>
                        <input
                            type="text"
                            id="experiencia"
                            name="experiencia"
                            maxlength="50"
                            value="<?= $valor("experiencia") ?>"
                            placeholder="Ex.: Iniciante"
                        >
                    </div>

                    <div class="perfil-campo">
                        <label for="renda_mensal">Renda mensal (R$)</label>
                        <input
                            type="number"
                            id="renda_mensal"
                            name="renda_mensal"
                            min="0"
                            max="99999999.99"
                            step="0.01"
                            value="<?= $valor("renda_mensal") ?>"
                            placeholder="Ex.: 2500,00"
                        >
                    </div>

                    <div class="perfil-campo">
                        <label for="horizonte_investimento">
                            Horizonte de investimento
                        </label>
                        <input
                            type="text"
                            id="horizonte_investimento"
                            name="horizonte_investimento"
                            maxlength="50"
                            value="<?= $valor("horizonte_investimento") ?>"
                            placeholder="Ex.: Longo prazo"
                        >
                    </div>

                    <div class="perfil-campo">
                        <label for="tolerancia_risco">
                            Tolerância a risco
                        </label>
                        <input
                            type="text"
                            id="tolerancia_risco"
                            name="tolerancia_risco"
                            maxlength="50"
                            value="<?= $valor("tolerancia_risco") ?>"
                            placeholder="Ex.: Moderada"
                        >
                    </div>

                    <div class="perfil-campo completo">
                        <label for="objetivo">
                            Objetivo financeiro
                        </label>
                        <input
                            type="text"
                            id="objetivo"
                            name="objetivo"
                            maxlength="100"
                            value="<?= $valor("objetivo") ?>"
                            placeholder="Ex.: Construir uma reserva financeira"
                        >
                    </div>

                    <div class="perfil-campo completo">
                        <label for="descricao_pessoal">
                            Sobre você e seus objetivos
                        </label>
                        <textarea
                            id="descricao_pessoal"
                            name="descricao_pessoal"
                            maxlength="10000"
                            placeholder="Descreva seus objetivos e suas preferências, se desejar."
                        ><?= $valor("descricao_pessoal") ?></textarea>
                    </div>

                </div>

                <div class="perfil-acoes">
                    <a
                        class="perfil-botao perfil-botao-secundario"
                        href="<?= $escapar(BASE_URL . '/dashboard') ?>"
                    >
                        Cancelar
                    </a>

                    <button
                        type="submit"
                        class="perfil-botao"
                    >
                        Salvar alterações
                    </button>
                </div>

            </form>
        </section>

        <footer class="perfil-rodape">
            INVESTEGRA · Gestão e acompanhamento financeiro
        </footer>

    </main>

</div>

</body>
</html>
