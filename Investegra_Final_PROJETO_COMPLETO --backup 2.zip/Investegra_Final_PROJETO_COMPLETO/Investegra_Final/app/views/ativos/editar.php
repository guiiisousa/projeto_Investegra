<?php

$escape = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar ativo | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= BASE_URL ?>/css/style.css"
    >
</head>
<body>

<div class="carteiras-container">

    <header class="cabecalho-carteiras">
        <div>
            <h1>Editar ativo</h1>

            <p>
                Carteira:
                <strong><?= $escape($carteira["nome"]) ?></strong>
            </p>

            <p>Atualize as informações do investimento.</p>
        </div>

        <a
            href="<?= BASE_URL ?>/ativos?carteira=<?= (int) $carteira["id"] ?>"
            class="botao-link"
        >
            Voltar aos ativos
        </a>
    </header>

    <section class="card-carteira">

        <form
            action="<?= BASE_URL ?>/ativos/atualizar"
            method="POST"
            class="formulario-ativo"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= $escape($_SESSION["csrf_token"]) ?>"
            >

            <input
                type="hidden"
                name="id"
                value="<?= (int) $ativo["id"] ?>"
            >

            <div class="campo-formulario">
                <label for="ticker">Ticker ou código do ativo</label>

                <input
                    type="text"
                    id="ticker"
                    name="ticker"
                    maxlength="20"
                    value="<?= $escape($ativo["ticker"]) ?>"
                    placeholder="Ex.: PETR4"
                    required
                >
            </div>

            <div class="campo-formulario">
                <label for="categoria_id">Categoria</label>

                <select
                    id="categoria_id"
                    name="categoria_id"
                >
                    <option value="">Sem categoria</option>

                    <?php foreach ($categorias as $categoria): ?>

                        <option
                            value="<?= (int) $categoria["id"] ?>"
                            <?= (int) ($ativo["categoria_id"] ?? 0)
                                === (int) $categoria["id"]
                                ? "selected"
                                : "" ?>
                        >
                            <?= $escape($categoria["nome"]) ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </div>

            <div class="campo-formulario">
                <label for="quantidade">Quantidade adquirida</label>

                <input
                    type="number"
                    id="quantidade"
                    name="quantidade"
                    min="0.0001"
                    step="0.0001"
                    value="<?= $escape($ativo["quantidade"]) ?>"
                    required
                >
            </div>

            <div class="campo-formulario">
                <label for="preco_medio">Preço médio de compra (R$)</label>

                <input
                    type="number"
                    id="preco_medio"
                    name="preco_medio"
                    min="0.01"
                    step="0.01"
                    value="<?= $escape($ativo["preco_medio"]) ?>"
                    required
                >
            </div>

            <div class="campo-formulario">
                <label for="data_compra">Data da compra</label>

                <input
                    type="date"
                    id="data_compra"
                    name="data_compra"
                    value="<?= $escape($ativo["data_compra"]) ?>"
                >
            </div>

            <div class="campo-formulario">
                <label for="observacao">Observações</label>

                <textarea
                    id="observacao"
                    name="observacao"
                    rows="4"
                    maxlength="60000"
                    placeholder="Informações adicionais (opcional)"
                ><?= $escape($ativo["observacao"]) ?></textarea>
            </div>

            <div class="acoes-carteiras">

                <button
                    type="submit"
                    class="botao-link"
                >
                    Salvar alterações
                </button>

                <a
                    href="<?= BASE_URL ?>/ativos?carteira=<?= (int) $carteira["id"] ?>"
                    class="botao-link"
                >
                    Cancelar
                </a>

            </div>

        </form>

    </section>

</div>

</body>
</html>
