<?php

$escape = static function ($valor): string {
    return htmlspecialchars((string) ($valor ?? ""), ENT_QUOTES, "UTF-8");
};

$formatarDinheiro = static function ($valor, string $moeda = "BRL"): string {
    $prefixo = match ($moeda) {
        "BRL" => "R$ ",
        "USD" => "US$ ",
        "EUR" => "€ ",
        default => $moeda . " ",
    };

    return $prefixo . number_format((float) $valor, 2, ",", ".");
};

$formatarPercentual = static function ($valor): string {
    return number_format((float) $valor, 2, ",", ".") . "%";
};

$nomeCarteira = $carteira["nome"] ?? "Carteira";
?>

<div class="carteiras-container">

    <header class="cabecalho-carteiras">
        <div>
            <h1>Ativos da carteira</h1>

            <p>
                Carteira:
                <strong><?= $escape($nomeCarteira) ?></strong>
            </p>
        </div>

        <div class="acoes-carteiras">
            <a
                href="<?= BASE_URL ?>/ativos/criar?carteira=<?= (int) $carteiraId ?>"
                class="botao-link"
            >
                + Novo ativo
            </a>

            <a
                href="<?= BASE_URL ?>/carteiras"
                class="botao-link"
            >
                Voltar às carteiras
            </a>
        </div>
    </header>

    <!-- Resumo financeiro da carteira -->
    <section class="resumo-patrimonio">

        <article class="indicador-patrimonio">
            <span>Total investido</span>

            <strong>
                <?= $formatarDinheiro($totalInvestido ?? 0) ?>
            </strong>

            <small>
                Soma dos valores médios de aquisição
            </small>
        </article>

        <article class="indicador-patrimonio">
            <span>Valor de mercado</span>

            <strong>
                <?= $formatarDinheiro($totalMercado ?? 0) ?>
            </strong>

            <small>
                Ativos com cotação disponível em reais:
                <?= (int) ($quantidadeCotada ?? 0) ?>
            </small>
        </article>

        <article class="indicador-patrimonio">
            <span>Resultado estimado</span>

            <?php
            $resultadoGeral = (float) ($totalResultado ?? 0);

            $classeResultadoGeral = $resultadoGeral >= 0
                ? "resultado-positivo"
                : "resultado-negativo";
            ?>

            <strong class="<?= $classeResultadoGeral ?>">
                <?= $resultadoGeral > 0 ? "+" : "" ?>
                <?= $formatarDinheiro($resultadoGeral) ?>
            </strong>

            <small>
                Considera somente os ativos com cotação disponível em reais
            </small>
        </article>

    </section>

    <?php if (($ativosSemCotacao ?? 0) > 0): ?>
        <div class="aviso-cotacao">
            <strong>Atenção:</strong>
            não foi possível calcular o valor de mercado em reais de
            <?= (int) $ativosSemCotacao ?>
            ativo(s). Isso pode ocorrer quando a cotação está indisponível
            ou quando a moeda não é BRL.
        </div>
    <?php endif; ?>

    <!-- Listagem dos ativos -->
    <?php if (empty($ativos)): ?>

        <div class="estado-vazio">
            <h2>Nenhum ativo cadastrado</h2>

            <p>
                Esta carteira ainda não possui ativos.
                Cadastre seu primeiro ativo para começar a acompanhar
                seus investimentos.
            </p>

            <a
                href="<?= BASE_URL ?>/ativos/criar?carteira=<?= (int) $carteiraId ?>"
                class="botao-link"
            >
                Cadastrar primeiro ativo
            </a>
        </div>

    <?php else: ?>

        <div class="lista-carteiras">

            <?php foreach ($ativos as $ativo): ?>

                <?php
                $ativoId = (int) $ativo["id"];

                $ticker = $ativo["ticker"] ?? "";
                $categoria = $ativo["categoria_nome"] ?? "Sem categoria";

                $quantidade = (float) $ativo["quantidade"];
                $precoMedio = (float) $ativo["preco_medio"];

                $valorInvestido = (float) ($ativo["valor_investido"] ?? 0);
                $cotacaoAtual = $ativo["cotacao_atual"] ?? null;
                $valorMercado = $ativo["valor_mercado"] ?? null;
                $resultado = $ativo["resultado"] ?? null;
                $percentual = $ativo["resultado_percentual"] ?? null;

                $moedaCotacao = $ativo["moeda_cotacao"] ?? "BRL";

                $temResultado = $resultado !== null
                    && $percentual !== null;

                $classeResultado = $temResultado && (float) $resultado >= 0
                    ? "resultado-positivo"
                    : "resultado-negativo";
                ?>

                <article class="card-carteira">

                    <div class="cabecalho-card-ativo">
                        <div>
                            <h2><?= $escape($ticker) ?></h2>

                            <span class="categoria-ativo">
                                <?= $escape($categoria) ?>
                            </span>
                        </div>

                        <div class="acoes-card">

                            <a
                                href="<?= BASE_URL ?>/ativos/editar?id=<?= $ativoId ?>"
                                class="botao-editar"
                            >
                                Editar
                            </a>

                            <form
                                action="<?= BASE_URL ?>/ativos/excluir"
                                method="POST"
                                onsubmit="return confirm('Deseja realmente excluir este ativo?');"
                            >
                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= $ativoId ?>"
                                >

                                <input
                                    type="hidden"
                                    name="carteira_id"
                                    value="<?= (int) $carteiraId ?>"
                                >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= $escape($csrfToken ?? '') ?>"
                                >

                                <button
                                    type="submit"
                                    class="botao-excluir"
                                >
                                    Excluir
                                </button>
                            </form>

                        </div>
                    </div>

                    <div class="detalhes-ativo">

                        <div class="detalhe-ativo">
                            <span>Quantidade</span>

                            <strong>
                                <?= number_format($quantidade, 4, ",", ".") ?>
                            </strong>
                        </div>

                        <div class="detalhe-ativo">
                            <span>Preço médio</span>

                            <strong>
                                <?= $formatarDinheiro($precoMedio) ?>
                            </strong>
                        </div>

                        <div class="detalhe-ativo">
                            <span>Total investido</span>

                            <strong>
                                <?= $formatarDinheiro($valorInvestido) ?>
                            </strong>
                        </div>

                        <div class="detalhe-ativo">
                            <span>Cotação atual</span>

                            <strong>
                                <?php if ($cotacaoAtual !== null): ?>

                                    <?= $formatarDinheiro($cotacaoAtual, $moedaCotacao) ?>

                                <?php else: ?>

                                    <span class="cotacao-indisponivel">
                                        <?= !empty($ativo["erro_cotacao"])
                                            ? "Falha na consulta"
                                            : "Indisponível" ?>
                                    </span>

                                <?php endif; ?>
                            </strong>
                        </div>

                        <div class="detalhe-ativo">
                            <span>Valor de mercado</span>

                            <strong>
                                <?php if ($valorMercado !== null): ?>

                                    <?= $formatarDinheiro($valorMercado) ?>

                                <?php else: ?>

                                    <span class="cotacao-indisponivel">
                                        Indisponível
                                    </span>

                                <?php endif; ?>
                            </strong>
                        </div>

                        <div class="detalhe-ativo">
                            <span>Resultado estimado</span>

                            <strong>
                                <?php if ($temResultado): ?>

                                    <span class="<?= $classeResultado ?>">
                                        <?= (float) $resultado > 0 ? "+" : "" ?>
                                        <?= $formatarDinheiro($resultado) ?>
                                    </span>

                                    <small class="<?= $classeResultado ?>">
                                        (<?= (float) $percentual > 0 ? "+" : "" ?>
                                        <?= $formatarPercentual($percentual) ?>)
                                    </small>

                                <?php else: ?>

                                    <span class="cotacao-indisponivel">
                                        Indisponível
                                    </span>

                                <?php endif; ?>
                            </strong>
                        </div>

                    </div>

                    <?php if (!empty($ativo["data_compra"])): ?>

                        <p class="informacao-ativo">
                            <strong>Data da compra:</strong>
                            <?= $escape(
                                date(
                                    "d/m/Y",
                                    strtotime($ativo["data_compra"])
                                )
                            ) ?>
                        </p>

                    <?php endif; ?>

                    <?php if (!empty($ativo["observacao"])): ?>

                        <p class="informacao-ativo">
                            <strong>Observação:</strong>
                            <?= nl2br($escape($ativo["observacao"])) ?>
                        </p>

                    <?php endif; ?>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>
