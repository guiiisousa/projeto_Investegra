<?php

$escape = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Novo ativo | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= BASE_URL ?>/css/style.css"
    >


<style>
    .carteiras-container {
        max-width: 1100px;
        margin: 40px auto;
        padding: 25px;
    }

    .cabecalho-carteiras {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 20px;
        margin-bottom: 30px;
        color: #f1f5f9;
    }

    .cabecalho-carteiras h1 {
        font-size: 28px;
        margin-bottom: 10px;
    }

    .cabecalho-carteiras p {
        color: #9ca3af;
        margin: 6px 0;
    }

    .card-carteira {
        background: #1f2937;
        border: 1px solid #374151;
        border-radius: 14px;
        padding: 25px;
    }

    .formulario-ativo {
        display: flex;
        flex-direction: column;
        gap: 22px;
        max-width: 800px;
        margin: auto;
    }

    .campo-formulario {
        display: flex;
        flex-direction: column;
        gap: 9px;
    }

    .campo-formulario label {
        color: #f3f4f6;
        font-weight: 600;
        font-size: 14px;
    }

    .formulario-ativo input,
    .formulario-ativo select,
    .formulario-ativo textarea {
        width: 100%;
        box-sizing: border-box;
        padding: 13px 15px;
        background: #111827;
        color: #f9fafb;
        border: 1px solid #4b5563;
        border-radius: 8px;
        font-family: inherit;
        font-size: 14px;
        outline: none;
    }

    .formulario-ativo input:focus,
    .formulario-ativo select:focus,
    .formulario-ativo textarea:focus {
        border-color: #00a86b;
        box-shadow: 0 0 0 3px rgba(0, 168, 107, .15);
    }

    .formulario-ativo input::placeholder,
    .formulario-ativo textarea::placeholder {
        color: #6b7280;
    }

    .campo-formulario small {
        color: #9ca3af;
        font-size: 12px;
    }

    .formulario-ativo textarea {
        resize: vertical;
        min-height: 110px;
    }

    .formulario-ativo .acoes-carteiras {
        display: flex;
        gap: 12px;
        margin-top: 10px;
    }

    .formulario-ativo .acoes-carteiras .botao-link {
        padding: 13px 22px;
        border: 1px solid #00a86b;
        border-radius: 8px;
        background: #00a86b;
        color: white;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
    }

    .formulario-ativo .acoes-carteiras a.botao-link {
        background: transparent;
        border-color: #4b5563;
        color: #e5e7eb;
    }

    @media (max-width: 600px) {
        .carteiras-container {
            padding: 15px;
        }

        .cabecalho-carteiras {
            flex-direction: column;
            align-items: flex-start;
        }

        .formulario-ativo .acoes-carteiras {
            flex-direction: column;
        }
    }
</style>

</head>
<body>

<div class="carteiras-container">

    <header class="cabecalho-carteiras">
        <div>
            <h1>Cadastrar ativo</h1>

            <p>
                Carteira:
                <strong><?= $escape($carteira["nome"]) ?></strong>
            </p>

            <p>
                Informe os dados do investimento que deseja registrar.
            </p>
        </div>

        <a
            href="<?= BASE_URL ?>/ativos?carteira=<?= (int) $carteira["id"] ?>"
            class="botao-link"
        >
            Voltar aos ativos
        </a>
    </header>

    <section class="card-carteira">

        <form
            action="<?= BASE_URL ?>/ativos/criar"
            method="POST"
            class="formulario-ativo"
            data-ativos-api
            data-busca-url="<?= BASE_URL ?>/api/ativos/buscar"
            data-cotacao-url="<?= BASE_URL ?>/api/ativos/cotacao"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= $escape($_SESSION["csrf_token"]) ?>"
            >

            <input
                type="hidden"
                name="carteira_id"
                value="<?= (int) $carteira["id"] ?>"
            >

            <div class="campo-formulario">
                <label for="ticker">Ticker ou código do ativo</label>

                <input
                    type="text"
                    id="ticker"
                    name="ticker"
                    maxlength="20"
                    placeholder="Ex.: PETR4, MXRF11, IVVB11"
                    required
                >

                <small>
                    Informe o código utilizado para identificar o investimento.
                </small>
            </div>

            <div class="campo-formulario">
                <label for="categoria_id">Categoria</label>

                <select
                    id="categoria_id"
                    name="categoria_id"
                >
                    <option value="">Selecione uma categoria</option>

                    <?php foreach ($categorias as $categoria): ?>
                        <option value="<?= (int) $categoria["id"] ?>">
                            <?= $escape($categoria["nome"]) ?>
                        </option>
                    <?php endforeach; ?>

                </select>
            </div>

            <div class="campo-formulario">
                <label for="quantidade">Quantidade adquirida</label>

                <input
                    type="number"
                    id="quantidade"
                    name="quantidade"
                    min="0.0001"
                    step="0.0001"
                    placeholder="Ex.: 10"
                    required
                >
            </div>

            <div class="campo-formulario">
                <label for="preco_medio">Preço médio de compra (R$)</label>

                <input
                    type="number"
                    id="preco_medio"
                    name="preco_medio"
                    min="0.01"
                    step="0.01"
                    placeholder="Ex.: 35.50"
                    required
                >

                <small>
                    Informe o preço médio pago por unidade, não o valor total.
                </small>
            </div>

            <div class="campo-formulario">
                <label for="data_compra">Data da compra</label>

                <input
                    type="date"
                    id="data_compra"
                    name="data_compra"
                >
            </div>

            <div class="campo-formulario">
                <label for="observacao">Observações</label>

                <textarea
                    id="observacao"
                    name="observacao"
                    rows="4"
                    maxlength="60000"
                    placeholder="Informações adicionais sobre o investimento (opcional)"
                ></textarea>
            </div>

            <div class="acoes-carteiras">
                <button
                    type="submit"
                    class="botao-link"
                >
                    Salvar ativo
                </button>

                <a
                    href="<?= BASE_URL ?>/ativos?carteira=<?= (int) $carteira["id"] ?>"
                    class="botao-link"
                >
                    Cancelar
                </a>
            </div>

        </form>

    </section>

</div>

<script src="<?= BASE_URL ?>/js/ativos.js" defer></script>

</body>
</html>
