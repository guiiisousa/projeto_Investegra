
<?php

$escapar = static function ($valor): string {
    return htmlspecialchars(
        (string) ($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
};

$carteiras = $carteiras ?? [];

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Selecionar carteira | INVESTEGRA</title>

    <link
        rel="stylesheet"
        href="<?= $escapar(BASE_URL . '/css/style.css') ?>"
    >

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 20px;
            background: #f4f7f6;
            color: #26352e;
            font-family: Arial, Helvetica, sans-serif;
        }

        .selecao-container {
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
        }

        .cabecalho-selecao {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .cabecalho-selecao h1 {
            margin: 0 0 10px;
            font-size: 30px;
            color: #103d2d;
        }

        .cabecalho-selecao p {
            margin: 0;
            color: #68766f;
            line-height: 1.6;
        }

        .grade-carteiras {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(260px, 1fr));
            gap: 22px;
        }

        .cartao-carteira {
            display: flex;
            flex-direction: column;
            min-width: 0;
            padding: 24px;
            background: #ffffff;
            border: 1px solid #e0e9e4;
            border-radius: 14px;
            box-shadow: 0 4px 14px rgba(16, 61, 45, 0.05);
            transition:
                transform 0.2s,
                box-shadow 0.2s;
        }

        .cartao-carteira:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 22px rgba(16, 61, 45, 0.10);
        }

        .icone-carteira {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            margin-bottom: 18px;
            border-radius: 12px;
            background: #e4f7ec;
            color: #008b59;
            font-size: 25px;
        }

        .cartao-carteira h2 {
            margin: 0 0 12px;
            color: #103d2d;
            font-size: 21px;
            overflow-wrap: anywhere;
        }

        .descricao-carteira {
            flex: 1;
            margin: 0 0 24px;
            color: #68766f;
            font-size: 14px;
            line-height: 1.7;
            overflow-wrap: anywhere;
        }

        .botao {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 8px;
            background: #008b59;
            color: #ffffff;
            text-align: center;
            text-decoration: none;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s;
        }

        .botao:hover {
            background: #006b44;
            color: #ffffff;
        }

        .botao-secundario {
            display: inline-block;
            padding: 11px 16px;
            border: 1px solid #d3e2d9;
            border-radius: 8px;
            color: #103d2d;
            background: #ffffff;
            text-decoration: none;
            font-weight: 600;
        }

        .botao-secundario:hover {
            background: #edf6f0;
        }

        .estado-vazio {
            padding: 45px 24px;
            border: 1px dashed #cbdcd1;
            border-radius: 14px;
            background: #ffffff;
            text-align: center;
        }

        .estado-vazio h2 {
            margin-top: 0;
            color: #103d2d;
        }

        .estado-vazio p {
            margin-bottom: 24px;
            color: #68766f;
            line-height: 1.6;
        }

        @media (max-width: 600px) {
            body {
                padding: 20px 14px;
            }

            .cabecalho-selecao h1 {
                font-size: 25px;
            }
        }
    </style>
</head>

<body>

    <main class="selecao-container">

        <header class="cabecalho-selecao">
            <div>
                <h1>Meus ativos</h1>

                <p>
                    Selecione uma carteira para consultar
                    seus investimentos.
                </p>
            </div>

            <a
                href="<?= $escapar(BASE_URL . '/carteiras') ?>"
                class="botao-secundario"
            >
                Voltar às carteiras
            </a>
        </header>

        <?php if (empty($carteiras)): ?>

            <section class="estado-vazio">
                <h2>Nenhuma carteira encontrada</h2>

                <p>
                    Você precisa criar uma carteira antes
                    de cadastrar e consultar seus ativos.
                </p>

                <a
                    href="<?= $escapar(BASE_URL . '/carteiras') ?>"
                    class="botao"
                >
                    Criar minha primeira carteira
                </a>
            </section>

        <?php else: ?>

            <section class="grade-carteiras">

                <?php foreach ($carteiras as $carteira): ?>

                    <article class="cartao-carteira">

                        <div class="icone-carteira"
                            aria-hidden="true">
                            $
                        </div>

                        <h2>
                            <?= $escapar($carteira["nome"]) ?>
                        </h2>

                        <p class="descricao-carteira">
                            <?php
                            $descricao = trim(
                                (string) ($carteira["descricao"] ?? "")
                            );

                            echo $descricao !== ""
                                ? nl2br($escapar($descricao))
                                : "Consulte os ativos vinculados a esta carteira.";
                            ?>
                        </p>

                        <a
                            href="<?= $escapar(
                                BASE_URL
                                . '/ativos?carteira='
                                . (int) $carteira["id"]
                            ) ?>"
                            class="botao"
                        >
                            Ver ativos
                        </a>

                    </article>

                <?php endforeach; ?>

            </section>

        <?php endif; ?>

    </main>

</body>
</html>
