
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>INVESTEGRA MVC</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <main class="container">
        <h1>INVESTEGRA</h1>

        <p>Estrutura MVC inicializada.</p>

        <?php if ($bancoConectado): ?>
            <p class="sucesso">
                Conexão com o MySQL estabelecida!
            </p>
        <?php else: ?>
            <p class="erro">
                Não foi possível conectar ao banco.
                Confira config/database.php e o MySQL.
            </p>
        <?php endif; ?>
    </main>
</body>
</html>
