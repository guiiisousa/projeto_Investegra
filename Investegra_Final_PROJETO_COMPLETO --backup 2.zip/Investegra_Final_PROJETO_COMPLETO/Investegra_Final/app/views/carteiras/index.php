
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas carteiras | INVESTEGRA</title>

    <link rel="stylesheet" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/css/style.css">
</head>
<body>
    <main class="carteiras-container">
        <header class="cabecalho-carteiras">
            <div>
                <h1>INVESTEGRA</h1>
                <p class="subtitulo">Minhas carteiras de investimento</p>
            </div>

            <a class="botao-link" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/dashboard">
                Voltar à dashboard
            </a>
        </header>

        <div class="acoes-carteiras">
            <h2>Suas carteiras</h2>

            <a class="botao-link" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/criar">
                + Nova carteira
            </a>
        </div>

        <?php if (empty($carteiras)): ?>
            <section class="estado-vazio">
                <h3>Nenhuma carteira cadastrada</h3>
                <p>Crie sua primeira carteira para organizar seus investimentos.</p>

                <a class="botao-link" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/criar">
                    Criar primeira carteira
                </a>
            </section>
        <?php else: ?>
            <section class="lista-carteiras">
                <?php foreach ($carteiras as $carteira): ?>
                    <article class="card-carteira">
                        <h3>
                            <?= htmlspecialchars($carteira["nome"], ENT_QUOTES, "UTF-8") ?>
                        </h3>

                        <p>
                            <?= nl2br(htmlspecialchars(
                                $carteira["descricao"] ?? "Sem descrição.",
                                ENT_QUOTES,
                                "UTF-8"
                            )) ?>
                        </p>

                        <small>
                            Criada em:
                            <?= htmlspecialchars(
                                date(
                                    "d/m/Y",
                                    strtotime($carteira["criado_em"])
                                ),
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </small>

                        <div class="acoes-card">
                            <a
                                class="botao-link botao-editar"
                                href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/editar?id=<?= (int) $carteira['id'] ?>"
                            >
                                Editar
                            </a>

                            <form
                                action="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/excluir"
                                method="POST"
                                onsubmit="return confirm('Deseja realmente excluir esta carteira?');"
                            >
                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= htmlspecialchars(
                                        $_SESSION['csrf_token'] ?? '',
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= (int) $carteira['id'] ?>"
                                >

                                <button type="submit" class="botao-excluir">
                                    Excluir
                                </button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
