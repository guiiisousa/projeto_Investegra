
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova carteira | INVESTEGRA</title>

    <link rel="stylesheet" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/css/style.css">
</head>
<body>
    <main class="login-container">
        <h1>INVESTEGRA</h1>
        <p class="subtitulo">Criar carteira de investimento</p>

        <?php if (!empty($erro)): ?>
            <div class="mensagem-erro">
                <?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form
            action="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/criar"
            method="POST"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            >

            <label for="nome">Nome da carteira</label>
            <input
                type="text"
                id="nome"
                name="nome"
                maxlength="100"
                value="<?= htmlspecialchars($nome ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="descricao">Descrição (opcional)</label>
            <textarea
                id="descricao"
                name="descricao"
                rows="4"
                placeholder="Ex.: investimentos de longo prazo"
            ><?= htmlspecialchars($descricao ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

            <button type="submit">Salvar carteira</button>
        </form>

        <p class="aviso">
            <a href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras">
                Voltar às carteiras
            </a>
        </p>
    </main>
</body>
</html>
