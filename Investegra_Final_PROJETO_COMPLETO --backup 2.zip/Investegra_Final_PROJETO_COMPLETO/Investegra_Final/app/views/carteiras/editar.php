<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar carteira | INVESTEGRA</title>

    <link rel="stylesheet" href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/css/style.css">
</head>
<body>
    <main class="login-container">
        <h1>INVESTEGRA</h1>
        <p class="subtitulo">Editar carteira</p>

        <?php if (!empty($erro)): ?>
            <div class="mensagem-erro">
                <?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form
            action="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras/atualizar"
            method="POST"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            >

            <input
                type="hidden"
                name="id"
                value="<?= (int) $carteira['id'] ?>"
            >

            <label for="nome">Nome da carteira</label>
            <input
                type="text"
                id="nome"
                name="nome"
                maxlength="100"
                value="<?= htmlspecialchars($nome ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="descricao">Descrição (opcional)</label>
            <textarea
                id="descricao"
                name="descricao"
                rows="4"
            ><?= htmlspecialchars($descricao ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

            <button type="submit">Salvar alterações</button>
        </form>

        <p class="aviso">
            <a href="<?= htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8') ?>/carteiras">
                Cancelar e voltar
            </a>
        </p>
    </main>
</body>
</html>
