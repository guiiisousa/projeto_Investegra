<?php
function escaparSimulacao($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function moedaSimulacao($v): string { return 'R$ ' . number_format((float)$v, 2, ',', '.'); }
$historico = $resultado['historico'] ?? [];
$mesesGrafico = array_column($historico, 'mes');
$saldosGrafico = array_column($historico, 'saldo');
$aportesGrafico = array_column($historico, 'total_aportado');
$modoAtivo = (($_GET['modo'] ?? '') === 'ativo');
$tipo = $tipo ?? 'juros_compostos';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Simulações | INVESTEGRA</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
*{box-sizing:border-box}body{margin:0;padding:28px;background:#f4f7f6;color:#26352e;font-family:Arial,Helvetica,sans-serif}.container{max-width:1180px;margin:auto}header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:24px}h1{margin:0 0 7px;color:#087c50}h2{margin:0 0 12px;font-size:20px}.sub,.muted{color:#718078;line-height:1.6}.card{background:#fff;border:1px solid #e5ece8;border-radius:15px;padding:24px;margin-bottom:20px;box-shadow:0 4px 16px rgba(20,50,35,.04)}.tabs{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}.tab,.btn{display:inline-block;padding:12px 17px;border:0;border-radius:9px;text-decoration:none;font-weight:700;cursor:pointer;background:#087c50;color:white}.tab.off,.btn.light{background:#eaf1ed;color:#26352e}.tab.active{background:#087c50;color:#fff}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:17px}.field{display:flex;flex-direction:column;gap:7px}.field label{font-weight:700;font-size:14px}.field input,.field select{padding:12px;border:1px solid #d5dfd9;border-radius:8px;font-size:15px;width:100%;background:#fff}.actions{display:flex;gap:10px;flex-wrap:wrap;grid-column:1/-1;margin-top:5px}.error,.success,.notice{padding:13px;border-radius:9px;margin-bottom:17px;line-height:1.5}.error{background:#fdecec;color:#9a2929}.success{background:#e9f7ef;color:#17643b}.notice{background:#fff7e6;color:#795b18}.metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.metric{padding:18px;background:#f7faf8;border-radius:10px}.metric span{display:block;color:#718078;font-size:13px;margin-bottom:8px}.metric strong{font-size:22px;color:#087c50;overflow-wrap:anywhere}.chart{height:340px;position:relative}.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;min-width:760px}th,td{text-align:left;padding:12px 9px;border-bottom:1px solid #edf1ee;font-size:14px}.ticker-results{border:1px solid #d5dfd9;border-radius:8px;max-height:190px;overflow:auto}.ticker-option{display:block;width:100%;padding:10px;text-align:left;border:0;border-bottom:1px solid #edf1ee;background:white;cursor:pointer}.ticker-option:hover{background:#eef8f2}.scenario-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:18px}.scenario{border:1px solid #e2eae5;border-radius:10px;padding:15px}.scenario h3{margin:0 0 8px;font-size:16px}.scenario strong{display:block;color:#087c50;font-size:20px;margin:8px 0}.small{font-size:12px;color:#718078;line-height:1.5}.hidden{display:none!important}@media(max-width:760px){body{padding:15px}.grid,.metrics,.scenario-grid{grid-template-columns:1fr}.card{padding:18px}.metric strong{font-size:20px}}
</style>
</head>
<body><main class="container">
<header><div><h1>Simulações financeiras</h1><p class="sub">Compare métodos de capitalização ou projete cenários hipotéticos para um ativo.</p></div><a class="btn light" href="<?= escaparSimulacao(BASE_URL.'/dashboard') ?>">Voltar ao painel</a></header>
<?php if (!empty($erro)): ?><div class="error"><?= escaparSimulacao($erro) ?></div><?php endif; ?>
<?php if (!empty($_GET['salvo'])): ?><div class="success">Simulação salva no seu histórico.</div><?php endif; ?>
<nav class="tabs">
<a class="tab <?= !$modoAtivo ? 'active' : 'off' ?>" href="<?= escaparSimulacao(BASE_URL.'/simulacoes') ?>">Juros simples e compostos</a>
<a class="tab <?= $modoAtivo ? 'active' : 'off' ?>" href="<?= escaparSimulacao(BASE_URL.'/simulacoes?modo=ativo') ?>">Simular por ativo</a>
</nav>
<?php if (!$modoAtivo): ?>
<section class="card"><h2>Simulador de juros</h2><p class="muted">Use os mesmos parâmetros para comparar juros simples e compostos. Os aportes são considerados no fim de cada mês.</p>
<form method="get" action="<?= escaparSimulacao(BASE_URL.'/simulacoes') ?>"><input type="hidden" name="calcular" value="1"><div class="grid">
<div class="field"><label for="tipo">Método de cálculo</label><select id="tipo" name="tipo"><option value="juros_compostos" <?= $tipo==='juros_compostos'?'selected':'' ?>>Juros compostos</option><option value="juros_simples" <?= $tipo==='juros_simples'?'selected':'' ?>>Juros simples</option></select></div>
<div class="field"><label for="capital_inicial">Capital inicial (R$)</label><input id="capital_inicial" name="capital_inicial" type="number" min="0" max="100000000" step="0.01" required value="<?= escaparSimulacao($entrada['capital_inicial']??1000) ?>"></div>
<div class="field"><label for="aporte_mensal">Aporte mensal (R$)</label><input id="aporte_mensal" name="aporte_mensal" type="number" min="0" max="10000000" step="0.01" required value="<?= escaparSimulacao($entrada['aporte_mensal']??200) ?>"></div>
<div class="field"><label for="taxa_anual">Taxa anual hipotética (%)</label><input id="taxa_anual" name="taxa_anual" type="number" min="-100" max="100" step="0.01" required value="<?= escaparSimulacao($entrada['taxa_anual']??10) ?>"></div>
<div class="field"><label for="prazo_meses">Prazo (meses)</label><input id="prazo_meses" name="prazo_meses" type="number" min="1" max="600" required value="<?= escaparSimulacao($entrada['prazo_meses']??60) ?>"></div>
<div class="actions"><button class="btn" type="submit">Calcular projeção</button><a class="btn light" href="<?= escaparSimulacao(BASE_URL.'/simulacoes') ?>">Limpar</a></div>
</div></form></section>
<?php if ($resultado !== null): ?>
<section class="card"><h2>Resultado — <?= $tipo==='juros_simples'?'juros simples':'juros compostos' ?></h2><div class="metrics">
<div class="metric"><span>Montante final estimado</span><strong><?= escaparSimulacao(moedaSimulacao($resultado['valor_final'])) ?></strong></div>
<div class="metric"><span>Total aportado</span><strong><?= escaparSimulacao(moedaSimulacao($resultado['total_aportado'])) ?></strong></div>
<div class="metric"><span>Juros estimados</span><strong><?= escaparSimulacao(moedaSimulacao($resultado['rendimento_estimado'])) ?></strong></div>
</div><div class="chart" style="margin-top:24px"><canvas id="graficoJuros"></canvas></div>
<form method="post" action="<?= escaparSimulacao(BASE_URL.'/simulacoes/salvar') ?>" style="margin-top:18px"><input type="hidden" name="csrf_token" value="<?= escaparSimulacao($csrfToken) ?>"><input type="hidden" name="tipo_simulacao" value="<?= escaparSimulacao($tipo) ?>"><?php foreach (['capital_inicial','aporte_mensal','taxa_anual','prazo_meses'] as $f): ?><input type="hidden" name="<?= $f ?>" value="<?= escaparSimulacao($entrada[$f]) ?>"><?php endforeach; ?><button class="btn" type="submit">Salvar no histórico</button></form>
</section>
<?php endif; ?>
<div class="notice">A projeção é matemática e hipotética. Não representa rentabilidade garantida. Não considera impostos, taxas, inflação ou oscilações reais de mercado. Em juros simples, os juros não são incorporados à base de cálculo; em compostos, há capitalização mensal equivalente à taxa anual informada.</div>
<?php else: ?>
<section class="card"><h2>Simulação de um ativo específico</h2><p class="muted">Pesquise um ticker na BRAPI, confira a cotação de referência e defina taxas hipotéticas para três cenários. A taxa é uma hipótese editável, não uma previsão.</p>
<form id="formAtivo" method="post" action="<?= escaparSimulacao(BASE_URL.'/simulacoes/salvar') ?>"><input type="hidden" name="csrf_token" value="<?= escaparSimulacao($csrfToken) ?>"><input type="hidden" name="tipo_simulacao" value="ativo"><input type="hidden" name="taxa_anual" id="taxaEscolhida" value="8"><input type="hidden" name="cenario" id="cenarioEscolhido" value="moderado">
<div class="grid">
<div class="field"><label for="buscaTicker">Buscar ativo (ticker ou nome)</label><input id="buscaTicker" autocomplete="off" placeholder="Ex.: PETR4, ITUB4, HGLG11"><div id="resultadosTicker" class="ticker-results hidden"></div><input type="hidden" id="ticker" name="ticker" required></div>
<div class="field"><label>Cotação atual de referência</label><input id="precoReferencia" type="text" readonly placeholder="Selecione um ativo"><span id="nomeAtivo" class="small">A cotação será consultada pela BRAPI.</span></div>
<div class="field"><label for="capitalAtivo">Investimento inicial (R$)</label><input id="capitalAtivo" name="capital_inicial" type="number" min="0" max="100000000" step="0.01" value="1000" required></div>
<div class="field"><label for="aporteAtivo">Aporte mensal (R$)</label><input id="aporteAtivo" name="aporte_mensal" type="number" min="0" max="10000000" step="0.01" value="200" required></div>
<div class="field"><label for="prazoAtivo">Prazo (meses)</label><input id="prazoAtivo" name="prazo_meses" type="number" min="1" max="600" value="60" required></div>
<div class="field"><label for="cenarioSalvar">Cenário a salvar</label><select id="cenarioSalvar"><option value="pessimista">Pessimista</option><option value="moderado" selected>Moderado</option><option value="otimista">Otimista</option></select></div>
<div class="field"><label for="taxaPessimista">Taxa anual — pessimista (%)</label><input id="taxaPessimista" type="number" step="0.01" min="-100" max="100" value="-5"></div>
<div class="field"><label for="taxaModerada">Taxa anual — moderado (%)</label><input id="taxaModerada" type="number" step="0.01" min="-100" max="100" value="8"></div>
<div class="field"><label for="taxaOtimista">Taxa anual — otimista (%)</label><input id="taxaOtimista" type="number" step="0.01" min="-100" max="100" value="15"></div>
</div>
<div id="erroAtivo" class="error hidden" style="margin-top:15px"></div>
<div class="scenario-grid" id="resultadosCenarios"><div class="scenario"><h3>Pessimista</h3><strong id="resPessimista">—</strong><span class="small">Taxa hipotética: <b id="labelPessimista">-5%</b></span></div><div class="scenario"><h3>Moderado</h3><strong id="resModerado">—</strong><span class="small">Taxa hipotética: <b id="labelModerado">8%</b></span></div><div class="scenario"><h3>Otimista</h3><strong id="resOtimista">—</strong><span class="small">Taxa hipotética: <b id="labelOtimista">15%</b></span></div></div>
<p class="small" style="margin-top:14px">A projeção usa capitalização composta mensal equivalente à taxa anual escolhida e supõe que os aportes sejam feitos no fim de cada mês. Não modela dividendos, proventos, custos, liquidez, variação cambial ou mudanças reais no preço de compra de cada aporte.</p>
<div class="actions" style="margin-top:18px"><button class="btn" type="submit">Salvar cenário selecionado</button></div>
</form></section>
<?php endif; ?>
<section class="card"><h2>Histórico de simulações</h2><?php if (empty($historicoSimulacoes)): ?><p class="muted">Você ainda não salvou simulações.</p><?php else: ?><div class="table-wrap"><table><thead><tr><th>Data</th><th>Modalidade</th><th>Ativo / método</th><th>Capital inicial</th><th>Aporte mensal</th><th>Taxa anual</th><th>Prazo</th><th>Montante estimado</th></tr></thead><tbody>
<?php foreach ($historicoSimulacoes as $item): ?><tr><td><?= escaparSimulacao(date('d/m/Y H:i',strtotime($item['criado_em']))) ?></td><td><?= ($item['tipo_simulacao']??'juros')==='ativo'?'Ativo':'Juros' ?></td><td><?= escaparSimulacao(($item['tipo_simulacao']??'juros')==='ativo' ? (($item['ticker']??'').' — '.($item['cenario']??'')) : ucfirst($item['tipo_juros'])) ?></td><td><?= escaparSimulacao(moedaSimulacao($item['aporte_inicial'])) ?></td><td><?= escaparSimulacao(moedaSimulacao($item['aporte_mensal'])) ?></td><td><?= escaparSimulacao(number_format((float)$item['rentabilidade'],2,',','.')) ?>%</td><td><?= (int)$item['prazo_anos'] ?> ano(s)</td><td><b><?= escaparSimulacao(moedaSimulacao($item['montante'])) ?></b></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
</main>
<?php if (!$modoAtivo && $resultado !== null): ?>
<script>
const meses = <?= json_encode($mesesGrafico, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const saldos = <?= json_encode($saldosGrafico, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const aportes = <?= json_encode($aportesGrafico, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
new Chart(document.getElementById('graficoJuros'),{type:'line',data:{labels:meses.map(m=>m===0?'Início':'Mês '+m),datasets:[{label:'Patrimônio projetado',data:saldos,borderColor:'#00a86b',backgroundColor:'rgba(0,168,107,.12)',fill:true,tension:.2,borderWidth:3},{label:'Total aportado',data:aportes,borderColor:'#247ba0',fill:false,tension:.1,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,interaction:{intersect:false,mode:'index'},plugins:{tooltip:{callbacks:{label:c=>c.dataset.label+': '+Number(c.raw).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}}},scales:{y:{beginAtZero:true,ticks:{callback:v=>Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL',maximumFractionDigits:0})}}}}});
</script><?php endif; ?>
<?php if ($modoAtivo): ?>
<script>
const baseUrl = <?= json_encode(BASE_URL, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const busca=document.getElementById('buscaTicker'), lista=document.getElementById('resultadosTicker'), ticker=document.getElementById('ticker'), preco=document.getElementById('precoReferencia'), nome=document.getElementById('nomeAtivo');
let timerBusca;
const dinheiro=v=>Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
async function consultarCotacao(symbol){
 ticker.value=symbol; lista.classList.add('hidden'); busca.value=symbol; nome.textContent='Consultando cotação...';
 try{const r=await fetch(baseUrl+'/api/ativos/cotacao?ticker='+encodeURIComponent(symbol));const j=await r.json();if(!j.sucesso)throw new Error(j.mensagem||'Cotação indisponível');preco.value=dinheiro(j.cotacao.preco_atual);nome.textContent=j.cotacao.nome+' · '+j.cotacao.ticker+' · '+(j.cotacao.moeda||'BRL');calcularCenarios();}
 catch(e){preco.value='';nome.textContent=e.message;}
}
busca.addEventListener('input',()=>{clearTimeout(timerBusca);ticker.value='';timerBusca=setTimeout(async()=>{const q=busca.value.trim();if(q.length<2){lista.classList.add('hidden');return;}try{const r=await fetch(baseUrl+'/api/ativos/buscar?q='+encodeURIComponent(q));const j=await r.json();lista.innerHTML='';(j.resultados||[]).forEach(a=>{const s=a.symbol||a.ticker;if(!s)return;const b=document.createElement('button');b.type='button';b.className='ticker-option';b.textContent=s+' — '+(a.shortName||a.longName||a.name||'Ativo');b.addEventListener('click',()=>consultarCotacao(s));lista.appendChild(b);});lista.classList.toggle('hidden',!lista.children.length);}catch(e){lista.classList.add('hidden');}},300);});
function valorFinal(cap,ap,rate,months){const rm=Math.pow(1+rate/100,1/12)-1;let v=cap;for(let i=0;i<months;i++)v=v*(1+rm)+ap;return v;}
function calcularCenarios(){const cap=Number(document.getElementById('capitalAtivo').value),ap=Number(document.getElementById('aporteAtivo').value),n=Number(document.getElementById('prazoAtivo').value);const keys=[['Pessimista','taxaPessimista'],['Moderado','taxaModerada'],['Otimista','taxaOtimista']];keys.forEach(([label,id])=>{const rate=Number(document.getElementById(id).value);document.getElementById('label'+label).textContent=rate.toLocaleString('pt-BR')+'%';document.getElementById('res'+label).textContent=(Number.isFinite(cap+ap+rate+n)&&n>0)?dinheiro(valorFinal(cap,ap,rate,n)):'—';});}
['capitalAtivo','aporteAtivo','prazoAtivo','taxaPessimista','taxaModerada','taxaOtimista'].forEach(id=>document.getElementById(id).addEventListener('input',calcularCenarios));
document.getElementById('formAtivo').addEventListener('submit',e=>{const chosen=document.getElementById('cenarioSalvar').value;const map={pessimista:'taxaPessimista',moderado:'taxaModerada',otimista:'taxaOtimista'};if(!ticker.value){e.preventDefault();const box=document.getElementById('erroAtivo');box.textContent='Selecione um ativo na lista de resultados.';box.classList.remove('hidden');return;}document.getElementById('taxaEscolhida').value=document.getElementById(map[chosen]).value;document.getElementById('cenarioEscolhido').value=chosen;});
calcularCenarios();
</script><?php endif; ?>
</body></html>
