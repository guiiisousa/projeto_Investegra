<?php

namespace App\Controllers;

use App\Services\BrapiService;

class BrapiController
{
    private function responder(
        array $dados,
        int $status = 200
    ): void {
        http_response_code($status);

        header("Content-Type: application/json; charset=UTF-8");
        header("Cache-Control: no-store");

        echo json_encode(
            $dados,
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        );

        exit;
    }

    private function exigirLogin(): void
    {
        if (!isset($_SESSION["id"])) {
            $this->responder([
                "sucesso" => false,
                "mensagem" => "É necessário fazer login."
            ], 401);
        }
    }

    /**
     * GET /api/ativos/buscar?q=PETR
     */
    public function buscar(): void
    {
        $this->exigirLogin();

        $termo = $_GET["q"] ?? "";

        if (!is_string($termo)) {
            $this->responder([
                "sucesso" => false,
                "mensagem" => "Termo de pesquisa inválido."
            ], 400);
        }

        $termo = trim($termo);

        if (strlen($termo) < 2) {
            $this->responder([
                "sucesso" => true,
                "resultados" => []
            ]);
        }

        if (strlen($termo) > 60) {
            $this->responder([
                "sucesso" => false,
                "mensagem" => "O termo de pesquisa é muito longo."
            ], 400);
        }

        try {
            $servico = new BrapiService();

            $resultados = $servico->buscarTickers($termo);

            $this->responder([
                "sucesso" => true,
                "resultados" => $resultados
            ]);
        } catch (\Throwable $erro) {
            error_log(
                "Erro na busca de ativos da brapi: "
                . $erro->getMessage()
            );

            $this->responder([
                "sucesso" => false,
                "mensagem" => "Não foi possível pesquisar os ativos."
            ], 502);
        }
    }

    /**
     * GET /api/ativos/cotacao?ticker=PETR4
     */
    public function cotacao(): void
    {
        $this->exigirLogin();

        $ticker = $_GET["ticker"] ?? "";

        if (!is_string($ticker)) {
            $this->responder([
                "sucesso" => false,
                "mensagem" => "Ticker inválido."
            ], 400);
        }

        $ticker = strtoupper(trim($ticker));

        if (!preg_match('/^[A-Z0-9.-]{1,20}$/', $ticker)) {
            $this->responder([
                "sucesso" => false,
                "mensagem" => "Informe um ticker válido."
            ], 400);
        }

        try {
            $servico = new BrapiService();

            $cotacao = $servico->buscarCotacao($ticker);

            $this->responder([
                "sucesso" => true,
                "cotacao" => $cotacao
            ]);
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao consultar cotação da brapi: "
                . $erro->getMessage()
            );

            $this->responder([
                "sucesso" => false,
                "mensagem" => "Não foi possível obter a cotação. Verifique o ticker e as permissões da API."
            ], 502);
        }
    }
}
