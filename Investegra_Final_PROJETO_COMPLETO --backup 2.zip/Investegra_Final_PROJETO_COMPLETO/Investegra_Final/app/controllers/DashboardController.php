<?php

namespace App\Controllers;

use App\Models\Carteira;
use App\Models\Ativo;
use App\Services\BrapiService;

class DashboardController
{
    public function index(): void
    {
        // Verifica se o usuário está autenticado.
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }

        $usuarioId = (int) $_SESSION["id"];
        $nomeUsuario = $_SESSION["nome"] ?? "Investidor";

        // Garante a existência do token CSRF.
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
        }

        $csrfToken = $_SESSION["csrf_token"];

        // Recupera as carteiras do usuário.
        $modeloCarteira = new Carteira();
        $carteiras = $modeloCarteira->listarPorUsuario($usuarioId);

        // Inicializa os indicadores.
        $quantidadeCarteiras = count($carteiras);
        $quantidadeAtivos = 0;
        $quantidadeCotada = 0;

        $totalInvestido = 0.0;
        $totalMercado = 0.0;
        $totalResultado = 0.0;

        $distribuicaoCategorias = [];
        $ultimosAtivos = [];

        $modeloAtivo = new Ativo();
        $servicoBrapi = new BrapiService();

        // Percorre as carteiras do usuário.
        foreach ($carteiras as $carteira) {
            $carteiraId = (int) $carteira["id"];

            $ativosCarteira = $modeloAtivo
                ->listarPorCarteiraEUsuario($carteiraId, $usuarioId);

            foreach ($ativosCarteira as $ativo) {
                $quantidadeAtivos++;

                $ticker = $ativo["ticker"] ?? "";
                $categoria = $ativo["categoria"] ?? "Sem categoria";

                $quantidade = (float) $ativo["quantidade"];
                $precoMedio = (float) $ativo["preco_medio"];

                $valorInvestido = $quantidade * $precoMedio;

                $totalInvestido += $valorInvestido;

                // Agrupa o valor investido por categoria.
                if (!isset($distribuicaoCategorias[$categoria])) {
                    $distribuicaoCategorias[$categoria] = 0.0;
                }

                $distribuicaoCategorias[$categoria] += $valorInvestido;

                // Guarda informações básicas para a listagem do dashboard.
                $ativoDashboard = [
                    "ticker" => $ticker,
                    "categoria" => $categoria,
                    "quantidade" => $quantidade,
                    "valor_investido" => $valorInvestido,
                    "carteira_id" => $carteiraId,
                    "carteira_nome" => $carteira["nome"] ?? "Carteira",
                    "cotacao_atual" => null,
                    "valor_mercado" => null,
                    "resultado" => null,
                    "resultado_percentual" => null,
                ];

                // Consulta a cotação atual do ativo.
                try {
                    $cotacao = $servicoBrapi->buscarCotacao($ticker);

                    $precoAtual = (float) $cotacao["preco_atual"];
                    $moeda = $cotacao["moeda"] ?? "BRL";

                    $ativoDashboard["cotacao_atual"] = $precoAtual;

                    // Só compara valores quando estão na mesma moeda.
                    if ($moeda === "BRL") {
                        $valorMercado = $quantidade * $precoAtual;
                        $resultado = $valorMercado - $valorInvestido;

                        $percentual = $valorInvestido > 0
                            ? ($resultado / $valorInvestido) * 100
                            : 0.0;

                        $ativoDashboard["valor_mercado"] = $valorMercado;
                        $ativoDashboard["resultado"] = $resultado;
                        $ativoDashboard["resultado_percentual"] = $percentual;

                        $totalMercado += $valorMercado;
                        $totalResultado += $resultado;
                        $quantidadeCotada++;
                    }
                } catch (\Throwable $erro) {
                    // Uma falha na API não deve impedir o dashboard de abrir.
                    error_log(
                        "Erro ao consultar " . $ticker . ": "
                        . $erro->getMessage()
                    );
                }

                $ultimosAtivos[] = $ativoDashboard;
            }
        }

        // Ordena os ativos pelo ticker para manter a listagem previsível.
        usort(
            $ultimosAtivos,
            static fn(array $a, array $b): int =>
                strcmp($a["ticker"], $b["ticker"])
        );

        // Calcula a participação percentual de cada categoria.
        $distribuicaoPercentual = [];

        foreach ($distribuicaoCategorias as $categoria => $valor) {
            $distribuicaoPercentual[$categoria] = $totalInvestido > 0
                ? ($valor / $totalInvestido) * 100
                : 0.0;
        }

        // Indica quantos ativos não tiveram cálculo de mercado em reais.
        $ativosSemCotacao = $quantidadeAtivos - $quantidadeCotada;

        
        // Disponibiliza os dados para a view.
        require dirname(__DIR__) . "/views/dashboard/index.php";

    }
}