<?php

namespace App\Controllers;

use App\Core\Database;

class HomeController
{
    public function index(): void
    {
        $bancoConectado = false;

        try {
            Database::conectar();
            $bancoConectado = true;
        } catch (\Throwable $erro) {
            $bancoConectado = false;
        }

        require dirname(__DIR__)
            . "/views/home/index.php";
    }
}
