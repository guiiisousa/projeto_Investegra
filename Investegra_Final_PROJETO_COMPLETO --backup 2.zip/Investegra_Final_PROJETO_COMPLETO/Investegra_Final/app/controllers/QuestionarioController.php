<?php

namespace App\Controllers;

use App\Models\Usuario;

class QuestionarioController
{
    private array $perguntas = [
        1 => [
            "pergunta" => "Como você reagiria se seus investimentos sofressem uma queda significativa?",
            "opcoes" => [
                0 => "Preferiria reduzir o risco e preservar meu dinheiro.",
                1 => "Analisaria a situação antes de tomar uma decisão.",
                2 => "Aceitaria a volatilidade pensando no longo prazo."
            ]
        ],
        2 => [
            "pergunta" => "Qual é sua principal prioridade ao investir?",
            "opcoes" => [
                0 => "Preservar meu patrimônio.",
                1 => "Equilibrar segurança e crescimento.",
                2 => "Buscar maior crescimento, aceitando riscos."
            ]
        ],
        3 => [
            "pergunta" => "Quando pretende utilizar a maior parte desse dinheiro?",
            "opcoes" => [
                0 => "Em até 1 ano.",
                1 => "Entre 1 e 5 anos.",
                2 => "Em mais de 5 anos."
            ]
        ],
        4 => [
            "pergunta" => "Como você se sente diante de investimentos com oscilações frequentes?",
            "opcoes" => [
                0 => "Prefiro evitá-los.",
                1 => "Aceito oscilações moderadas.",
                2 => "Aceito oscilações elevadas."
            ]
        ],
        5 => [
            "pergunta" => "Como você avalia sua experiência com investimentos?",
            "opcoes" => [
                0 => "Ainda estou aprendendo.",
                1 => "Já conheço alguns investimentos.",
                2 => "Tenho experiência e compreendo os riscos."
            ]
        ],
        6 => [
            "pergunta" => "Qual alternativa descreve melhor seu objetivo?",
            "opcoes" => [
                0 => "Priorizar segurança e liquidez.",
                1 => "Combinar segurança e valorização.",
                2 => "Priorizar crescimento no longo prazo."
            ]
        ]
    ];

    private function exigirLogin(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }
    }

    private function garantirCsrf(): void
    {
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(
                random_bytes(32)
            );
        }
    }

    public function index(): void
    {
        $this->exigirLogin();
        $this->garantirCsrf();

        $modelo = new Usuario();

        try {
            $usuario = $modelo->buscarPerfilPorId(
                (int) $_SESSION["id"]
            );
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao carregar questionário: "
                . $erro->getMessage()
            );

            http_response_code(500);
            echo "Não foi possível carregar o questionário.";
            return;
        }

        if (!$usuario) {
            http_response_code(404);
            echo "Usuário não encontrado.";
            return;
        }

        $perguntas = $this->perguntas;
        $csrfToken = $_SESSION["csrf_token"];
        $erro = null;

        $mostrarQuestionario =
            $usuario["score_risco"] === null ||
            isset($_GET["refazer"]);

        $resultado = null;

        if (!$mostrarQuestionario) {
            $resultado = [
                "score" => (int) $usuario["score_risco"],
                "perfil" => $usuario["perfil_risco"]
            ];
        }

        require dirname(__DIR__)
            . "/views/questionario/index.php";
    }

    public function salvar(): void
    {
        $this->exigirLogin();
        $this->garantirCsrf();

        if (
            $_SERVER["REQUEST_METHOD"] !== "POST" ||
            !isset($_POST["csrf_token"]) ||
            !hash_equals(
                $_SESSION["csrf_token"],
                (string) $_POST["csrf_token"]
            )
        ) {
            http_response_code(403);
            echo "Solicitação inválida. Atualize a página e tente novamente.";
            return;
        }

        $score = 0;

        foreach ($this->perguntas as $numero => $pergunta) {
            $campo = "q" . $numero;
            $resposta = $_POST[$campo] ?? null;

            if (
                !is_string($resposta) ||
                !in_array($resposta, ["0", "1", "2"], true)
            ) {
                $this->redirecionarComErro();
                return;
            }

            $score += (int) $resposta;
        }

        if ($score <= 4) {
            $perfil = "Conservador";
        } elseif ($score <= 8) {
            $perfil = "Moderado";
        } else {
            $perfil = "Arrojado";
        }

        try {
            $modelo = new Usuario();

            $salvou = $modelo->salvarResultadoRisco(
                (int) $_SESSION["id"],
                $score,
                $perfil
            );

            if (!$salvou) {
                throw new \RuntimeException(
                    "Não foi possível salvar o resultado."
                );
            }
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao salvar perfil de risco: "
                . $erro->getMessage()
            );

            $this->redirecionarComErro();
            return;
        }

        header(
            "Location: " . BASE_URL . "/questionario?resultado=1"
        );
        exit;
    }

    private function redirecionarComErro(): void
    {
        $_SESSION["questionario_erro"] =
            "Responda às seis perguntas antes de continuar.";

        header(
            "Location: " . BASE_URL . "/questionario?refazer=1"
        );
        exit;
    }
}
