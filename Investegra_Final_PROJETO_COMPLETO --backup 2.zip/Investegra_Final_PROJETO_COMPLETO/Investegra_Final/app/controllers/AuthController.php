<?php

namespace App\Controllers;

use App\Models\Usuario;

class AuthController
{
    public function loginForm(): void
    {
        if (isset($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/dashboard");
            exit;
        }

        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(
                random_bytes(32)
            );
        }

        $erro = null;

        require dirname(__DIR__)
            . "/views/auth/login.php";
    }

    public function autenticar(): void
    {
        if (
            !isset($_POST["csrf_token"]) ||
            !isset($_SESSION["csrf_token"]) ||
            !hash_equals(
                $_SESSION["csrf_token"],
                (string) $_POST["csrf_token"]
            )
        ) {
            http_response_code(403);
            $erro = "Sessão inválida. Atualize a página e tente novamente.";

            require dirname(__DIR__)
                . "/views/auth/login.php";
            return;
        }

        $email = trim($_POST["email"] ?? "");
        $senha = $_POST["senha"] ?? "";

        if (
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            $senha === ""
        ) {
            $erro = "Informe um e-mail válido e sua senha.";

            require dirname(__DIR__)
                . "/views/auth/login.php";
            return;
        }

        try {
            $modelo = new Usuario();
            $usuario = $modelo->autenticar($email, $senha);
        } catch (\Throwable $e) {
            error_log(
                "Erro durante autenticação: " . $e->getMessage()
            );

            http_response_code(500);
            $erro = "Não foi possível realizar o login. Tente novamente.";

            require dirname(__DIR__)
                . "/views/auth/login.php";
            return;
        }

        if (!$usuario) {
            $erro = "E-mail ou senha incorretos.";

            require dirname(__DIR__)
                . "/views/auth/login.php";
            return;
        }

        // Evita reutilização do identificador anterior da sessão.
        session_regenerate_id(true);

        // Mantém a chave que o INVESTEGRA antigo já utiliza.
        $_SESSION["id"] = (int) $usuario["id"];
        $_SESSION["nome"] = $usuario["nome"];
        $_SESSION["email"] = $usuario["email"];

        // Gera um novo token para a sessão autenticada.
        $_SESSION["csrf_token"] = bin2hex(
            random_bytes(32)
        );

        header("Location: " . BASE_URL . "/dashboard");
        exit;
    }

    
    public function logout(): void
    {
        if (
            !isset($_POST["csrf_token"]) ||
            !isset($_SESSION["csrf_token"]) ||
            !hash_equals(
                $_SESSION["csrf_token"],
                (string) $_POST["csrf_token"]
            )
        ) {
            http_response_code(403);
            echo "Requisição inválida.";
            return;
        }

        $_SESSION = [];

        if (ini_get("session.use_cookies")) {
            $parametros = session_get_cookie_params();

            setcookie(
                session_name(),
                "",
                time() - 42000,
                $parametros["path"],
                $parametros["domain"],
                $parametros["secure"],
                $parametros["httponly"]
            );
        }

        session_destroy();

        header("Location: " . BASE_URL . "/login");
        exit;
    }

}
