<?php

namespace App\Controllers;

use App\Services\ChatIAService;
use App\Services\ContextoFinanceiroService;

class ChatController
{
    /**
     * Exibe a página do chat.
     */
    public function index(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }

        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
        }

        $mensagens = $_SESSION["chat_ollama"] ?? [];
        $erroChat = $_SESSION["chat_erro"] ?? null;

        if (!is_array($mensagens)) {
            $mensagens = [];
        }

        unset($_SESSION["chat_erro"]);

        require __DIR__ . "/../views/chat/index.php";
    }

    /**
     * Processa uma mensagem enviada pelo usuário.
     */
    public function enviar(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        // Validação do token CSRF.
        $tokenEnviado = $_POST["csrf_token"] ?? "";
        $tokenSessao = $_SESSION["csrf_token"] ?? "";

        if (
            !is_string($tokenEnviado) ||
            !is_string($tokenSessao) ||
            $tokenSessao === "" ||
            !hash_equals($tokenSessao, $tokenEnviado)
        ) {
            $_SESSION["chat_erro"] =
                "Sua sessão expirou. Atualize a página e tente novamente.";

            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        // Validação da mensagem.
        $mensagem = $_POST["mensagem"] ?? "";

        if (!is_string($mensagem)) {
            $_SESSION["chat_erro"] = "Mensagem inválida.";

            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        $mensagem = trim($mensagem);

        if ($mensagem === "") {
            $_SESSION["chat_erro"] =
                "Digite uma mensagem antes de enviar.";

            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        if (mb_strlen($mensagem, "UTF-8") > 4000) {
            $_SESSION["chat_erro"] =
                "Sua mensagem ultrapassou o limite de 4.000 caracteres.";

            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        // Recupera o histórico da sessão.
        $historico = $_SESSION["chat_ollama"] ?? [];

        if (!is_array($historico)) {
            $historico = [];
        }

        try {
            /*
             * 1. Prepara o contexto financeiro do usuário.
             *
             * O ID vem da sessão autenticada, nunca de um
             * campo enviado pelo formulário.
             */
            $contextoFinanceiro = "";

            try {
                $contextoService = new ContextoFinanceiroService();

                $contextoFinanceiro = $contextoService->gerarContexto(
                    (int) $_SESSION["id"]
                );

            } catch (\Throwable $e) {
                error_log(
                    "[INVESTEGRA CONTEXTO] " .
                    get_class($e) . ": " .
                    $e->getMessage() .
                    " em " . $e->getFile() .
                    ":" . $e->getLine()
                );

                /*
                 * Se o contexto não puder ser carregado,
                 * o chat ainda poderá responder perguntas gerais.
                 * A IA será instruída a não inventar dados financeiros.
                 */
                $contextoFinanceiro =
                    "Não foi possível consultar os dados financeiros "
                    . "do usuário nesta solicitação. "
                    . "Não invente saldos, ativos ou valores da carteira.";
            }

            /*
             * 2. Consulta o serviço central de IA.
             *
             * Atualmente, o ChatIAService utiliza a Ollama
             * conforme config/ia.php.
             */
            $chatIA = new ChatIAService();

            $resultado = $chatIA->conversar(
                $mensagem,
                $historico,
                $contextoFinanceiro
            );

            // Verifica o retorno do serviço.
            if (
                !is_array($resultado) ||
                empty($resultado["sucesso"]) ||
                !isset($resultado["resposta"]) ||
                !is_string($resultado["resposta"])
            ) {
                $detalhe = is_array($resultado)
                    ? ($resultado["erro"] ?? "Resposta inválida do serviço.")
                    : "O serviço retornou um resultado inválido.";

                error_log(
                    "[INVESTEGRA CHAT] Falha na consulta: " . $detalhe
                );

                $_SESSION["chat_erro"] =
                    "Não foi possível consultar o assistente. "
                    . "Tente novamente em instantes.";

                header("Location: " . BASE_URL . "/chat");
                exit;
            }

            $resposta = trim($resultado["resposta"]);

            if ($resposta === "") {
                error_log(
                    "[INVESTEGRA CHAT] O serviço retornou uma resposta vazia."
                );

                $_SESSION["chat_erro"] =
                    "O assistente não retornou uma resposta. Tente novamente.";

                header("Location: " . BASE_URL . "/chat");
                exit;
            }

            /*
             * 3. Atualiza o histórico somente após uma resposta válida.
             */
            $historico[] = [
                "role" => "user",
                "content" => $mensagem
            ];

            $historico[] = [
                "role" => "assistant",
                "content" => $resposta
            ];

            // Mantém no máximo 10 mensagens na sessão.
            $_SESSION["chat_ollama"] = array_slice(
                $historico,
                -10
            );

            unset($_SESSION["chat_erro"]);

        } catch (\Throwable $e) {
            error_log(
                "[INVESTEGRA CHAT] " .
                get_class($e) . ": " .
                $e->getMessage() .
                " em " . $e->getFile() .
                ":" . $e->getLine()
            );

            $_SESSION["chat_erro"] =
                "Ocorreu um erro interno ao consultar o assistente. "
                . "Verifique o log do PHP para identificar a causa.";
        }

        header("Location: " . BASE_URL . "/chat");
        exit;
    }

    /**
     * Limpa o histórico da conversa.
     */
    public function limpar(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        $tokenEnviado = $_POST["csrf_token"] ?? "";
        $tokenSessao = $_SESSION["csrf_token"] ?? "";

        if (
            !is_string($tokenEnviado) ||
            !is_string($tokenSessao) ||
            $tokenSessao === "" ||
            !hash_equals($tokenSessao, $tokenEnviado)
        ) {
            $_SESSION["chat_erro"] =
                "Sua sessão expirou. Atualize a página e tente novamente.";

            header("Location: " . BASE_URL . "/chat");
            exit;
        }

        unset($_SESSION["chat_ollama"]);
        unset($_SESSION["chat_erro"]);

        header("Location: " . BASE_URL . "/chat");
        exit;
    }
}
