<?php

namespace App\Controllers;

use App\Models\Usuario;

class CadastroController
{
    public function formulario(): void
    {
        if (isset($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/dashboard");
            exit;
        }

        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
        }

        $erro = null;
        $nome = "";
        $email = "";
        $documento = "";
        $tipoUsuario = "PF";

        require dirname(__DIR__) . "/views/auth/cadastro.php";
    }

    public function cadastrar(): void
    {
        if (isset($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/dashboard");
            exit;
        }

        $nome = trim($_POST["nome"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $documento = trim($_POST["documento"] ?? "");
        $tipoUsuario = strtoupper(trim($_POST["tipo_usuario"] ?? "PF"));
        $senha = $_POST["senha"] ?? "";
        $confirmacao = $_POST["confirmacao"] ?? "";

        $erro = null;

        if (
            !isset($_POST["csrf_token"]) ||
            !isset($_SESSION["csrf_token"]) ||
            !hash_equals(
                $_SESSION["csrf_token"],
                (string) $_POST["csrf_token"]
            )
        ) {
            http_response_code(403);
            $erro = "Sessão inválida. Atualize a página e tente novamente.";

            if (empty($_SESSION["csrf_token"])) {
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
            }

            require dirname(__DIR__) . "/views/auth/cadastro.php";
            return;
        }

        if (
            $nome === "" ||
            strlen($nome) > 100 ||
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($email) > 150 ||
            !in_array($tipoUsuario, ["PF", "PJ"], true) ||
            strlen($senha) < 8 ||
            strlen($senha) > 4096 ||
            $senha !== $confirmacao
        ) {
            $erro = "Confira os dados. Informe um nome, e-mail válido, tipo de cadastro e uma senha com pelo menos 8 caracteres, confirmada corretamente.";

            require dirname(__DIR__) . "/views/auth/cadastro.php";
            return;
        }

        // Normaliza o documento e valida o tipo selecionado.
        if ($tipoUsuario === "PF") {
            if (!preg_match('/^[0-9.\-\s]+$/', $documento)) {
                $erro = "O CPF informado contém caracteres inválidos.";
            } else {
                $documento = preg_replace('/\D/', '', $documento);

                if (!$this->cpfValido($documento)) {
                    $erro = "O CPF informado é inválido.";
                }
            }
        } else {
            if (!preg_match('/^[A-Za-z0-9.\/\-\s]+$/', $documento)) {
                $erro = "O CNPJ informado contém caracteres inválidos.";
            } else {
                $documento = strtoupper(
                    preg_replace('/[^A-Za-z0-9]/', '', $documento)
                );

                if (!$this->cnpjValido($documento)) {
                    $erro = "O CNPJ informado é inválido. Confira os 14 caracteres e os dígitos verificadores.";
                }
            }
        }

        if ($erro !== null) {
            require dirname(__DIR__) . "/views/auth/cadastro.php";
            return;
        }

        try {
            $modelo = new Usuario();

            if ($modelo->emailExiste($email)) {
                $erro = "Este e-mail já está cadastrado.";
                require dirname(__DIR__) . "/views/auth/cadastro.php";
                return;
            }

            if ($modelo->documentoExiste($documento)) {
                $erro = "Este CPF ou CNPJ já está cadastrado.";
                require dirname(__DIR__) . "/views/auth/cadastro.php";
                return;
            }

            $id = $modelo->cadastrar(
                $nome,
                $email,
                $documento,
                $senha,
                $tipoUsuario
            );

            session_regenerate_id(true);

            $_SESSION["id"] = $id;
            $_SESSION["nome"] = $nome;
            $_SESSION["email"] = $email;
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

            header("Location: " . BASE_URL . "/dashboard");
            exit;

        } catch (\Throwable $e) {
            error_log("Erro no cadastro: " . $e->getMessage());
            http_response_code(500);

            $erro = "Não foi possível concluir o cadastro. Tente novamente.";

            require dirname(__DIR__) . "/views/auth/cadastro.php";
            return;
        }
    }

    private function cpfValido(string $cpf): bool
    {
        if (
            !preg_match('/^\d{11}$/', $cpf) ||
            preg_match('/^(\d)\1{10}$/', $cpf)
        ) {
            return false;
        }

        for ($posicao = 9; $posicao <= 10; $posicao++) {
            $soma = 0;

            for ($i = 0; $i < $posicao; $i++) {
                $soma += (int) $cpf[$i] * (($posicao + 1) - $i);
            }

            $resto = ($soma * 10) % 11;
            $digito = ($resto === 10) ? 0 : $resto;

            if ((int) $cpf[$posicao] !== $digito) {
                return false;
            }
        }

        return true;
    }

    private function cnpjValido(string $cnpj): bool
    {
        // 12 caracteres alfanuméricos + 2 dígitos verificadores.
        if (
            !preg_match('/^[A-Z0-9]{12}\d{2}$/', $cnpj) ||
            preg_match('/^(.)\1{13}$/', $cnpj)
        ) {
            return false;
        }

        $pesosPrimeiro = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        $pesosSegundo = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

        $base = substr($cnpj, 0, 12);
        $primeiroDigito = $this->calcularDigitoCnpj(
            $base,
            $pesosPrimeiro
        );

        $baseComPrimeiroDigito = $base . $primeiroDigito;
        $segundoDigito = $this->calcularDigitoCnpj(
            $baseComPrimeiroDigito,
            $pesosSegundo
        );

        return substr($cnpj, 12, 2) === $primeiroDigito . $segundoDigito;
    }

    private function calcularDigitoCnpj(
        string $base,
        array $pesos
    ): string {
        $soma = 0;

        for ($i = 0; $i < count($pesos); $i++) {
            // Regra oficial: valor ASCII do caractere menos 48.
            $valor = ord($base[$i]) - 48;
            $soma += $valor * $pesos[$i];
        }

        $resto = $soma % 11;
        $digito = ($resto < 2) ? 0 : 11 - $resto;

        return (string) $digito;
    }
}
