<?php

namespace App\Controllers;

use App\Models\Carteira;

class CarteiraController
{
    /**
     * Garante que o usuário esteja autenticado.
     */
    private function exigirLogin(): void
    {
        if (!isset($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }
    }

    /**
     * Exibe as carteiras do usuário.
     */
    public function index(): void
    {
        $this->exigirLogin();

        $modelo = new Carteira();

        $carteiras = $modelo->listarPorUsuario(
            (int) $_SESSION["id"]
        );

        require dirname(__DIR__)
            . "/views/carteiras/index.php";
    }

    /**
     * Exibe o formulário de criação.
     */
    public function criarForm(): void
    {
        $this->exigirLogin();
        $this->garantirTokenCsrf();

        $erro = null;
        $nome = "";
        $descricao = "";

        require dirname(__DIR__)
            . "/views/carteiras/criar.php";
    }

    /**
     * Salva uma nova carteira.
     */
    public function salvar(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            return;
        }

        $nome = trim($_POST["nome"] ?? "");
        $descricao = trim($_POST["descricao"] ?? "");

        if ($nome === "" || strlen($nome) > 400) {
            http_response_code(422);

            $erro = "Informe um nome válido para a carteira.";
            $descricao = "";

            require dirname(__DIR__)
                . "/views/carteiras/criar.php";

            return;
        }

        try {
            $modelo = new Carteira();

            $modelo->criar(
                $nome,
                $descricao !== "" ? $descricao : null,
                (int) $_SESSION["id"]
            );

            header("Location: " . BASE_URL . "/carteiras");
            exit;

        } catch (\Throwable $e) {
            error_log(
                "Erro ao criar carteira: " . $e->getMessage()
            );

            http_response_code(500);

            $erro = "Não foi possível criar a carteira.";

            require dirname(__DIR__)
                . "/views/carteiras/criar.php";
        }
    }

    /**
     * Exibe o formulário de edição.
     */
    public function editarForm(): void
    {
        $this->exigirLogin();
        $this->garantirTokenCsrf();

        $id = filter_input(
            INPUT_GET,
            "id",
            FILTER_VALIDATE_INT
        );

        if (!$id || $id < 1) {
            http_response_code(400);
            echo "Identificador de carteira inválido.";
            return;
        }

        $modelo = new Carteira();

        $carteira = $modelo->buscarPorIdEUsuario(
            $id,
            (int) $_SESSION["id"]
        );

        if (!$carteira) {
            http_response_code(404);
            echo "Carteira não encontrada.";
            return;
        }

        $erro = null;
        $nome = $carteira["nome"];
        $descricao = $carteira["descricao"] ?? "";

        require dirname(__DIR__)
            . "/views/carteiras/editar.php";
    }

    /**
     * Atualiza uma carteira existente.
     */
    public function atualizar(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            return;
        }

        $id = filter_var(
            $_POST["id"] ?? null,
            FILTER_VALIDATE_INT
        );

        $nome = trim($_POST["nome"] ?? "");
        $descricao = trim($_POST["descricao"] ?? "");

        if (!$id || $id < 1) {
            http_response_code(400);
            echo "Identificador de carteira inválido.";
            return;
        }

        $modelo = new Carteira();

        $carteira = $modelo->buscarPorIdEUsuario(
            $id,
            (int) $_SESSION["id"]
        );

        if (!$carteira) {
            http_response_code(404);
            echo "Carteira não encontrada.";
            return;
        }

        if ($nome === "" || strlen($nome) > 400) {
            http_response_code(422);

            $erro = "Informe um nome válido para a carteira.";
            $descricao = "";

            require dirname(__DIR__)
                . "/views/carteiras/editar.php";

            return;
        }

        try {
            $modelo->atualizar(
                $id,
                (int) $_SESSION["id"],
                $nome,
                $descricao !== "" ? $descricao : null
            );

            header("Location: " . BASE_URL . "/carteiras");
            exit;

        } catch (\Throwable $e) {
            error_log(
                "Erro ao atualizar carteira: " . $e->getMessage()
            );

            http_response_code(500);

            $erro = "Não foi possível atualizar a carteira.";
            $descricao = $descricao;

            require dirname(__DIR__)
                . "/views/carteiras/editar.php";
        }
    }

    /**
     * Exclui uma carteira por meio de uma requisição POST.
     */
    public function excluir(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            return;
        }

        $id = filter_var(
            $_POST["id"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$id || $id < 1) {
            http_response_code(400);
            echo "Identificador de carteira inválido.";
            return;
        }

        try {
            $modelo = new Carteira();

            $modelo->excluir(
                $id,
                (int) $_SESSION["id"]
            );

            header("Location: " . BASE_URL . "/carteiras");
            exit;

        } catch (\Throwable $e) {
            error_log(
                "Erro ao excluir carteira: " . $e->getMessage()
            );

            http_response_code(500);
            echo "Não foi possível excluir a carteira.";
        }
    }

    /**
     * Garante que exista um token CSRF na sessão.
     */
    private function garantirTokenCsrf(): void
    {
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(
                random_bytes(32)
            );
        }
    }

    /**
     * Valida o token enviado pelo formulário.
     */
    private function validarTokenCsrf(): bool
    {
        if (
            !isset($_POST["csrf_token"]) ||
            !isset($_SESSION["csrf_token"]) ||
            !hash_equals(
                $_SESSION["csrf_token"],
                (string) $_POST["csrf_token"]
            )
        ) {
            http_response_code(403);
            echo "Requisição inválida. Atualize a página e tente novamente.";
            return false;
        }

        return true;
    }
}
