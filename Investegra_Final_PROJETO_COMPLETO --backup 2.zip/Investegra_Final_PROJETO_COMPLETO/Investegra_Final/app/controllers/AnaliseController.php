<?php

namespace App\Controllers;

use App\Models\Analise;
use App\Models\HistoricoPatrimonio;
use App\Services\HistoricoPatrimonioService;

class AnaliseController
{
    public function index(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }

        $usuarioId = (int) $_SESSION["id"];

        // 1. Carrega a distribuição dos investimentos por categoria.
        $modeloAnalise = new Analise();

        $distribuicaoCategorias =
            $modeloAnalise->distribuicaoPorCategoria($usuarioId);

        $totalInvestido = array_sum(
            array_column(
                $distribuicaoCategorias,
                "total_investido"
            )
        );

        foreach ($distribuicaoCategorias as &$item) {
            $valor = (float) $item["total_investido"];

            $item["percentual"] = $totalInvestido > 0
                ? ($valor / $totalInvestido) * 100
                : 0;
        }

        unset($item);

        // 2. Carrega o histórico patrimonial existente.
        $modeloHistorico = new HistoricoPatrimonio();

        $historicoPatrimonio =
            $modeloHistorico->listarPorUsuario($usuarioId);

        // 3. Verifica se já existe um registro para hoje.
        $hoje = date("Y-m-d");
        $registrarHoje = true;

        if (!empty($historicoPatrimonio)) {
            $ultimoRegistro = end($historicoPatrimonio);

            $dataUltimoRegistro = substr(
                $ultimoRegistro["data_registro"],
                0,
                10
            );

            if ($dataUltimoRegistro === $hoje) {
                $registrarHoje = false;
            }
        }

        // 4. Registra o patrimônio se ainda não houver
        // um registro para a data atual.
        $mensagemHistorico = null;
        $tipoMensagemHistorico = "info";

        if ($registrarHoje) {
            $servicoHistorico = new HistoricoPatrimonioService();

            $resultado = $servicoHistorico
                ->registrarPatrimonioUsuario($usuarioId);

            $mensagemHistorico =
                $resultado["mensagem"] ?? null;

            $tipoMensagemHistorico = !empty($resultado["sucesso"])
                ? "sucesso"
                : "erro";

            // Recarrega o histórico após a tentativa.
            $historicoPatrimonio =
                $modeloHistorico->listarPorUsuario($usuarioId);
        }

        // 5. Prepara os dados utilizados pelos gráficos.
        require dirname(__DIR__)
            . "/views/analises/index.php";
    }
}
