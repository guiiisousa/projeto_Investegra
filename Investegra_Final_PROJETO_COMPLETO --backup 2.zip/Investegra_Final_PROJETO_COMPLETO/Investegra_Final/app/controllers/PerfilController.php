<?php

namespace App\Controllers;

use App\Models\Usuario;

class PerfilController
{
    private function exigirLogin(): void
    {
        if (empty($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }
    }

    private function garantirTokenCsrf(): void
    {
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(
                random_bytes(32)
            );
        }
    }

    private function validarTokenCsrf(): bool
    {
        return isset(
            $_POST["csrf_token"],
            $_SESSION["csrf_token"]
        ) && hash_equals(
            $_SESSION["csrf_token"],
            (string) $_POST["csrf_token"]
        );
    }

    /**
     * Exibe o perfil do usuário autenticado.
     */
    public function index(): void
    {
        $this->exigirLogin();
        $this->garantirTokenCsrf();

        $modelo = new Usuario();

        try {
            $usuario = $modelo->buscarPerfilPorId(
                (int) $_SESSION["id"]
            );
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao consultar perfil: "
                . $erro->getMessage()
            );

            http_response_code(500);
            echo "Não foi possível carregar seu perfil.";
            return;
        }

        if (!$usuario) {
            http_response_code(404);
            echo "Usuário não encontrado.";
            return;
        }

        $csrfToken = $_SESSION["csrf_token"];
        $erro = null;
        $sucesso = isset($_GET["salvo"])
            && $_GET["salvo"] === "1";

        require dirname(__DIR__)
            . "/views/perfil/index.php";
    }

    /**
     * Salva as alterações do perfil.
     */
    public function atualizar(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            http_response_code(403);
            echo "Sessão inválida. Atualize a página e tente novamente.";
            return;
        }

        $id = (int) $_SESSION["id"];

        $nome = trim($_POST["nome"] ?? "");
        $email = trim($_POST["email"] ?? "");

        $idadeTexto = trim($_POST["idade"] ?? "");
        $experienciaTexto = trim($_POST["experiencia"] ?? "");
        $rendaTexto = trim($_POST["renda_mensal"] ?? "");
        $horizonteTexto = trim(
            $_POST["horizonte_investimento"] ?? ""
        );
        $toleranciaTexto = trim(
            $_POST["tolerancia_risco"] ?? ""
        );
        $objetivoTexto = trim($_POST["objetivo"] ?? "");
        $descricaoTexto = trim(
            $_POST["descricao_pessoal"] ?? ""
        );

        $idade = null;
        $rendaMensal = null;

        if (
            $nome === "" ||
            strlen($nome) > 100
        ) {
            $erro = "Informe um nome com até 100 caracteres.";
        } elseif (
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($email) > 150
        ) {
            $erro = "Informe um endereço de e-mail válido.";
        } elseif ($idadeTexto !== "") {
            $idadeValidada = filter_var(
                $idadeTexto,
                FILTER_VALIDATE_INT
            );

            if (
                $idadeValidada === false ||
                $idadeValidada < 13 ||
                $idadeValidada > 120
            ) {
                $erro = "Informe uma idade válida entre 13 e 120 anos.";
            } else {
                $idade = $idadeValidada;
            }
        }

        if (
            $erro === null &&
            $rendaTexto !== ""
        ) {
            $rendaNormalizada = str_replace(
                ",",
                ".",
                $rendaTexto
            );

            if (
                !is_numeric($rendaNormalizada) ||
                (float) $rendaNormalizada < 0 ||
                (float) $rendaNormalizada > 99999999.99
            ) {
                $erro = "Informe uma renda mensal válida.";
            } else {
                $rendaMensal = (float) $rendaNormalizada;
            }
        }

        if (
            $erro === null &&
            (
                strlen($experienciaTexto) > 50 ||
                strlen($horizonteTexto) > 50 ||
                strlen($toleranciaTexto) > 50 ||
                strlen($objetivoTexto) > 100
            )
        ) {
            $erro = "Um dos campos ultrapassou o limite permitido.";
        }

        if (
            $erro === null &&
            strlen($descricaoTexto) > 10000
        ) {
            $erro = "A descrição pessoal deve ter até 10.000 caracteres.";
        }

        $modelo = new Usuario();

        if ($erro === null) {
            try {
                if (
                    $modelo->emailEmUsoPorOutroUsuario(
                        $email,
                        $id
                    )
                ) {
                    $erro = "Esse e-mail já está sendo utilizado por outra conta.";
                } else {
                    $modelo->atualizarPerfil(
                        $id,
                        $nome,
                        $email,
                        $idade,
                        $experienciaTexto !== ""
                            ? $experienciaTexto : null,
                        $rendaMensal,
                        $horizonteTexto !== ""
                            ? $horizonteTexto : null,
                        $toleranciaTexto !== ""
                            ? $toleranciaTexto : null,
                        $objetivoTexto !== ""
                            ? $objetivoTexto : null,
                        $descricaoTexto !== ""
                            ? $descricaoTexto : null
                    );

                    $_SESSION["nome"] = $nome;
                    $_SESSION["email"] = $email;

                    header(
                        "Location: "
                        . BASE_URL
                        . "/perfil?salvo=1"
                    );
                    exit;
                }
            } catch (\Throwable $erroInterno) {
                error_log(
                    "Erro ao atualizar perfil: "
                    . $erroInterno->getMessage()
                );

                $erro = "Não foi possível salvar as alterações. Tente novamente.";
            }
        }

        try {
            $usuario = $modelo->buscarPerfilPorId($id);

            if ($usuario) {
                $usuario["nome"] = $nome;
                $usuario["email"] = $email;
                $usuario["idade"] = $idadeTexto;
                $usuario["experiencia"] = $experienciaTexto;
                $usuario["renda_mensal"] = $rendaTexto;
                $usuario["horizonte_investimento"] = $horizonteTexto;
                $usuario["tolerancia_risco"] = $toleranciaTexto;
                $usuario["objetivo"] = $objetivoTexto;
                $usuario["descricao_pessoal"] = $descricaoTexto;
            }
        } catch (\Throwable $erroInterno) {
            error_log(
                "Erro ao recuperar perfil após falha: "
                . $erroInterno->getMessage()
            );

            http_response_code(500);
            echo "Não foi possível recuperar os dados do perfil.";
            return;
        }

        if (!$usuario) {
            http_response_code(404);
            echo "Usuário não encontrado.";
            return;
        }

        $this->garantirTokenCsrf();
        $csrfToken = $_SESSION["csrf_token"];
        $sucesso = false;

        require dirname(__DIR__)
            . "/views/perfil/index.php";
    }
}
