<?php

namespace App\Controllers;

use App\Models\Ativo;
use App\Models\Carteira;
use App\Services\BrapiService;

class AtivoController
{
    private function exigirLogin(): void
    {
        if (!isset($_SESSION["id"])) {
            header("Location: " . BASE_URL . "/login");
            exit;
        }
    }

    private function garantirTokenCsrf(): void
    {
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
        }
    }

    private function validarTokenCsrf(): bool
    {
        $token = $_POST["csrf_token"] ?? "";

        return is_string($token)
            && !empty($_SESSION["csrf_token"])
            && hash_equals($_SESSION["csrf_token"], $token);
    }

    private function redirecionar(string $caminho): void
    {
        header("Location: " . BASE_URL . $caminho);
        exit;
    }

    
/**
 * Exibe a seleção de carteiras ou lista os ativos
 * da carteira selecionada.
 */
public function index(): void
{
    $this->exigirLogin();

    $usuarioId = (int) $_SESSION["id"];

    $carteiraId = filter_input(
        INPUT_GET,
        "carteira",
        FILTER_VALIDATE_INT
    );

    $modeloCarteira = new Carteira();

    /*
     * Quando nenhuma carteira é informada,
     * apresenta a tela de seleção.
     */
    if (!$carteiraId || $carteiraId < 1) {
        $carteiras = $modeloCarteira->listarPorUsuario(
            $usuarioId
        );

        require dirname(__DIR__)
            . "/views/ativos/selecionar.php";

        return;
    }

    /*
     * Verifica se a carteira pertence ao usuário
     * autenticado antes de mostrar seus ativos.
     */
    $carteira = $modeloCarteira->buscarPorIdEUsuario(
        $carteiraId,
        $usuarioId
    );

    if (!$carteira) {
        http_response_code(404);
        echo "Carteira não encontrada.";
        return;
    }

    /*
     * A partir daqui, mantém o funcionamento atual
     * da listagem e dos cálculos dos ativos.
     */
    $modeloAtivo = new Ativo();

    $ativos = $modeloAtivo->listarPorCarteiraEUsuario(
        $carteiraId,
        $usuarioId
    );

    $servicoBrapi = new BrapiService();

    $totalInvestido = 0.0;
    $totalMercado = 0.0;
    $totalResultado = 0.0;
    $quantidadeCotada = 0;

    foreach ($ativos as &$ativo) {
        $quantidade = (float) $ativo["quantidade"];
        $precoMedio = (float) $ativo["preco_medio"];

        $valorInvestido = $quantidade * $precoMedio;

        $ativo["valor_investido"] = $valorInvestido;
        $ativo["cotacao_atual"] = null;
        $ativo["valor_mercado"] = null;
        $ativo["resultado"] = null;
        $ativo["resultado_percentual"] = null;
        $ativo["erro_cotacao"] = false;
        $ativo["moeda_cotacao"] = "BRL";

        $totalInvestido += $valorInvestido;

        try {
            $cotacao = $servicoBrapi->buscarCotacao(
                $ativo["ticker"]
            );

            $ativo["cotacao_atual"] = $cotacao["preco_atual"];
            $ativo["moeda_cotacao"] = $cotacao["moeda"] ?? "BRL";

            if ($ativo["moeda_cotacao"] === "BRL") {
                $valorMercado = $quantidade
                    * $cotacao["preco_atual"];

                $resultado = $valorMercado - $valorInvestido;

                $percentual = $valorInvestido > 0
                    ? ($resultado / $valorInvestido) * 100
                    : 0;

                $ativo["valor_mercado"] = $valorMercado;
                $ativo["resultado"] = $resultado;
                $ativo["resultado_percentual"] = $percentual;

                $totalMercado += $valorMercado;
                $totalResultado += $resultado;
                $quantidadeCotada++;
            }
        } catch (\Throwable $erro) {
            $ativo["erro_cotacao"] = true;

            error_log(
                "Falha na cotação de "
                . $ativo["ticker"]
                . ": "
                . $erro->getMessage()
            );
        }
    }

    unset($ativo);

    $ativosSemCotacao = count($ativos) - $quantidadeCotada;

    $this->garantirTokenCsrf();

    require dirname(__DIR__) . "/views/ativos/index.php";
}


    /**
     * Exibe o formulário de cadastro.
     */
    public function criarForm(): void
    {
        $this->exigirLogin();

        $usuarioId = (int) $_SESSION["id"];

        $carteiraId = filter_input(
            INPUT_GET,
            "carteira",
            FILTER_VALIDATE_INT
        );

        if (!$carteiraId || $carteiraId < 1) {
            $this->redirecionar("/carteiras");
        }

        $modeloCarteira = new Carteira();

        $carteira = $modeloCarteira->buscarPorIdEUsuario(
            $carteiraId,
            $usuarioId
        );

        if (!$carteira) {
            http_response_code(404);
            echo "Carteira não encontrada.";
            return;
        }

        $modeloAtivo = new Ativo();
        $categorias = $modeloAtivo->listarCategorias();

        $this->garantirTokenCsrf();

        require dirname(__DIR__) . "/views/ativos/criar.php";
    }

    /**
     * Cadastra um novo ativo.
     */
    public function salvar(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            http_response_code(403);
            echo "Solicitação inválida. Atualize a página e tente novamente.";
            return;
        }

        $usuarioId = (int) $_SESSION["id"];

        $carteiraId = filter_var(
            $_POST["carteira_id"] ?? "",
            FILTER_VALIDATE_INT
        );

        $categoriaTexto = trim(
            (string) ($_POST["categoria_id"] ?? "")
        );

        $categoriaId = $categoriaTexto === ""
            ? null
            : filter_var(
                $categoriaTexto,
                FILTER_VALIDATE_INT
            );

        $ticker = strtoupper(
            trim((string) ($_POST["ticker"] ?? ""))
        );

        $quantidadeTexto = trim(
            (string) ($_POST["quantidade"] ?? "")
        );

        $precoTexto = trim(
            (string) ($_POST["preco_medio"] ?? "")
        );

        $dataCompra = trim(
            (string) ($_POST["data_compra"] ?? "")
        );

        $observacao = trim(
            (string) ($_POST["observacao"] ?? "")
        );

        $quantidade = filter_var(
            $quantidadeTexto,
            FILTER_VALIDATE_FLOAT
        );

        $precoMedio = filter_var(
            $precoTexto,
            FILTER_VALIDATE_FLOAT
        );

        if (
            !$carteiraId ||
            $carteiraId < 1 ||
            ($categoriaId !== null &&
                (!$categoriaId || $categoriaId < 1)) ||
            !preg_match('/^[A-Z0-9.-]{1,20}$/', $ticker) ||
            $quantidade === false ||
            $quantidade <= 0 ||
            $precoMedio === false ||
            $precoMedio <= 0 ||
            strlen($observacao) > 60000
        ) {
            http_response_code(422);
            echo "Verifique os dados informados.";
            return;
        }

        if ($dataCompra !== "") {
            $data = \DateTimeImmutable::createFromFormat(
                "!Y-m-d",
                $dataCompra
            );

            if (
                !$data ||
                $data->format("Y-m-d") !== $dataCompra
            ) {
                http_response_code(422);
                echo "A data de compra é inválida.";
                return;
            }
        } else {
            $dataCompra = null;
        }

        $modeloCarteira = new Carteira();

        $carteira = $modeloCarteira->buscarPorIdEUsuario(
            $carteiraId,
            $usuarioId
        );

        if (!$carteira) {
            http_response_code(404);
            echo "Carteira não encontrada.";
            return;
        }

        $modeloAtivo = new Ativo();

        try {
            $id = $modeloAtivo->criar(
                $carteiraId,
                $usuarioId,
                $categoriaId,
                $ticker,
                (float) $quantidade,
                (float) $precoMedio,
                $dataCompra,
                $observacao !== "" ? $observacao : null
            );

            if ($id < 1) {
                http_response_code(500);
                echo "Não foi possível cadastrar o ativo.";
                return;
            }

            $this->redirecionar(
                "/ativos?carteira=" . $carteiraId
            );
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao cadastrar ativo: " . $erro->getMessage()
            );

            http_response_code(500);
            echo "Ocorreu um erro ao cadastrar o ativo.";
        }
    }

    /**
     * Exibe o formulário de edição.
     */
    public function editarForm(): void
    {
        $this->exigirLogin();

        $usuarioId = (int) $_SESSION["id"];

        $id = filter_input(
            INPUT_GET,
            "id",
            FILTER_VALIDATE_INT
        );

        if (!$id || $id < 1) {
            $this->redirecionar("/carteiras");
        }

        $modeloAtivo = new Ativo();

        $ativo = $modeloAtivo->buscarPorIdEUsuario(
            $id,
            $usuarioId
        );

        if (!$ativo) {
            http_response_code(404);
            echo "Ativo não encontrado.";
            return;
        }

        $modeloCarteira = new Carteira();

        $carteira = $modeloCarteira->buscarPorIdEUsuario(
            (int) $ativo["carteira_id"],
            $usuarioId
        );

        if (!$carteira) {
            http_response_code(404);
            echo "Carteira não encontrada.";
            return;
        }

        $categorias = $modeloAtivo->listarCategorias();

        $this->garantirTokenCsrf();

        require dirname(__DIR__) . "/views/ativos/editar.php";
    }

    /**
     * Atualiza os dados de um ativo.
     */
    public function atualizar(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            http_response_code(403);
            echo "Solicitação inválida. Atualize a página e tente novamente.";
            return;
        }

        $usuarioId = (int) $_SESSION["id"];

        $id = filter_var(
            $_POST["id"] ?? "",
            FILTER_VALIDATE_INT
        );

        if (!$id || $id < 1) {
            $this->redirecionar("/carteiras");
        }

        $modeloAtivo = new Ativo();

        $ativo = $modeloAtivo->buscarPorIdEUsuario(
            $id,
            $usuarioId
        );

        if (!$ativo) {
            http_response_code(404);
            echo "Ativo não encontrado.";
            return;
        }

        $categoriaTexto = trim(
            (string) ($_POST["categoria_id"] ?? "")
        );

        $categoriaId = $categoriaTexto === ""
            ? null
            : filter_var(
                $categoriaTexto,
                FILTER_VALIDATE_INT
            );

        $ticker = strtoupper(
            trim((string) ($_POST["ticker"] ?? ""))
        );

        $quantidade = filter_var(
            trim((string) ($_POST["quantidade"] ?? "")),
            FILTER_VALIDATE_FLOAT
        );

        $precoMedio = filter_var(
            trim((string) ($_POST["preco_medio"] ?? "")),
            FILTER_VALIDATE_FLOAT
        );

        $dataCompra = trim(
            (string) ($_POST["data_compra"] ?? "")
        );

        $observacao = trim(
            (string) ($_POST["observacao"] ?? "")
        );

        if (
            ($categoriaId !== null &&
                (!$categoriaId || $categoriaId < 1)) ||
            !preg_match('/^[A-Z0-9.-]{1,20}$/', $ticker) ||
            $quantidade === false ||
            $quantidade <= 0 ||
            $precoMedio === false ||
            $precoMedio <= 0 ||
            strlen($observacao) > 60000
        ) {
            http_response_code(422);
            echo "Verifique os dados informados.";
            return;
        }

        if ($dataCompra !== "") {
            $data = \DateTimeImmutable::createFromFormat(
                "!Y-m-d",
                $dataCompra
            );

            if (
                !$data ||
                $data->format("Y-m-d") !== $dataCompra
            ) {
                http_response_code(422);
                echo "A data de compra é inválida.";
                return;
            }
        } else {
            $dataCompra = null;
        }

        try {
            $modeloAtivo->atualizar(
                $id,
                $usuarioId,
                $categoriaId,
                $ticker,
                (float) $quantidade,
                (float) $precoMedio,
                $dataCompra,
                $observacao !== "" ? $observacao : null
            );

            $this->redirecionar(
                "/ativos?carteira=" . (int) $ativo["carteira_id"]
            );
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao atualizar ativo: " . $erro->getMessage()
            );

            http_response_code(500);
            echo "Ocorreu um erro ao atualizar o ativo.";
        }
    }

    /**
     * Exclui um ativo.
     */
    public function excluir(): void
    {
        $this->exigirLogin();

        if (!$this->validarTokenCsrf()) {
            http_response_code(403);
            echo "Solicitação inválida. Atualize a página e tente novamente.";
            return;
        }

        $usuarioId = (int) $_SESSION["id"];

        $id = filter_var(
            $_POST["id"] ?? "",
            FILTER_VALIDATE_INT
        );

        if (!$id || $id < 1) {
            $this->redirecionar("/carteiras");
        }

        $modeloAtivo = new Ativo();

        $ativo = $modeloAtivo->buscarPorIdEUsuario(
            $id,
            $usuarioId
        );

        if (!$ativo) {
            http_response_code(404);
            echo "Ativo não encontrado.";
            return;
        }

        try {
            $modeloAtivo->excluir($id, $usuarioId);

            $this->redirecionar(
                "/ativos?carteira=" . (int) $ativo["carteira_id"]
            );
        } catch (\Throwable $erro) {
            error_log(
                "Erro ao excluir ativo: " . $erro->getMessage()
            );

            http_response_code(500);
            echo "Ocorreu um erro ao excluir o ativo.";
        }
    }
}
