<?php
namespace App\Controllers;

use App\Models\Simulacao;
use App\Services\SimulacaoService;
use App\Services\BrapiService;

class SimulacaoController
{
    private function exigirLogin(): void
    {
        if (empty($_SESSION['id'])) { header('Location: ' . BASE_URL . '/login'); exit; }
    }

    private function csrf(): void
    {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    private function numero(array $dados, string $campo): float
    {
        $valor = $dados[$campo] ?? null;
        if (!is_numeric($valor)) throw new \InvalidArgumentException('Preencha todos os campos numéricos corretamente.');
        return (float)$valor;
    }

    private function calcular(array $dados, string $tipo): array
    {
        $capital = $this->numero($dados, 'capital_inicial');
        $aporte = $this->numero($dados, 'aporte_mensal');
        $taxa = $this->numero($dados, 'taxa_anual');
        $meses = filter_var($dados['prazo_meses'] ?? null, FILTER_VALIDATE_INT);
        if ($meses === false) throw new \InvalidArgumentException('Informe um prazo válido em meses.');
        $service = new SimulacaoService();
        if ($tipo === 'juros_simples') return $service->calcularSimples($capital, $aporte, $taxa, $meses);
        return $service->calcularCompostos($capital, $aporte, $taxa, $meses);
    }

    public function index(): void
    {
        $this->exigirLogin(); $this->csrf();
        $resultado = null; $erro = $_SESSION['simulacao_erro'] ?? null; unset($_SESSION['simulacao_erro']);
        $tipo = ($_GET['tipo'] ?? 'juros_compostos') === 'juros_simples' ? 'juros_simples' : 'juros_compostos';
        $entrada = ['capital_inicial'=>1000, 'aporte_mensal'=>200, 'taxa_anual'=>10, 'prazo_meses'=>60];
        if (isset($_GET['calcular'])) {
            foreach ($entrada as $campo => $padrao) $entrada[$campo] = $_GET[$campo] ?? $padrao;
            try { $resultado = $this->calcular($_GET, $tipo); }
            catch (\Throwable $e) { $erro = $e->getMessage(); }
        }
        try { $historicoSimulacoes = (new Simulacao())->listarPorUsuario((int)$_SESSION['id']); }
        catch (\Throwable $e) { error_log('Erro ao listar simulações: '.$e->getMessage()); $historicoSimulacoes=[]; $erro = $erro ?: 'Não foi possível carregar o histórico. Execute a atualização do banco de dados.'; }
        $csrfToken = $_SESSION['csrf_token'];
        require dirname(__DIR__) . '/views/simulacoes/index.php';
    }

    public function salvar(): void
    {
        $this->exigirLogin(); $this->csrf();
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) { http_response_code(403); echo 'Sessão inválida. Atualize a página.'; return; }
        try {
            $tipo = $_POST['tipo_simulacao'] ?? 'juros_compostos';
            if (!in_array($tipo, ['juros_simples','juros_compostos','ativo'], true)) throw new \InvalidArgumentException('Tipo de simulação inválido.');
            $ticker = null; $preco = null; $cenario = null; $taxa = $this->numero($_POST, 'taxa_anual');
            if ($tipo === 'ativo') {
                $ticker = strtoupper(trim((string)($_POST['ticker'] ?? '')));
                if (!preg_match('/^[A-Z0-9.-]{1,20}$/', $ticker)) throw new \InvalidArgumentException('Selecione um ticker válido.');
                $cotacao = (new BrapiService())->buscarCotacao($ticker);
                $preco = (float)$cotacao['preco_atual'];
                $cenario = trim((string)($_POST['cenario'] ?? 'personalizado'));
                $resultado = (new SimulacaoService())->calcularAtivo($this->numero($_POST,'capital_inicial'), $this->numero($_POST,'aporte_mensal'), $taxa, (int)($_POST['prazo_meses'] ?? 0));
            } else {
                $resultado = $this->calcular($_POST, $tipo);
            }
            (new Simulacao())->salvar((int)$_SESSION['id'], $tipo, (float)$resultado['capital_inicial'], (float)$resultado['aporte_mensal'], $taxa, (int)$resultado['prazo_meses'], (float)$resultado['valor_final'], $ticker, $preco, $cenario);
            header('Location: ' . BASE_URL . '/simulacoes?salvo=1'); exit;
        } catch (\Throwable $e) {
            error_log('Erro ao salvar simulação: '.$e->getMessage());
            $_SESSION['simulacao_erro'] = $e instanceof \InvalidArgumentException ? $e->getMessage() : 'Não foi possível salvar. Verifique a cotação, o banco e os parâmetros.';
            header('Location: ' . BASE_URL . '/simulacoes'); exit;
        }
    }
}
