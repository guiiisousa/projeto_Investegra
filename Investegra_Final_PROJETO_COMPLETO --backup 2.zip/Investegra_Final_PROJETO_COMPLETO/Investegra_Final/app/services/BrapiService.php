<?php

namespace App\Services;

use RuntimeException;

class BrapiService
{
    private string $baseUrl;
    private string $token;

    public function __construct()
    {
        $config = require dirname(__DIR__, 2)
            . "/config/brapi.php";

        $this->baseUrl = rtrim(
            $config["base_url"],
            "/"
        );

        $this->token = trim(
            $config["token"] ?? ""
        );
    }

    /**
     * Executa uma requisição GET à brapi.
     */
    private function requisitar(string $endpoint): array
    {
        if (!function_exists("curl_init")) {
            throw new RuntimeException(
                "A extensão cURL do PHP não está habilitada."
            );
        }

        $curl = curl_init(
            $this->baseUrl . $endpoint
        );

        $headers = [
            "Accept: application/json"
        ];

        if ($this->token !== "") {
            $headers[] = "Authorization: Bearer "
                . $this->token;
        }

        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => false
        ]);

        $resposta = curl_exec($curl);
        $status = (int) curl_getinfo(
            $curl,
            CURLINFO_HTTP_CODE
        );

        $erroCurl = curl_error($curl);

        curl_close($curl);

        if ($resposta === false) {
            error_log("Erro cURL brapi: " . $erroCurl);

            throw new RuntimeException(
                "Não foi possível consultar a API."
            );
        }

        $dados = json_decode($resposta, true);

        if (!is_array($dados)) {
            throw new RuntimeException(
                "A API retornou uma resposta inválida."
            );
        }

        if ($status < 200 || $status >= 300) {
            error_log(
                "Erro HTTP brapi: " . $status
                . " - " . ($dados["message"] ?? "Sem detalhes")
            );

            if ($status === 401 || $status === 403) {
                throw new RuntimeException(
                    "A API exige autenticação ou uma permissão adicional."
                );
            }

            if ($status === 429) {
                throw new RuntimeException(
                    "Limite de consultas atingido. Tente novamente mais tarde."
                );
            }

            throw new RuntimeException(
                "A consulta à API não foi concluída."
            );
        }

        return $dados;
    }

    /**
     * Busca tickers disponíveis pelo código digitado.
     */
    
    public function buscarTickers(string $termo): array
    {
        $termo = trim($termo);

        if (strlen($termo) < 2 || strlen($termo) > 60) {
            return [];
        }

        $endpoint = "/v2/tickers?"
            . http_build_query([
                "search" => $termo,
                "limit" => 10,
                "sortBy" => "volume",
                "sortOrder" => "desc"
            ]);

        $dados = $this->requisitar($endpoint);

        $resultados = $dados["results"] ?? [];

        if (!is_array($resultados)) {
            return [];
        }

        return array_values(array_filter(
            array_slice($resultados, 0, 10),
            static fn($item) =>
                is_array($item)
                && isset($item["symbol"])
                && is_string($item["symbol"])
        ));
    }


    /**
     * Consulta a cotação atual de uma ação.
     */
    
    public function buscarCotacao(string $ticker): array
    {
        $ticker = strtoupper(trim($ticker));

        if (!preg_match('/^[A-Z0-9.-]{1,20}$/', $ticker)) {
            throw new RuntimeException(
                "O código do ativo é inválido."
            );
        }

        // Reutiliza a cotação por até 60 segundos na sessão.
        $chaveCache = "brapi_cotacao_" . $ticker;

        if (session_status() === PHP_SESSION_ACTIVE) {
            $cache = $_SESSION[$chaveCache] ?? null;

            if (
                is_array($cache) &&
                isset($cache["horario"], $cache["dados"]) &&
                time() - $cache["horario"] < 60
            ) {
                return $cache["dados"];
            }
        }

        $endpoint = "/v2/stocks/quote?"
            . http_build_query([
                "symbols" => $ticker
            ]);

        $dados = $this->requisitar($endpoint);
        $resultados = $dados["results"] ?? [];

        if (
            !is_array($resultados) ||
            !isset($resultados[0])
        ) {
            throw new RuntimeException(
                "Não foi encontrada cotação para esse ativo."
            );
        }

        $resultado = $resultados[0];
        $cotacao = $resultado["data"] ?? $resultado;

        if (
            !is_array($cotacao) ||
            !isset($cotacao["regularMarketPrice"]) ||
            !is_numeric($cotacao["regularMarketPrice"])
        ) {
            throw new RuntimeException(
                "A API não retornou um preço válido."
            );
        }

        $resultadoFinal = [
            "ticker" => $resultado["symbol"] ?? $ticker,
            "nome" => $cotacao["shortName"]
                ?? $cotacao["longName"]
                ?? $ticker,
            "preco_atual" => (float)
                $cotacao["regularMarketPrice"],
            "variacao_percentual" => isset(
                $cotacao["regularMarketChangePercent"]
            )
                ? (float) $cotacao["regularMarketChangePercent"]
                : null,
            "moeda" => $cotacao["currency"] ?? "BRL",
            "consultado_em" => $dados["requestedAt"] ?? null
        ];

        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION[$chaveCache] = [
                "horario" => time(),
                "dados" => $resultadoFinal
            ];
        }

        return $resultadoFinal;
    }

}
