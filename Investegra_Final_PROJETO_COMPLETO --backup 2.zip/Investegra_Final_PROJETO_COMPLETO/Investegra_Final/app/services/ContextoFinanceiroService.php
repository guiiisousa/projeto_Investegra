<?php

namespace App\Services;

use App\Models\Carteira;
use App\Models\Ativo;

class ContextoFinanceiroService
{
    private Carteira $carteiraModel;
    private Ativo $ativoModel;

    public function __construct()
    {
        $this->carteiraModel = new Carteira();
        $this->ativoModel = new Ativo();
    }

    /**
     * Monta um contexto financeiro usando somente os dados
     * pertencentes ao usuário autenticado.
     */
    public function gerarContexto(int $usuarioId): string
    {
        if ($usuarioId <= 0) {
            throw new \InvalidArgumentException(
                "ID de usuário inválido."
            );
        }

        $carteiras = $this->carteiraModel
            ->listarPorUsuario($usuarioId);

        $totalInvestido = 0.0;
        $quantidadeAtivos = 0;
        $totaisPorCategoria = [];
        $detalhesAtivos = [];
        $quantidadeDetalhesExibidos = 0;
        $limiteDetalhes = 80;

        $linhas = [
            "CONTEXTO FINANCEIRO DO INVESTEGRA",
            "Data da consulta: " . date("d/m/Y H:i"),
            "Quantidade de carteiras: " . count($carteiras),
            "",
            "IMPORTANTE:",
            "- Os valores investidos são calculados por quantidade x preço médio.",
            "- Esses valores representam custo de aquisição estimado,",
            "  não necessariamente o valor atual de mercado.",
            "- Não invente cotações, rentabilidade ou saldos ausentes.",
            "- Se uma informação não estiver disponível, informe isso.",
            ""
        ];

        foreach ($carteiras as $carteira) {
            $carteiraId = (int) $carteira["id"];

            $ativos = $this->ativoModel
                ->listarPorCarteiraEUsuario(
                    $carteiraId,
                    $usuarioId
                );

            $totalCarteira = 0.0;

            foreach ($ativos as $ativo) {
                $quantidade = (float) $ativo["quantidade"];
                $precoMedio = (float) $ativo["preco_medio"];

                $valorInvestido = $quantidade * $precoMedio;

                $totalInvestido += $valorInvestido;
                $totalCarteira += $valorInvestido;
                $quantidadeAtivos++;

                $categoria = trim(
                    (string) ($ativo["categoria"] ?? "")
                );

                if ($categoria === "") {
                    $categoria = "Sem categoria";
                }

                if (!isset($totaisPorCategoria[$categoria])) {
                    $totaisPorCategoria[$categoria] = 0.0;
                }

                $totaisPorCategoria[$categoria] += $valorInvestido;

                if ($quantidadeDetalhesExibidos < $limiteDetalhes) {
                    $detalhesAtivos[] = [
                        "carteira" => (string) $carteira["nome"],
                        "ticker" => (string) $ativo["ticker"],
                        "categoria" => $categoria,
                        "quantidade" => $quantidade,
                        "preco_medio" => $precoMedio,
                        "valor_investido" => $valorInvestido
                    ];

                    $quantidadeDetalhesExibidos++;
                }
            }

            $linhas[] = "Carteira: " . $carteira["nome"];
            $linhas[] = "Quantidade de ativos: " . count($ativos);
            $linhas[] = "Total investido (custo estimado): R$ "
                . number_format($totalCarteira, 2, ",", ".");
            $linhas[] = "";
        }

        $linhas[] = "RESUMO GERAL";
        $linhas[] = "Total investido estimado: R$ "
            . number_format($totalInvestido, 2, ",", ".");
        $linhas[] = "Quantidade total de registros de ativos: "
            . $quantidadeAtivos;
        $linhas[] = "";

        $linhas[] = "DISTRIBUIÇÃO POR CATEGORIA";

        if (empty($totaisPorCategoria)) {
            $linhas[] = "Nenhum ativo cadastrado.";
        } else {
            arsort($totaisPorCategoria);

            foreach ($totaisPorCategoria as $categoria => $valor) {
                $linhas[] = $categoria . ": R$ "
                    . number_format($valor, 2, ",", ".");
            }
        }

        $linhas[] = "";
        $linhas[] = "DETALHES DOS ATIVOS CADASTRADOS";

        if (empty($detalhesAtivos)) {
            $linhas[] = "Nenhum ativo cadastrado.";
        } else {
            foreach ($detalhesAtivos as $ativo) {
                $linhas[] = sprintf(
                    "- Carteira: %s | Ativo: %s | Categoria: %s"
                    . " | Quantidade: %s | Preço médio: R$ %s"
                    . " | Custo estimado: R$ %s",
                    $ativo["carteira"],
                    $ativo["ticker"],
                    $ativo["categoria"],
                    number_format(
                        $ativo["quantidade"],
                        4,
                        ",",
                        "."
                    ),
                    number_format(
                        $ativo["preco_medio"],
                        2,
                        ",",
                        "."
                    ),
                    number_format(
                        $ativo["valor_investido"],
                        2,
                        ",",
                        "."
                    )
                );
            }

            if ($quantidadeAtivos > $limiteDetalhes) {
                $linhas[] =
                    "Observação: os detalhes foram limitados a "
                    . $limiteDetalhes
                    . " registros. Os totais gerais consideram todos "
                    . "os ativos consultados.";
            }
        }

        return implode("\n", $linhas);
    }
}
