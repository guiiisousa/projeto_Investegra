<?php

namespace App\Services;

class OllamaService
{
    private string $baseUrl;
    private string $modelo;

    public function __construct()
    {
        $this->baseUrl = "http://127.0.0.1:11434";
        $this->modelo = "llama3.2:latest";
    }

    public function conversar(
        string $mensagem,
        array $historico = [],
        string $contexto = ""
    ): array {
        $mensagem = trim($mensagem);

        if ($mensagem === "") {
            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" => "Digite uma mensagem."
            ];
        }

        if (mb_strlen($mensagem) > 4000) {
            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" => "A mensagem ultrapassa o limite de 4.000 caracteres."
            ];
        }

        $mensagens = [
            [
                "role" => "system",
                "content" =>
                    "Você é o assistente virtual do INVESTEGRA, "
                    . "um sistema de gestão de investimentos. "
                    . "Responda em português brasileiro, de forma "
                    . "clara, educada e organizada. "
                    . "Explique conceitos financeiros de maneira "
                    . "educativa. Não invente cotações, saldos ou "
                    . "informações sobre a carteira do usuário. "
                    . "Deixe claro que projeções não garantem "
                    . "rentabilidade futura. "
                    . "Não solicite senhas ou credenciais."
                    . ($contexto !== ""
                        ? "\n\nContexto financeiro disponível:\n" . $contexto
                        : "")
            ]
        ];

        // Limita a quantidade de mensagens anteriores enviadas.
        $historico = array_slice($historico, -10);

        foreach ($historico as $item) {
            if (
                !isset($item["role"], $item["content"]) ||
                !in_array($item["role"], ["user", "assistant"], true) ||
                !is_string($item["content"])
            ) {
                continue;
            }

            $conteudo = trim($item["content"]);

            if ($conteudo === "" || mb_strlen($conteudo) > 4000) {
                continue;
            }

            $mensagens[] = [
                "role" => $item["role"],
                "content" => $conteudo
            ];
        }

        $mensagens[] = [
            "role" => "user",
            "content" => $mensagem
        ];

        $payload = json_encode([
            "model" => $this->modelo,
            "messages" => $mensagens,
            "stream" => false
        ], JSON_UNESCAPED_UNICODE);

        if ($payload === false) {
            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" => "Não foi possível preparar a mensagem."
            ];
        }

        $curl = curl_init(
            $this->baseUrl . "/api/chat"
        );

        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 120
        ]);

        $corpoResposta = curl_exec($curl);
        $erroCurl = curl_error($curl);
        $statusHttp = (int) curl_getinfo(
            $curl,
            CURLINFO_HTTP_CODE
        );

        curl_close($curl);

        if ($corpoResposta === false) {
            error_log("Erro de comunicação com Ollama: " . $erroCurl);

            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" =>
                    "Não foi possível conectar ao Ollama. "
                    . "Verifique se ele está em execução."
            ];
        }

        $dados = json_decode($corpoResposta, true);

        if (
            $statusHttp < 200 ||
            $statusHttp >= 300 ||
            !is_array($dados)
        ) {
            error_log(
                "Resposta inválida do Ollama. HTTP: " . $statusHttp
            );

            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" =>
                    "O Ollama não conseguiu processar a mensagem."
            ];
        }

        $resposta = $dados["message"]["content"] ?? "";

        if (!is_string($resposta) || trim($resposta) === "") {
            return [
                "sucesso" => false,
                "resposta" => "",
                "erro" => "O modelo não retornou uma resposta válida."
            ];
        }

        return [
            "sucesso" => true,
            "resposta" => trim($resposta),
            "erro" => null
        ];
    }
}
