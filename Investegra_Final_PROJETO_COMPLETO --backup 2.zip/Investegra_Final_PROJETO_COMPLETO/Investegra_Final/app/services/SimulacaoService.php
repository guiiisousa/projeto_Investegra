<?php
namespace App\Services;

use InvalidArgumentException;

class SimulacaoService
{
    private function validar(float $capital, float $aporte, float $taxaAnual, int $meses): void
    {
        if (!is_finite($capital) || !is_finite($aporte) || !is_finite($taxaAnual)) {
            throw new InvalidArgumentException('Informe valores numéricos válidos.');
        }
        if ($capital < 0 || $capital > 100000000) throw new InvalidArgumentException('Capital inicial fora do limite permitido.');
        if ($aporte < 0 || $aporte > 10000000) throw new InvalidArgumentException('Aporte mensal fora do limite permitido.');
        if ($taxaAnual < -100 || $taxaAnual > 100) throw new InvalidArgumentException('A taxa anual deve estar entre -100% e 100%.');
        if ($meses < 1 || $meses > 600) throw new InvalidArgumentException('O prazo deve estar entre 1 e 600 meses.');
    }

    /** Juros simples: cada parcela rende linearmente pelo tempo em que permanece aplicada. */
    public function calcularSimples(float $capital, float $aporte, float $taxaAnual, int $meses): array
    {
        $this->validar($capital, $aporte, $taxaAnual, $meses);
        $taxaMensal = $taxaAnual / 100 / 12;
        $saldo = $capital;
        $total = $capital;
        $historico = [['mes'=>0, 'saldo'=>round($saldo,2), 'total_aportado'=>round($total,2)]];
        for ($m=1; $m <= $meses; $m++) {
            // O aporte é feito no fim do mês e começa a render no mês seguinte.
            $saldo += ($capital * 0); // deixa explícito que não há capitalização do saldo
            $saldo = $capital + ($capital * $taxaMensal * $m)
                + ($aporte * $taxaMensal * (($m - 1) * $m / 2))
                + ($aporte * ($m - 1));
            $total = $capital + ($aporte * $m);
            $historico[] = ['mes'=>$m, 'saldo'=>round($saldo,2), 'total_aportado'=>round($total,2)];
        }
        return $this->formatarResultado($capital, $aporte, $taxaAnual, $meses, $total, $saldo, $historico, 'simples');
    }

    /** Juros compostos com taxa mensal efetiva equivalente à taxa anual informada. */
    public function calcularCompostos(float $capital, float $aporte, float $taxaAnual, int $meses): array
    {
        $this->validar($capital, $aporte, $taxaAnual, $meses);
        if ($taxaAnual <= -100) throw new InvalidArgumentException('A taxa anual precisa ser maior que -100% para juros compostos.');
        $taxaMensal = pow(1 + $taxaAnual / 100, 1 / 12) - 1;
        $saldo = $capital;
        $total = $capital;
        $historico = [['mes'=>0, 'saldo'=>round($saldo,2), 'total_aportado'=>round($total,2)]];
        for ($m=1; $m <= $meses; $m++) {
            $saldo = ($saldo * (1 + $taxaMensal)) + $aporte;
            $total += $aporte;
            if (!is_finite($saldo)) throw new InvalidArgumentException('Não foi possível concluir a projeção com esses parâmetros.');
            $historico[] = ['mes'=>$m, 'saldo'=>round($saldo,2), 'total_aportado'=>round($total,2)];
        }
        return $this->formatarResultado($capital, $aporte, $taxaAnual, $meses, $total, $saldo, $historico, 'compostos');
    }

    public function calcularAtivo(float $capital, float $aporte, float $taxaAnual, int $meses): array
    {
        // A simulação por ativo utiliza juros compostos como modelo matemático de cenário,
        // não como promessa de retorno do ativo selecionado.
        return $this->calcularCompostos($capital, $aporte, $taxaAnual, $meses);
    }

    private function formatarResultado(float $capital, float $aporte, float $taxaAnual, int $meses, float $total, float $saldo, array $historico, string $tipo): array
    {
        return [
            'tipo_juros'=>$tipo, 'capital_inicial'=>$capital, 'aporte_mensal'=>$aporte,
            'taxa_anual'=>$taxaAnual, 'prazo_meses'=>$meses,
            'total_aportado'=>round($total,2), 'valor_final'=>round($saldo,2),
            'rendimento_estimado'=>round($saldo-$total,2), 'historico'=>$historico
        ];
    }
}
