<?php

namespace App\Services;

use App\Models\Carteira;
use App\Models\Ativo;
use App\Models\HistoricoPatrimonio;
use App\Services\BrapiService;
use Throwable;

class HistoricoPatrimonioService
{
    /**
     * Calcula e registra o patrimônio de um usuário.
     *
     * O registro só é salvo quando todas as cotações
     * necessárias estão disponíveis e são em BRL.
     */
    public function registrarPatrimonioUsuario(int $usuarioId): array
    {
        try {
            $modeloCarteira = new Carteira();
            $modeloAtivo = new Ativo();
            $modeloHistorico = new HistoricoPatrimonio();
            $brapi = new BrapiService();

            $carteiras = $modeloCarteira->listarPorUsuario($usuarioId);

            $valorTotal = 0.0;
            $quantidadeAtivos = 0;

            foreach ($carteiras as $carteira) {
                $ativos = $modeloAtivo->listarPorCarteiraEUsuario(
                    (int) $carteira["id"],
                    $usuarioId
                );

                foreach ($ativos as $ativo) {
                    $ticker = strtoupper(trim($ativo["ticker"] ?? ""));
                    $quantidade = (float) ($ativo["quantidade"] ?? 0);

                    if ($ticker === "" || $quantidade < 0) {
                        return [
                            "sucesso" => false,
                            "mensagem" => "Existe um ativo com dados inválidos."
                        ];
                    }

                    $cotacao = $brapi->buscarCotacao($ticker);

                    if (
                        !is_array($cotacao)
                        || !isset($cotacao["preco_atual"])
                        || !is_numeric($cotacao["preco_atual"])
                        || !isset($cotacao["moeda"])
                        || strtoupper($cotacao["moeda"]) !== "BRL"
                    ) {
                        return [
                            "sucesso" => false,
                            "mensagem" =>
                                "Não foi possível registrar o histórico completo. "
                                . "Verifique a cotação de " . $ticker . "."
                        ];
                    }

                    $precoAtual = (float) $cotacao["preco_atual"];

                    if ($precoAtual < 0) {
                        return [
                            "sucesso" => false,
                            "mensagem" => "A cotação de " . $ticker . " é inválida."
                        ];
                    }

                    $valorTotal += $quantidade * $precoAtual;
                    $quantidadeAtivos++;
                }
            }

            $registrado = $modeloHistorico->registrarOuAtualizar(
                $usuarioId,
                $valorTotal
            );

            if (!$registrado) {
                return [
                    "sucesso" => false,
                    "mensagem" => "Não foi possível salvar o histórico patrimonial."
                ];
            }

            return [
                "sucesso" => true,
                "mensagem" => "Histórico patrimonial registrado com sucesso.",
                "valor_total" => $valorTotal,
                "quantidade_ativos" => $quantidadeAtivos
            ];

        } catch (Throwable $erro) {
            error_log(
                "Erro ao registrar histórico patrimonial: "
                . $erro->getMessage()
            );

            return [
                "sucesso" => false,
                "mensagem" =>
                    "Ocorreu um erro ao calcular ou registrar o patrimônio."
            ];
        }
    }
}
