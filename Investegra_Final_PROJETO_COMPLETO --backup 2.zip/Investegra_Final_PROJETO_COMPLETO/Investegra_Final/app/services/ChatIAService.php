<?php

namespace App\Services;

class ChatIAService
{
    private array $configuracao;

    public function __construct()
    {
        $caminhoConfig = dirname(__DIR__, 2) . "/config/ia.php";

        if (!is_file($caminhoConfig)) {
            throw new \RuntimeException(
                "Arquivo de configuração da IA não encontrado."
            );
        }

        $configuracao = require $caminhoConfig;

        if (!is_array($configuracao)) {
            throw new \RuntimeException(
                "A configuração da IA é inválida."
            );
        }

        $this->configuracao = $configuracao;
    }

    public function conversar(
        string $mensagem,
        array $historico = [],
        string $contexto = ""
    ): array {
        $provedorPrincipal = strtolower(
            trim((string) ($this->configuracao["provedor"] ?? "ollama"))
        );

        $provedorAlternativo = $this->configuracao["fallback"] ?? null;

        $resultado = $this->executarProvedor(
            $provedorPrincipal,
            $mensagem,
            $historico,
            $contexto
        );

        if (!empty($resultado["sucesso"])) {
            return $resultado;
        }

        // Tenta a alternativa somente se ela estiver configurada.
        if (
            is_string($provedorAlternativo) &&
            trim($provedorAlternativo) !== "" &&
            strtolower(trim($provedorAlternativo)) !== $provedorPrincipal
        ) {
            error_log(
                "[INVESTEGRA IA] Provedor principal falhou; " .
                "tentando a alternativa configurada."
            );

            $alternativo = $this->executarProvedor(
                strtolower(trim($provedorAlternativo)),
                $mensagem,
                $historico,
                $contexto
            );

            if (!empty($alternativo["sucesso"])) {
                return $alternativo;
            }
        }

        return $resultado;
    }

    private function executarProvedor(
        string $provedor,
        string $mensagem,
        array $historico,
        string $contexto
    ): array {
        try {
            switch ($provedor) {
                case "ollama":
                    $servico = new OllamaService();
                    break;

                case "grok":
                    // O serviço será implementado em uma etapa futura.
                    if (!class_exists(GrokService::class)) {
                        return $this->falha(
                            "O serviço Grok ainda não foi configurado."
                        );
                    }

                    $servico = new GrokService();
                    break;

                default:
                    return $this->falha(
                        "O provedor de IA configurado não é reconhecido."
                    );
            }

            return $servico->conversar(
                $mensagem,
                $historico,
                $contexto
            );

        } catch (\Throwable $e) {
            error_log(
                "[INVESTEGRA IA] Erro no provedor " .
                $provedor . ": " .
                get_class($e) . ": " .
                $e->getMessage()
            );

            return $this->falha(
                "Não foi possível consultar o provedor de IA."
            );
        }
    }

    private function falha(string $mensagem): array
    {
        return [
            "sucesso" => false,
            "resposta" => "",
            "erro" => $mensagem
        ];
    }

    public function getProvedor(): string
    {
        return strtolower(
            trim((string) ($this->configuracao["provedor"] ?? "ollama"))
        );
    }
}
