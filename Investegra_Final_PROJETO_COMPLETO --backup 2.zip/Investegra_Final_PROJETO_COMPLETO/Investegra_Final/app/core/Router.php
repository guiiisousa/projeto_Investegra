<?php

namespace App\Core;

class Router
{
    private array $rotas = [];

    public function get(
        string $caminho,
        array $acao
    ): void {
        $this->registrar("GET", $caminho, $acao);
    }

    public function post(
        string $caminho,
        array $acao
    ): void {
        $this->registrar("POST", $caminho, $acao);
    }

    private function registrar(
        string $metodo,
        string $caminho,
        array $acao
    ): void {
        $caminho = $this->normalizar($caminho);

        $this->rotas[$metodo][$caminho] = $acao;
    }

    public function executar(): void
    {
        // Identifica o método HTTP
        $metodo = strtoupper(
            $_SERVER["REQUEST_METHOD"] ?? "GET"
        );

        // Obtém o caminho da URL, ignorando parâmetros
        $uri = parse_url(
            $_SERVER["REQUEST_URI"] ?? "/",
            PHP_URL_PATH
        ) ?: "/";

        // Identifica o diretório base da aplicação
        $base = str_replace(
            "\\",
            "/",
            dirname($_SERVER["SCRIPT_NAME"] ?? "")
        );

        $base = rtrim($base, "/");

        // Remove o diretório base do endereço solicitado
        if (
            $base !== "" &&
            $base !== "." &&
            (
                $uri === $base ||
                str_starts_with($uri, $base . "/")
            )
        ) {
            $uri = substr($uri, strlen($base));
        }

        // Normaliza o caminho
        $caminho = $this->normalizar($uri);

        // Procura a rota correspondente
        $acao = $this->rotas[$metodo][$caminho] ?? null;

        // Verifica se a rota existe
        if ($acao === null) {
            http_response_code(404);
            echo "Página não encontrada.";
            return;
        }

        // Separa a classe e o método do controller
        [$classe, $metodoController] = $acao;

        // Instancia o controller
        $controller = new $classe();

        // Executa o método correspondente
        $controller->$metodoController();
    }

    private function normalizar(string $caminho): string
    {
        $caminho = "/" . trim($caminho, "/");

        return $caminho === "" ? "/" : $caminho;
    }
}
