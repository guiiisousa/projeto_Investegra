
<?php

spl_autoload_register(function (string $classe): void {
    $prefixo = "App\\";

    if (!str_starts_with($classe, $prefixo)) {
        return;
    }

    $classeRelativa = substr(
        $classe,
        strlen($prefixo)
    );

    $partes = explode("\\", $classeRelativa);

    if (count($partes) < 2) {
        return;
    }

    $pasta = strtolower(array_shift($partes));

    $arquivo = dirname(__DIR__)
        . DIRECTORY_SEPARATOR
        . $pasta
        . DIRECTORY_SEPARATOR
        . implode(DIRECTORY_SEPARATOR, $partes)
        . ".php";

    if (is_file($arquivo)) {
        require_once $arquivo;
    }
});
