<?php
namespace App\Core;

use mysqli;
use RuntimeException;

class Database
{
    private static ?mysqli $conexao = null;

    public static function conectar(): mysqli
    {
        if (self::$conexao instanceof mysqli) {
            return self::$conexao;
        }

        $config = require dirname(__DIR__, 2)
            . "/config/database.php";

        mysqli_report(
            MYSQLI_REPORT_ERROR |
            MYSQLI_REPORT_STRICT
        );

        try {
            self::$conexao = new mysqli(
                $config["host"],
                $config["usuario"],
                $config["senha"],
                $config["banco"]
            );

            self::$conexao->set_charset("utf8mb4");

            return self::$conexao;
        } catch (\Throwable $erro) {
            error_log(
                "Erro de conexão com o banco: "
                . $erro->getMessage()
            );

            throw new RuntimeException(
                "Não foi possível conectar ao banco de dados."
            );
        }
    }
}
