<?php
// Informe seu token BRAPI, se sua modalidade de acesso exigir.
// Você também pode definir BRAPI_TOKEN como variável de ambiente.
return [
    "base_url" => "https://brapi.dev/api",
    "token" => getenv("BRAPI_TOKEN") ?: ""
];
