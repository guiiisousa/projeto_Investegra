<?php

return [
    // Provedor principal utilizado atualmente.
    "provedor" => "ollama",

    // Provedor alternativo, reservado para configuração futura.
    "fallback" => null
];
