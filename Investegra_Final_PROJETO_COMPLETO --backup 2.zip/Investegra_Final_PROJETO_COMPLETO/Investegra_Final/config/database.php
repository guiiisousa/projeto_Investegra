<?php
// Ajuste estas configurações ao seu MySQL local.
// Também é possível definir as variáveis de ambiente INVESTEGRA_DB_HOST,
// INVESTEGRA_DB_USER, INVESTEGRA_DB_PASS e INVESTEGRA_DB_NAME.
return [
    "host" => getenv("INVESTEGRA_DB_HOST") ?: "localhost",
    "usuario" => getenv("INVESTEGRA_DB_USER") ?: "root",
    "senha" => getenv("INVESTEGRA_DB_PASS") !== false ? getenv("INVESTEGRA_DB_PASS") : "Beto2009!",
    "banco" => getenv("INVESTEGRA_DB_NAME") ?: "Investegra_Final_Projeto_Completo"
];
